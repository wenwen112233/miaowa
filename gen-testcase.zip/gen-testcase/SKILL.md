---
name: gen-testcase
description: >-
  AI 自动化交付流程中的"验收测试用例生成"Skill。
  从 PRD 出发生成验收测试用例（非代码级单元测试），上传学城供产品同学评审确认，
  产品可多轮提出修改意见，确认通过后输出最终用例文件。
  当用户提到"生成测试用例"、"验收测试用例"、"测试用例评审"、"gen-testcase"、
  或希望从 PRD 生成验收测试用例供产品确认时使用此 skill。
  与 coder（代码开发 skill）配合使用：gen-testcase 输出确认后的用例，coder 读取用例进行开发。
---

# gen-testcase — 验收测试用例生成

从 PRD 生成验收测试用例，产品确认后交付给后续代码开发环节。

## 流程总览

```
拉取 PRD → 生成验收测试用例 → 产品确认（可多轮修改）
```

与 coder skill 的衔接关系：

| 本 skill 覆盖范围 | 产物 | 下游 |
|-------------------|------|------|
| 拉取 PRD → 生成验收测试用例 → 产品确认 | `.worker/<name>/验收测试用例.md` | coder（读取用例进行代码开发） |

---

## 调用方式

```
/gen-testcase <prd-url>                    # 全流程
/gen-testcase <name> --only=<step>         # 只执行指定步骤
/gen-testcase --list-steps                 # 查看所有步骤
```

### `--only` 参数对照表

| 参数值 | 步骤 | 说明 |
|--------|------|------|
| `prd` | Step 0 | 拉取 PRD |
| `gen` | Step 1 | 生成验收测试用例 |
| `review` | Step 2 | 产品确认测试用例 |

---

## 配置

启动时读取 `$PWD/.worker/dev.json`，文件不存在时使用默认配置：

```json
{
  "citadel": {
    "uploadTestCases": true
  }
}
```

| 字段 | 说明 | 默认值 |
|------|------|--------|
| `citadel.uploadTestCases` | 是否将测试用例上传到学城 | `true` |

---

## 执行流程

### 准备：读取配置和参数

```bash
PROJECT_ROOT="$PWD"
```

解析 ARGUMENTS，确定 `NAME`、`PRD_URL`，以及执行模式（全流程 / `--only`）。

输出：
```
🤖 [gen-testcase] 开始执行：<name>
```

---

### Step 0：拉取 PRD

需要 `<prd-url>` 参数。未传入时报错：`❌ 缺少 PRD 链接，请提供学城文档 URL`

**0.1 拉取 PRD 内容**

从 URL 中提取 contentId（km.sankuai.com/collabpage/<id> → <id>），执行：

```bash
oa-skills citadel getSimpleMarkdown --contentId <id>
```

提取返回内容中的标题和正文。从标题推导 `name`：翻译为英文、取核心业务词、snake_case（如「品牌管理」→ `brand`）。

写入 `$PROJECT_ROOT/.worker/<name>/prd.md`，文件已存在时覆盖写入。第一行保留学城原始链接：
```
<!-- km-url: https://km.sankuai.com/... -->
```

**0.2 场景判断**

解析 prd.md 文档标题，提取版本号，正则：`{功能名}V(\d+)-`：

- 版本号为 01，或标题不含版本号 → **新增场景**，`SCENE=new`
- 版本号 ≥ 02 → **变更场景**，`SCENE=change`

**0.3 变更清单生成**（仅 `SCENE=change` 时执行）

查找上一版本文档，AI 对比生成变更清单，追加写入 prd.md 末尾。格式：

```markdown
## 变更清单（V{N-1}→V{N}）

> 本节由 gen-testcase 自动生成，供后续步骤精准识别本次变更范围。

### 新增
- **[功能模块]**：[一句话说明，使用产品语言]

### 修改
- **[功能模块]**：[原内容] → [新内容，使用产品语言]
```

**0.4 API 文档拉取**（可选）

查找 PRD 子文档列表中标题含「API」或「接口」的子文档：

```bash
oa-skills citadel getChildContent --contentId <prd-id>
```

找到后拉取内容写入 `.worker/<name>/api.md`。未找到时跳过，输出 `⏭️ 未找到 API 文档，测试用例生成将仅依据 PRD`。

输出：
```
📖 [0/2] 拉取 PRD...
   ✅ PRD 已写入 .worker/<name>/prd.md（标题：<title>，name：<name>）
   🆕 新增场景 / 🔄 变更场景（V{N}）
   ✅ API 文档已写入 .worker/<name>/api.md
（或）
   ⏭️  未找到 API 文档，将仅依据 PRD 生成
```

---

### Step 1：生成验收测试用例

**核心原则：生成的是验收测试用例（从 PRD 视角描述"功能应该做什么"），不是代码级单元测试。**

读取 `.worker/<name>/prd.md` 和 `.worker/<name>/api.md`（如存在），根据 `SCENE` 变量分流处理。

读取 `references/test-case-format.md` 获取完整的测试用例格式规范。

**1.1 测试用例生成策略**

从 PRD 中识别所有用户可感知的功能点和业务场景，为每个场景生成一条验收测试用例。每条用例包含完整的操作路径（多步骤），步骤之间存在数据依赖。

**场景识别规则：**
- 从 PRD 交互说明、功能描述、业务规则章节中识别
- 每个独立的用户操作流程对应一条测试用例
- 覆盖正常流程、边界场景、异常场景三类
- 变更场景下，仅为变更清单中涉及的功能生成用例

**用例分类：**
- **正常流程用例**（Happy Path）：用户按预期路径完成操作
- **边界场景用例**：空数据、超长输入、分页边界、重复操作等
- **异常场景用例**：非法参数、权限不足、网络异常、并发冲突等

**1.2 项目类型适配**

自动检测项目类型（检测 `package.json` 为前端、`pom.xml` 为后端、两者都有为全栈），适配测试用例侧重：

| 项目类型 | 测试用例侧重 | 示例 |
|---------|-------------|------|
| `frontend` | 页面交互、UI 状态流转、表单校验 | 打开页面 → 点击按钮 → 填写表单 → 提交 → 验证页面反馈 |
| `backend` | 接口调用、数据流转、业务规则 | 调用创建接口 → 验证返回 → 调用查询接口 → 验证数据 |
| `fullstack` | 前后端联合场景 | 前端操作 → 后端接口响应 → 前端展示验证 |

**1.3 生成测试用例文档**

写入 `.worker/<name>/验收测试用例.md`，格式见 `references/test-case-format.md`。

**1.4 格式校验**

生成后执行格式校验，确保每条用例至少包含 2 个步骤、每个步骤有明确的预期结果：

```bash
TC_COUNT=$(grep -c "^## TC-" $PROJECT_ROOT/.worker/$NAME/验收测试用例.md)
STEP_COUNT=$(grep -c "^| TC-" $PROJECT_ROOT/.worker/$NAME/验收测试用例.md)
[ "$TC_COUNT" -eq 0 ] && echo "❌ 未生成任何测试用例，请检查 PRD 内容" && exit 1
[ "$STEP_COUNT" -lt "$((TC_COUNT * 2))" ] && echo "❌ 测试用例步骤数不足，每条用例至少 2 个步骤" && exit 1
```

**1.5 上传学城**（配置开启时）

从 prd.md 第一行读取学城链接。若链接存在：
1. 使用 `citadel` skill 查询该文档的子文档列表
2. 若标题为「验收测试用例」的子文档已存在 → 覆盖更新
3. 若不存在 → 新建子文档，标题「验收测试用例」，内容为验收测试用例.md 全文

输出：
```
🧪 [1/2] 生成验收测试用例...
   ✅ 已写入 .worker/<name>/验收测试用例.md（共 N 条用例，M 个步骤）
   ✅ 已同步到学城：<子文档链接>
（或）
   ⏭️  未找到学城链接，跳过上传
```

---

### Step 2：产品确认测试用例

**这是强制的人工确认环节，产品同学需确认测试用例是否正确、是否需要修正和补充。**

**2.1 展示测试用例**

读取 `.worker/<name>/验收测试用例.md`，向用户展示用例概览：

```
📋 验收测试用例已生成，请产品同学确认：

| 编号 | 场景名称 | 类型 | 步骤数 |
|------|---------|------|--------|
| TC-1 | 创建品牌-正常流程 | 正常 | 4 |
| TC-2 | 创建品牌-名称为空 | 异常 | 2 |
| TC-3 | 查询品牌列表-分页 | 边界 | 3 |
| ... |

完整用例已上传学城：<子文档链接>
完整文件路径：.worker/<name>/验收测试用例.md

请确认：
[A] 测试用例正确，继续交付给开发
[B] 需要修改，我会提供修改意见
[C] 中止流程
```

**2.2 处理产品反馈**

用户选择 `[B]` 时，接收修改意见，重新生成测试用例（回到 Step 1 逻辑），再次展示确认。循环直到产品确认通过。

**2.3 确认通过**

用户选择 `[A]` 后，将确认状态记录到 `.worker/<name>/state.md`，输出最终产物路径供 coder skill 使用。

输出：
```
✅ [2/2] 产品确认通过
   📋 测试用例已确认（N 条用例，M 个步骤）
   📄 产物路径：.worker/<name>/验收测试用例.md
   
下一步：使用 coder 进行代码开发
   /coder <prd-url> 或 /coder <name>
```

---

### 完成

打印执行摘要：

```
🎉 [gen-testcase] 执行完成！（<name>）

📋 执行摘要：

| 步骤 | 产物 |
|------|------|
| Step 0  prd    | .worker/<name>/prd.md + api.md |
| Step 1  gen    | .worker/<name>/验收测试用例.md（N 条用例） |
| Step 2  review | 产品确认通过 |

下一步：使用 coder 进行代码开发
   /coder <prd-url> 或 /coder <name>
```

---

## 错误处理原则

- 每步失败后打印清晰错误信息和 `--only=<step>` 重试提示
- Step 0 API 文档未找到不退出，降级为仅依据 PRD 生成
- Step 1 格式校验失败退出，提示重新生成
- Step 2 产品确认是人工环节，用户可多次要求修改

## 步骤流转铁律

**无论任何步骤内部经历了多少轮修改和重试，只要该步骤最终成功，必须立即继续执行后续步骤，不得停止。**

---

## ARGUMENTS

用户调用格式：
```
/gen-testcase <prd-url>                    # 全流程
/gen-testcase <name> --only=<step>         # 只执行指定步骤
/gen-testcase --list-steps                 # 查看所有步骤
```

解析规则：
- `--list-steps` → 输出步骤列表后立即退出
- 第一个非 `--` 参数以 `https://km.` 开头 → 作为 prd-url
- 第一个非 `--` 参数不以 `https://` 开头 → 作为 name（仅用于 `--only=<step>` 场景，需 `.worker/<name>/prd.md` 已存在）
- 执行到 PRD 拉取步骤但 prd-url 缺失时，报错：`❌ 缺少 PRD 链接`

`--list-steps` 输出：
```
📋 [gen-testcase] 步骤列表

| 步骤 | Code   | 说明               |
|------|--------|--------------------|
| 0    | prd    | 拉取 PRD           |
| 1    | gen    | 生成验收测试用例   |
| 2    | review | 产品确认测试用例   |

用法示例：
  /gen-testcase https://km.sankuai.com/collabpage/123456
  /gen-testcase brand --only=gen
  /gen-testcase brand --only=review
```

ARGUMENTS: <此处由调用者传入实际参数>
