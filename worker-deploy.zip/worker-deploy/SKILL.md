---
name: worker-deploy
description: AI 开发完成后一键部署至测试泳道，同时支持后端 Cargo 泳道和前端 Talos 泳道（talos-better.sankuai.com）。自动完成 Git 提交推送 → 触发泳道部署（Cargo/Talos）→ 等待部署完成 → 返回泳道名和访问域名。前端部署通过 talos-cli 的 --swimlane 参数把发布发到独立泳道，避免多人共用 newtest 环境冲突，且可与后端 cargo 泳道使用同一泳道名打通环境。当用户提到部署到甬道、部署到泳道、deploy to swimlane、AI 开发完部署、一键部署、自动部署到测试环境、前端部署、talos 部署、发布到 talos-better 时使用此 skill。自包含部署脚本体系，无需安装其他 skill。也支持自然语言触发，例如"我在xx仓库里的xx分支上写了版代码，帮我部署一下"、"帮我把这个分支部署到测试环境"、"代码写好了，部署一下"、"把feature/xxx分支部到泳道"、"deploy my branch"、"帮我把前端发布到泳道环境"等表述。当用户的意图是将某个仓库的某个分支部署到测试泳道时，即使没有使用 /worker-deploy 命令，也应激活此 skill。
---

# worker-deploy — AI 开发到部署甬道

从代码就绪到 Cargo 泳道可验证的一键全流程：Git 提交推送 → 触发 Cargo 泳道部署 → 等待部署完成 → 输出泳道名。

> **⚠️ 硬约束：所有步骤必须严格串行执行，禁止并行。**

> **定位**：第一阶段独立 skill，仅做后端 Cargo 泳道部署；后续合并进 worker-java 全流程。

> **自包含**：本 skill 内置了完整的部署脚本体系和认证模块，无需安装任何其他 skill 即可完成部署。

---

## 目录结构

```
worker-deploy/
├── SKILL.md                          # 本文件
├── scripts/
│   ├── auth-common.sh                # 认证公共函数库（5种鉴权方式）
│   ├── browser-sso-login.js          # 浏览器 SSO 登录（Node.js）
│   ├── deploy/
│   │   ├── execute_deploy.sh         # 部署主入口（Plus / Cargo）
│   │   ├── submit_deploy_job.sh      # 提交部署任务到 catpaw-plus
│   │   ├── get_ssoid.sh              # 获取 SSOID
│   │   ├── get_current_branch.sh     # 获取当前 Git 分支及状态
│   │   ├── read_config.sh            # 读取 deploy-config.json
│   │   ├── validate_config.sh        # 验证配置完整性
│   │   ├── commit_to_temp_branch.sh  # 临时分支提交
│   │   └── diagnose_and_retry.sh     # 部署失败自动诊断+重试
│   ├── talos/
│   │   ├── talos-common.sh           # talos-cli 检测 + 认证复用公共库
│   │   ├── fetch_talos_info.sh       # 查询当前仓库的 Talos 应用与模板
│   │   ├── execute_talos_deploy.sh   # 触发 Talos 前端泳道发布（--swimlane）
│   │   └── get_talos_flow_status.sh  # 查询 Talos 发布流水线状态
│   └── release/
│       ├── fetch_release_info.sh     # 获取发布项信息
│       └── release-common.sh         # 发布项公共配置
├── references/
│   ├── config_structure.md           # 配置文件结构详解
│   ├── cache_structure.md            # 缓存数据结构说明
│   ├── deploy/
│   │   ├── README.md                 # 部署管理完整文档
│   │   └── deploy_api_reference.md   # catpaw-plus API 参考
│   └── release/
│       └── README.md                 # 发布项信息管理文档
└── .cache/                           # 运行时自动生成
    └── release-info/
        ├── releases.json
        └── releases/<id>/templates.json
```

**内置脚本清单：**

| 脚本 | 用途 |
|------|------|
| `scripts/deploy/execute_deploy.sh` | 部署主入口，支持 Plus 和 Cargo 两种模式 |
| `scripts/deploy/submit_deploy_job.sh` | 提交部署任务到 catpaw-plus 平台，处理 API 交互 |
| `scripts/deploy/get_ssoid.sh` | 获取 SSOID（支持环境变量、CIBA、浏览器 SSO、CatPaw 配置文件四种方式） |
| `scripts/deploy/get_current_branch.sh` | 获取当前 Git 分支名称、SHA 和未提交变更状态 |
| `scripts/deploy/read_config.sh` | 读取并解析 deploy-config.json |
| `scripts/deploy/validate_config.sh` | 验证配置文件的完整性和有效性 |
| `scripts/deploy/commit_to_temp_branch.sh` | 将未提交变更提交到临时分支并推送 |
| `scripts/deploy/diagnose_and_retry.sh` | 部署失败后自动诊断（cargo-cli AI 诊断）+ 智能重试 |
| `scripts/talos/talos-common.sh` | talos-cli 检测（全局/npx 降级）+ 复用 auth-common.sh 注入 TALOS_ACCESS_TOKEN |
| `scripts/talos/fetch_talos_info.sh` | 查询当前仓库对应的 Talos 应用（app_id）与发布模板（template_id） |
| `scripts/talos/execute_talos_deploy.sh` | 触发 Talos 前端泳道发布（核心：`--swimlane` 参数） |
| `scripts/talos/get_talos_flow_status.sh` | 查询 Talos 发布流水线状态（用于等待发布完成） |
| `scripts/release/fetch_release_info.sh` | 获取发布项信息和部署模版列表 |
| `scripts/auth-common.sh` | 认证公共函数库（jq 自动安装、5种鉴权决策树、Token 持久化） |
| `scripts/browser-sso-login.js` | 浏览器 SSO 登录实现（需 Node.js + @mtfe/sso-web-oidc-cli） |

---

## 自然语言触发

本 skill 除了支持 `/worker-deploy` 命令调用外，还支持通过自然语言触发。当用户说出类似以下表述时，AI 应识别部署意图并激活本 skill：

**典型触发表述：**

- "我在 /Users/xxx/IdeaProjects/giantcps 仓库里的 feature/my-branch 分支上写了版代码，帮我部署一下"
- "帮我把 feature/xxx 分支部署到测试环境"
- "代码写好了，部署一下"
- "把当前分支部到泳道"
- "deploy my branch to swimlane"
- "帮我部署 giantcps 项目"

**AI 解析规则：**

从用户的自然语言中提取以下信息（提取不到的用默认值）：

| 信息 | 提取方式 | 默认值 |
|------|---------|--------|
| 仓库路径 | 用户提到的绝对路径（如 `/Users/xxx/IdeaProjects/giantcps`）或仓库名 | 当前工作目录 `$PWD` |
| 分支名 | 用户提到的分支名（如 `feature/my-branch`、`auto-delivery-test`） | 仓库当前所在分支 |
| 泳道名 | 用户提到的泳道名 | 配置文件中的 `swimlane`（为空则自动创建） |

**解析完成后的执行流程：**

1. **切换到目标仓库** — 如果用户指定了仓库路径，先 `cd` 到该路径
2. **切换到目标分支** — 如果用户指定的分支和当前分支不同：
   ```bash
   CURRENT=$(git branch --show-current)
   if [ "$CURRENT" != "$TARGET_BRANCH" ]; then
     git fetch origin "$TARGET_BRANCH" 2>/dev/null
     git checkout "$TARGET_BRANCH" 2>/dev/null || git checkout -b "$TARGET_BRANCH" "origin/$TARGET_BRANCH"
   fi
   ```
3. **检查配置是否存在** — 如果 `.worker/deploy.json` 不存在，自动进入「自动配置生成」流程（见下方）
4. **执行全流程** — 等同于 `/worker-deploy`（Step 1 → Step 2 → Step 3）

### 自动配置生成

当 `.worker/deploy.json` 不存在时，**不报错退出**，而是自动生成配置：

```bash
# 1. 查询当前仓库的发布项信息
cd "$PROJECT_ROOT"
"$SKILL_DIR/scripts/release/fetch_release_info.sh"
# 脚本自动从 git remote origin 获取仓库 URL 并查询发布项
# 结果缓存到 $SKILL_DIR/.cache/release-info/releases.json
```

```bash
# 2. 读取缓存，获取发布项列表
RELEASES=$(cat "$SKILL_DIR/.cache/release-info/releases.json")
RELEASE_COUNT=$(echo "$RELEASES" | jq '.releases | length')
```

**根据发布项数量决定下一步：**

- **0 个发布项** → 报错退出：`❌ 该仓库未找到任何发布项，请确认仓库地址是否正确`
- **1 个发布项** → 自动选择该发布项，无需询问用户
- **多个发布项** → 列出所有发布项，**询问用户要部署哪一个**

```bash
# 3. 提取选定发布项的信息
SELECTED_RELEASE=$(echo "$RELEASES" | jq -r ".releases[$INDEX]")
R_ID=$(echo "$SELECTED_RELEASE" | jq -r '.release_id')
R_NAME=$(echo "$SELECTED_RELEASE" | jq -r '.release_name')
R_APPKEY=$(echo "$SELECTED_RELEASE" | jq -r '.appkey')

# 4. 读取该发布项的模版列表（选 env=test 的模版）
TEMPLATES=$(cat "$SKILL_DIR/.cache/release-info/releases/$R_ID/templates.json")
TEST_TEMPLATE=$(echo "$TEMPLATES" | jq '[.templates[] | select(.environment_name == "test")] | .[0]')
T_ID=$(echo "$TEST_TEMPLATE" | jq -r '.template_id')
T_NAME=$(echo "$TEST_TEMPLATE" | jq -r '.template_name')
```

**如果没有 test 环境模版** → 列出所有模版让用户选择。

```bash
# 5. 自动生成 deploy.json
mkdir -p "$PROJECT_ROOT/.worker"
cat > "$PROJECT_ROOT/.worker/deploy.json" << EOF
{
  "deploy_type": "cargo",
  "release": [
    {
      "release_id": $R_ID,
      "release_name": "$R_NAME",
      "appkey": "$R_APPKEY",
      "template": {
        "id": $T_ID,
        "name": "$T_NAME",
        "env": "test"
      }
    }
  ],
  "label": "",
  "label_type": "branch",
  "swimlane": "",
  "deploy": {
    "pollIntervalSeconds": 30,
    "timeoutMinutes": 10
  },
  "git": {
    "autoCommit": true,
    "commitMessagePrefix": "feat"
  }
}
EOF

echo "✅ 已自动生成配置文件：$PROJECT_ROOT/.worker/deploy.json"
```

生成完成后，继续执行正常的全流程（Step 1 → Step 2 → Step 3）。

---

## 配置

启动时读取 `$PWD/.worker/deploy.json`。文件不存在时自动进入上方「自动配置生成」流程

```json
{
  "deploy_type": "cargo",
  "release": [
    {
      "release_id": 178014,
      "release_name": "项目发布项名称",
      "appkey": "com.sankuai.xxx",
      "template": {
        "id": 1001,
        "name": "test",
        "env": "test"
      }
    }
  ],
  "label": "",
  "label_type": "branch",
  "swimlane": "",
  "deploy": {
    "pollIntervalSeconds": 30,
    "timeoutMinutes": 10
  },
  "git": {
    "autoCommit": true,
    "commitMessagePrefix": "feat"
  }
}
```

**配置字段说明：**

| 字段 | 必需 | 类型 | 说明 |
|------|:----:|------|------|
| `deploy_type` | ✓ | string | 部署类型：`cargo`（后端服务）或 `talos`（前端工程） |
| `release` | ✓ | array | 发布项数组（通常一个元素） |
| `release[].release_id` | ✓ | number | 发布项 ID |
| `release[].release_name` | ✓ | string | 发布项名称 |
| `release[].appkey` | ✓ | string | 应用 AppKey，如 `com.sankuai.xxx`（Cargo 必需） |
| `release[].template.id` | ✓ | number | 部署模版 ID |
| `release[].template.name` | ✓ | string | 部署模版名称（Cargo 会将此值传给 API） |
| `release[].template.env` | ✓ | string | 部署环境，第一阶段固定为 `test` |
| `label` | ✗ | string | 部署标签（分支名/tag/commit SHA），为空时自动取当前分支 |
| `label_type` | ✗ | string | 标签类型 `branch`/`tag`/`commit`，默认 `branch` |
| `swimlane` | ✗ | string | 泳道名/ProjectID，为空时自动创建新泳道 |
| `deploy.pollIntervalSeconds` | ✗ | number | 部署状态轮询间隔（秒），默认 30 |
| `deploy.timeoutMinutes` | ✗ | number | 部署超时上限（分钟），默认 10 |
| `git.autoCommit` | ✗ | boolean | 是否自动提交，默认 true |
| `git.commitMessagePrefix` | ✗ | string | commit 消息前缀，默认 `feat` |

详细的配置结构说明请参考 [references/config_structure.md](references/config_structure.md)。

### 前端 Talos 部署配置（`deploy_type: "talos"`）

前端工程（Web / MRN / 小程序等，托管在 talos-better.sankuai.com）使用 `deploy_type: "talos"`。**关键点：通过 `swimlane` 字段把前端发布到独立泳道**，域名形如 `<swimlane>-sl-xxx.giant.test.sankuai.com`，避免多人共用 `newtest` 环境时都访问同一个网址导致冲突。**建议 `swimlane` 与后端 cargo 部署使用同一个泳道名，前后端环境全打通。**

```json
{
  "deploy_type": "talos",
  "talos": {
    "platform": "v2",
    "app_id": "34261",
    "template_id": "534278",
    "sub_app_id": "",
    "target": "newtest"
  },
  "label": "",
  "label_type": "branch",
  "swimlane": "wenshuhui-f7257",
  "deploy": {
    "pollIntervalSeconds": 30,
    "timeoutMinutes": 15
  },
  "git": {
    "autoCommit": true,
    "commitMessagePrefix": "feat"
  }
}
```

| 字段 | 必需 | 类型 | 说明 |
|------|:----:|------|------|
| `talos.platform` | ✗ | string | Talos 平台版本 `v1`/`v2`，默认 `v2` |
| `talos.app_id` | ✓ | string | Talos 应用 ID |
| `talos.template_id` | ✓ | string | 发布模板 ID |
| `talos.sub_app_id` | ✗ | string | Talos 1.0 Monorepo 子项目 ID（仅 v1 需要） |
| `talos.target` | ✗ | string | 目标环境，默认 `newtest`（仅支持测试环境） |
| `swimlane` | ✓ | string | **泳道名（前端泳道化部署的核心）**，建议与后端 cargo 泳道名一致 |

### 首次配置获取

如果用户不知道 `release_id`、`template` 等值，使用内置的发布项查询脚本获取：

```bash
# 定位 skill 脚本目录
SKILL_DIR=$(find ~/.catpaw/skills -name "worker-deploy" -type d 2>/dev/null | head -1)
if [ -z "$SKILL_DIR" ]; then
  # 如果是项目级 skill
  SKILL_DIR=$(find .catpaw/skills -name "worker-deploy" -type d 2>/dev/null | head -1)
fi

# 授予执行权限
chmod +x "$SKILL_DIR/scripts"/**/*.sh "$SKILL_DIR/scripts"/*.sh 2>/dev/null

# 获取当前仓库的发布项信息
"$SKILL_DIR/scripts/release/fetch_release_info.sh"
```

返回的 JSON 中包含 `release_id`、`release_name`、`appkey` 和可用的部署模版列表，选取 `env=test` 的模版填入配置即可。详细的发布项查询说明请参考 [references/release/README.md](references/release/README.md)。

**前端 Talos 项目**：如果是前端工程（不知道 `app_id`、`template_id`），使用 talos 查询脚本获取：

```bash
# 查询当前仓库对应的 Talos 应用与发布模板
"$SKILL_DIR/scripts/talos/fetch_talos_info.sh" "$PWD" "v2" "newtest"
```

返回 JSON 中 `apps` 是当前仓库对应的 Talos 应用列表（取 `id` 作为 `app_id`），`templates` 是可用发布模板列表（取 `id` 作为 `template_id`）。多个应用/模板时询问用户选择，单个时自动选定，填入 `talos` 配置块即可。

---

## 前置准备

### cargo-cli（部署诊断依赖）

本 skill 在部署失败时自动调用 cargo-cli 进行 AI 诊断和重试。首次使用前检查是否已安装：

```bash
cargo-cli --version  # 需要 ≥ 1.3.2
# 未安装时执行：
npm install -g @ee/cargo-cli --registry=http://r.npm.sankuai.com
```

cargo-cli 的 SSO 认证自动复用本 skill 的 `~/.catpaw/sso_config.json`，无需额外登录。

### 授予脚本执行权限

首次使用时，对 `scripts` 目录下所有脚本授予执行权限：

```bash
# 定位 skill 目录
SKILL_DIR=$(find ~/.catpaw/skills -name "worker-deploy" -type d 2>/dev/null | head -1)
[ -z "$SKILL_DIR" ] && SKILL_DIR=$(find .catpaw/skills -name "worker-deploy" -type d 2>/dev/null | head -1)
[ -z "$SKILL_DIR" ] && echo "❌ 未找到 worker-deploy skill 目录" && exit 1

# 授予执行权限
chmod +x "$SKILL_DIR/scripts"/**/*.sh "$SKILL_DIR/scripts"/*.sh 2>/dev/null
```

### 认证说明

本 skill 内置 6 种鉴权方式，按优先级自动选择：

1. 环境变量 `PLUS_ACCESS_TOKEN`（最高优先级）
2. CatDesk CLI 认证（`catdesk auth token`，CatPaw 用户自身 SSO 会话，自动刷新）
3. 已保存的 Token（`~/.config/plus-cli/config.json`，12小时有效）
4. CatClaw/OpenClaw 沙箱环境 → CIBA 认证（大象 App 推送确认）
5. 非 CatClaw 环境 → 浏览器 SSO 登录（需 Node.js + `@mtfe/sso-web-oidc-cli`）
6. CatPaw 配置文件降级（`~/.catpaw/sso_config.json`，兜底）

大部分情况下无需手动处理认证，脚本会自动选择合适的方式。如果遇到 SSOID 相关错误，请给 CatPaw 提 TT。

---

## 执行流程

### 准备：读取配置和参数

```bash
PROJECT_ROOT="$PWD"
WORKER_START_TIME=$(date +%s)

# 定位 skill 目录
SKILL_DIR=$(find ~/.catpaw/skills -name "worker-deploy" -type d 2>/dev/null | head -1)
[ -z "$SKILL_DIR" ] && SKILL_DIR=$(find .catpaw/skills -name "worker-deploy" -type d 2>/dev/null | head -1)
[ -z "$SKILL_DIR" ] && echo "❌ 未找到 worker-deploy skill 目录" && exit 1

# 授予执行权限
chmod +x "$SKILL_DIR/scripts"/**/*.sh "$SKILL_DIR/scripts"/*.sh 2>/dev/null

# 读取配置（不存在时自动生成）
CONFIG_FILE="$PROJECT_ROOT/.worker/deploy.json"
if [ ! -f "$CONFIG_FILE" ]; then
  echo "📋 未找到 .worker/deploy.json，自动生成配置..."
  # 执行自动配置生成流程（见「自动配置生成」章节）
  # 1) 查询发布项  2) 选择发布项和模版  3) 生成 deploy.json
  # 具体步骤由 AI agent 按「自动配置生成」章节的逻辑执行
fi

CONFIG=$(cat "$CONFIG_FILE")
DEPLOY_TYPE=$(echo "$CONFIG" | jq -r '.deploy_type // "cargo"')
APPKEY=$(echo "$CONFIG" | jq -r '.release[0].appkey')
RELEASE_ID=$(echo "$CONFIG" | jq -r '.release[0].release_id')
RELEASE_NAME=$(echo "$CONFIG" | jq -r '.release[0].release_name')
TEMPLATE_ID=$(echo "$CONFIG" | jq -r '.release[0].template.id')
TEMPLATE_NAME=$(echo "$CONFIG" | jq -r '.release[0].template.name')
TEMPLATE_ENV=$(echo "$CONFIG" | jq -r '.release[0].template.env // "test"')
LABEL=$(echo "$CONFIG" | jq -r '.label // ""')
LABEL_TYPE=$(echo "$CONFIG" | jq -r '.label_type // "branch"')
SWIMLANE=$(echo "$CONFIG" | jq -r '.swimlane // ""')
POLL_INTERVAL=$(echo "$CONFIG" | jq -r '.deploy.pollIntervalSeconds // 30')
TIMEOUT_MINUTES=$(echo "$CONFIG" | jq -r '.deploy.timeoutMinutes // 10')
AUTO_COMMIT=$(echo "$CONFIG" | jq -r '.git.autoCommit // true')
COMMIT_PREFIX=$(echo "$CONFIG" | jq -r '.git.commitMessagePrefix // "feat"')
```

解析 ARGUMENTS，确定执行模式（全流程 / `--only`）。

**运行时变量兜底规则（适用于 `--only` 模式）：**

`--only=wait` 或 `--only=deploy` 直接进入某步骤时，`JOB_ID` 可能为空。遇到为空时：
- `JOB_ID` 为空 → 从 `.worker/deploy-state.json` 读取上次记录的 `job_id`
- 仍为空 → 报错退出：`❌ 无法获取部署任务 ID，请确认已执行过 deploy 步骤`

输出：
```
🤖 [worker-deploy] 开始执行
   📋 应用：<appkey>
   📦 发布项：<release_name> (ID: <release_id>)
   🎯 环境：<template_env>
```

---

### Step 1：Git 提交推送

检测当前 Git 状态，自动提交并推送到远程。

使用内置脚本获取当前分支状态：

```bash
BRANCH_INFO=$("$SKILL_DIR/scripts/deploy/get_current_branch.sh" "$PROJECT_ROOT")
CURRENT_BRANCH=$(echo "$BRANCH_INFO" | jq -r '.branch')
HAS_UNCOMMITTED=$(echo "$BRANCH_INFO" | jq -r '.has_uncommitted_changes')
COMMIT_SHA=$(echo "$BRANCH_INFO" | jq -r '.sha')
```

**如果配置中指定了 `label`（非空），跳过 Git 提交步骤，直接使用配置中的 label。**

**分两条路：**

**无未提交变更（`HAS_UNCOMMITTED` = false）→ 跳过提交，直接使用当前分支：**

```bash
LABEL="$CURRENT_BRANCH"
LABEL_TYPE="branch"
```

**有未提交变更 → 执行提交推送（`AUTO_COMMIT` = true 时）：**

```bash
# 确保所有变更已暂存
git add -A
```

**生成语义化 commit 消息（AI 分析改动内容）：**

AI agent 在执行 `git commit` 前，**必须先分析本次代码改动，生成语义化的 commit message**，而非使用固定的时间戳格式。流程如下：

```bash
# 1. 获取暂存区的 diff
DIFF_OUTPUT=$(git diff --cached)
DIFF_LINE_COUNT=$(echo "$DIFF_OUTPUT" | wc -l)
```

**根据 diff 大小选择分析策略：**

- **diff 行数 ≤ 500 行**：AI agent 读取完整 diff 内容，理解改动意图（新增了什么功能、修复了什么问题、重构了哪些逻辑），生成语义化 commit message。
- **diff 行数 > 500 行**：diff 内容过大，AI agent 改用 `git diff --cached --stat` 获取改动文件列表和统计信息，根据文件名、文件类型和增删行数推断改动范围，生成摘要式 commit message。

**commit message 格式规范：**

```
<prefix>: <简洁描述改动内容，不超过72字符>
```

- `prefix` 取配置中的 `git.commitMessagePrefix`（默认 `feat`），但 AI 应根据实际改动类型智能调整：新功能用 `feat`，修 bug 用 `fix`，重构用 `refactor`，文档用 `docs`，测试用 `test`，性能优化用 `perf`，样式用 `style`。
- 描述部分用简洁的中文或英文概括本次改动的核心内容，例如：`达人列表接口新增提交状态字段`、`fix: 修复达人选号分页越界问题`。
- 如果改动涉及多个方面，选取最主要的一个作为主题，不要堆砌罗列。

```bash
# 2. AI agent 根据 diff 分析结果生成 COMMIT_MSG（此处由 AI agent 填入实际消息）
COMMIT_MSG="$COMMIT_PREFIX: <AI 生成的语义化描述>"

# 3. 提交并推送
git commit -m "$COMMIT_MSG"
git push -u origin HEAD
```

> **注意**：AI agent 在生成 commit message 时，应像一个有经验的开发者写 commit 一样，准确概括改动意图，避免过于笼统（如"修改代码"）或过于冗长。如果 diff 内容难以理解，可降级为 `<prefix>: auto deploy <时间戳>` 格式。

**分支名被拒绝时的处理：**

如果 `git push` 失败，且错误信息中包含 `分支流检查`、`分支命名规则`、`分支卡控`、`pre-receive hook declined` 等关键词，说明当前分支名不符合公司分支命名规范。AI agent 应执行以下流程：

1. **识别拒绝原因**：从 git push 的 stderr 输出中确认是分支命名问题（而非其他原因如权限不足、网络错误等）。
2. **生成新分支名**：将原分支名改为 `dev/<原分支名>` 格式。例如原分支 `total-price` → 新分支 `dev/total-price`。如果 `dev/<原分支名>` 仍然可能不合规（例如原分支名本身含有特殊字符），AI 可根据实际命名规范调整。
3. **提示用户确认**：输出提示信息，告知用户原分支名被拒绝、建议的新分支名，并使用 AskQuestion 工具让用户确认或修改：
   ```
   ⚠️ 分支名「<原分支名>」被远程仓库拒绝（不符合分支命名规范）
   建议重命名为：dev/<原分支名>
   ```
   提供选项：
   - 确认使用 `dev/<原分支名>` 并继续推送
   - 用户自定义分支名
4. **执行重命名并推送**：用户确认后，执行以下操作：
   ```bash
   # 创建新分支（指向当前 commit）
   git branch <NEW_BRANCH>
   # 切换到新分支
   git checkout <NEW_BRANCH>
   # 推送新分支到远程
   git push -u origin <NEW_BRANCH>
   ```
5. **更新后续步骤使用的分支名**：后续 Step 2/3 中的 `LABEL` 和 `CURRENT_BRANCH` 应使用新分支名。

> **注意**：只在确认是分支命名问题时才执行此流程。其他推送错误（如网络问题、权限问题）不应触发重命名，而应直接报错退出。

```bash
COMMIT_SHA=$(git rev-parse HEAD)
LABEL="$CURRENT_BRANCH"   # 如果发生过分支重命名，这里使用重命名后的新分支名
LABEL_TYPE="branch"
```

**如果 `AUTO_COMMIT` = false：**
- 有未提交变更 → 报错退出：`❌ 有未提交的变更，请先手动提交或将 git.autoCommit 设为 true`
- 无未提交变更 → 正常继续

输出：
```
📦 [1/3] Git 提交推送...
   ✅ 已提交并推送：<commit_msg>（分支：<branch>，SHA：<commit_sha 前8位>）
（或）
   ⏭️  工作区干净，跳过提交（分支：<branch>，SHA：<commit_sha 前8位>）
（或）
   ⚠️ 分支名「<原分支名>」被拒绝 → 已重命名为「<新分支名>」并推送成功（SHA：<commit_sha 前8位>）
（或）
   ❌ 有未提交的变更，请先手动提交
```

---

### Step 2：触发泳道部署

**根据 `deploy_type` 分流：**

```bash
if [ "$DEPLOY_TYPE" = "talos" ]; then
  # 前端 Talos 泳道部署 → 跳转 Step 2-Talos
  :
else
  # 后端 Cargo 泳道部署 → 继续下方 Step 2-Cargo（默认）
  :
fi
```

#### Step 2-Cargo：触发 Cargo 泳道部署（`deploy_type: "cargo"`）

使用内置的部署脚本，触发异步部署后**立即进入下一步，不等待**。

```bash
# 调用内置部署脚本（Cargo 模式）
DEPLOY_OUTPUT=$("$SKILL_DIR/scripts/deploy/execute_deploy.sh" \
  "$DEPLOY_TYPE" \
  "$RELEASE_ID" \
  "$TEMPLATE_ID" \
  "$TEMPLATE_NAME" \
  "$LABEL_TYPE" \
  "$LABEL" \
  "$APPKEY" \
  "$SWIMLANE" \
  2>&1)

echo "$DEPLOY_OUTPUT"
```

**从部署结果中提取关键信息：**

```bash
# 部署脚本返回 JSON，提取 job_id 和 project_id（泳道名）
DEPLOY_STATUS=$(echo "$DEPLOY_OUTPUT" | jq -r '.status // empty')

if [ "$DEPLOY_STATUS" = "success" ] || [ "$DEPLOY_STATUS" = "pending" ]; then
  JOB_ID=$(echo "$DEPLOY_OUTPUT" | jq -r '.job_id // empty')
  SWIMLANE_RESULT=$(echo "$DEPLOY_OUTPUT" | jq -r '.project_id // .swimlane // empty')

  # 如果配置中 swimlane 为空，从返回值中取（catpaw-plus 自动创建的）
  [ -z "$SWIMLANE" ] && SWIMLANE="$SWIMLANE_RESULT"
else
  ERROR_MSG=$(echo "$DEPLOY_OUTPUT" | jq -r '.message // "未知错误"')
  echo "❌ 部署触发失败：$ERROR_MSG"

  # 特殊错误处理：无可用机器
  if echo "$ERROR_MSG" | grep -q "没有可用的机器"; then
    echo "💡 提示：该部署模板下所有机器可能属于 Cargo 泳道，请检查 deploy.json 中的 template 配置"
  fi

  # SSOID 错误
  if echo "$ERROR_MSG" | grep -qi "ssoid\|sso"; then
    echo "💡 提示：SSOID 异常，请给 CatPaw 提 TT"
  fi

  exit 1
fi
```

**持久化部署状态（供 `--only=wait` 使用）：**

```bash
mkdir -p "$PROJECT_ROOT/.worker"
cat > "$PROJECT_ROOT/.worker/deploy-state.json" << EOF
{
  "job_id": "$JOB_ID",
  "swimlane": "$SWIMLANE",
  "branch": "$CURRENT_BRANCH",
  "commit_sha": "$COMMIT_SHA",
  "deploy_time": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
}
EOF
```

输出：
```
🚢 [2/3] 触发 Cargo 泳道部署...
   ✅ 部署已触发（分支：<label>，任务 ID：<job_id>）
   🚀 泳道：<SWIMLANE>
```

---

#### Step 2-Talos：触发 Talos 前端泳道部署（`deploy_type: "talos"`）

前端工程通过 talos-cli 的 `--swimlane` 参数发布到独立泳道，避免多人共用 `newtest` 冲突。

```bash
# 从配置读取 talos 相关字段
TALOS_PLATFORM=$(echo "$CONFIG" | jq -r '.talos.platform // "v2"')
TALOS_APP_ID=$(echo "$CONFIG" | jq -r '.talos.app_id // empty')
TALOS_TEMPLATE_ID=$(echo "$CONFIG" | jq -r '.talos.template_id // empty')
TALOS_SUB_APP_ID=$(echo "$CONFIG" | jq -r '.talos.sub_app_id // empty')
TALOS_TARGET=$(echo "$CONFIG" | jq -r '.talos.target // "newtest"')

# swimlane 必填（前端泳道化部署的核心）；为空时用 misId 生成一个
if [ -z "$SWIMLANE" ]; then
  SWIMLANE="$(whoami)-$(date +%s | tail -c 6)"
  echo "ℹ️  未指定泳道，自动生成泳道名：$SWIMLANE"
fi

# 组装可选参数
TALOS_OPTS=(--target "$TALOS_TARGET" --platform "$TALOS_PLATFORM" --note "worker-deploy 自动发布")
[ -n "$TALOS_SUB_APP_ID" ] && TALOS_OPTS+=(--sub-app-id "$TALOS_SUB_APP_ID")

# 调用内置 talos 发布脚本（认证自动复用 auth-common.sh）
TALOS_OUTPUT=$("$SKILL_DIR/scripts/talos/execute_talos_deploy.sh" \
  "$TALOS_APP_ID" \
  "$TALOS_TEMPLATE_ID" \
  "$CURRENT_BRANCH" \
  "$SWIMLANE" \
  "${TALOS_OPTS[@]}" \
  2>&1)

echo "$TALOS_OUTPUT"
```

**提取发布结果：**

```bash
TALOS_JSON=$(echo "$TALOS_OUTPUT" | grep -o '{.*}' | tail -1)
TALOS_STATUS=$(echo "$TALOS_JSON" | jq -r '.status // empty')

if [ "$TALOS_STATUS" = "success" ]; then
  FLOW_ID=$(echo "$TALOS_JSON" | jq -r '.flow_id // empty')
  DEPLOY_URL=$(echo "$TALOS_JSON" | jq -r '.url // empty')
  echo "✅ 前端发布已触发（泳道：$SWIMLANE，flowId：$FLOW_ID）"
else
  ERROR_MSG=$(echo "$TALOS_JSON" | jq -r '.message // "未知错误"')
  echo "❌ 前端发布触发失败：$ERROR_MSG"
  exit 1
fi
```

**持久化发布状态：**

```bash
mkdir -p "$PROJECT_ROOT/.worker"
cat > "$PROJECT_ROOT/.worker/deploy-state.json" << EOF
{
  "deploy_type": "talos",
  "flow_id": "$FLOW_ID",
  "app_id": "$TALOS_APP_ID",
  "platform": "$TALOS_PLATFORM",
  "swimlane": "$SWIMLANE",
  "branch": "$CURRENT_BRANCH",
  "commit_sha": "$COMMIT_SHA",
  "deploy_url": "$DEPLOY_URL",
  "deploy_time": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
}
EOF
```

**等待前端发布完成**（Talos 场景 Step 3 用下面的脚本轮询，替代 Cargo 的 catpaw-plus 轮询）：

```bash
POLL_INTERVAL=$(echo "$CONFIG" | jq -r '.deploy.pollIntervalSeconds // 30')
TIMEOUT_MIN=$(echo "$CONFIG" | jq -r '.deploy.timeoutMinutes // 15')
ELAPSED=0
while [ $ELAPSED -lt $((TIMEOUT_MIN * 60)) ]; do
  FLOW_STATUS=$("$SKILL_DIR/scripts/talos/get_talos_flow_status.sh" "$FLOW_ID" "$TALOS_APP_ID" "$TALOS_PLATFORM" 2>/dev/null | jq -r '.status // "unknown"')
  case "$FLOW_STATUS" in
    success) echo "✅ 前端发布成功"; break ;;
    failed)  echo "❌ 前端发布失败，请查看：$DEPLOY_URL"; exit 1 ;;
    *)       echo "🔄 [$((ELAPSED/60))m$((ELAPSED%60))s] 发布中，继续等待..."; sleep "$POLL_INTERVAL"; ELAPSED=$((ELAPSED + POLL_INTERVAL)) ;;
  esac
done
```

输出：
```
🚢 [2/3] 触发 Talos 前端泳道部署...
   ✅ 发布已触发（分支：<branch>，flowId：<flow_id>）
   🚀 泳道：<SWIMLANE>
   🌐 泳道域名：<SWIMLANE>-sl-xxx.giant.test.sankuai.com
```

> **说明**：Talos 场景下 Step 2-Talos 已内含轮询等待逻辑，完成后直接进入「完成」输出摘要，不再走 Step 3（Cargo 专用）。

---

### Step 3：等待部署完成

轮询 catpaw-plus 的部署状态查询接口，直到部署成功/失败/超时。

**⚠️ 严禁使用 while 循环或任何长时间阻塞的单次 bash 命令实现轮询。必须每次轮询单独调用一次 bash。**

`JOB_ID` 为空时，从 `.worker/deploy-state.json` 读取：
```bash
[ -z "$JOB_ID" ] && JOB_ID=$(jq -r '.job_id' "$PROJECT_ROOT/.worker/deploy-state.json" 2>/dev/null)
[ -z "$JOB_ID" ] && echo "❌ 无法获取部署任务 ID" && exit 1
```

**每次轮询执行：**

```bash
STATUS_OUTPUT=$(curl -s "https://catpaw-plus.sankuai.com/get/job?jobID=$JOB_ID")
DEPLOY_STATUS=$(echo "$STATUS_OUTPUT" | jq -r '.Data.Status // "unknown"')
```

**判断逻辑：**

| 状态 | 处理 |
|------|------|
| `success` | 部署成功，提取 `StackUrl`，进入「完成」。**不得再 sleep** |
| `failed` | **自动诊断+重试**（见下方 Step 3b），不直接报错退出 |
| `pending` / `processing` / 其他 | `sleep $POLL_INTERVAL`，继续轮询 |
| 累计超过 `$TIMEOUT_MINUTES` 分钟 | 超时退出：`⚠️ 等待超时（${TIMEOUT_MINUTES}分钟），请手动检查部署状态` |

**提取部署详情链接：**

```bash
# Cargo 部署返回 StackUrl
STACK_URL=$(echo "$STATUS_OUTPUT" | jq -r '.Data.Result.Data.StackUrl // empty')
# 如果 StackUrl 为空，尝试 JobUrl（Plus 模式兼容）
JOB_URL=$(echo "$STATUS_OUTPUT" | jq -r '.Data.Result.Data.JobUrl // empty')
DEPLOY_URL="${STACK_URL:-$JOB_URL}"
```

输出：
```
⏳ [3/3] 等待部署完成...
   🔄 [00:30] 当前状态：pending，继续等待...
   🔄 [01:00] 当前状态：processing，继续等待...
   ✅ [01:30] 部署成功！
（或）
   ❌ [02:00] 部署失败 → 进入自动诊断...
（或）
   ⚠️ [10:00] 等待超时，请手动检查部署状态
```

详细的 API 说明请参考 [references/deploy/deploy_api_reference.md](references/deploy/deploy_api_reference.md)。

---

### Step 3b：自动诊断 + 重试（失败后自动触发，用户无感）

当 Step 3 轮询到 `failed` 状态时，**不报错退出**，而是自动进入诊断+重试流程。

**⚠️ 此步骤对用户完全透明，用户只看到最终结果。**

```bash
# 部署失败后，自动调用诊断+重试脚本
DIAG_RESULT=$("$SKILL_DIR/scripts/deploy/diagnose_and_retry.sh" \
  "$CARGO_STACK_UUID" \
  "$APPKEY" \
  "$RELEASE_NAME" \
  "$LABEL" \
  "$TEMPLATE_NAME" \
  1 \
  2>&1)

DIAG_SUCCESS=$(echo "$DIAG_RESULT" | jq -r '.success // false')
```

**诊断+重试脚本内部流程：**

1. **获取状态** — 调用 `cargo-cli stack status` 获取 runner 状态和 `runnerUUID`
2. **AI 诊断** — 如果有 `runnerUUID`，调用 `cargo-cli stack deploy-diagnose`（Cargo AI 特征诊断）
3. **深度日志** — AI 诊断无命中时，尝试 `deploy-log-list` → `deploy-log-read` 读取机器日志
4. **决策重试策略** — 根据诊断结果自动选择：
   - 分支不存在 → 不重试，提示推送分支
   - 构建缓存/编译问题 → 加 `--force` 强制重新构建
   - 资源/机器问题 → 等待 30 秒后重试
   - 其他 → 直接重试
5. **执行重试** — 调用 `cargo-cli stack deploy` 重新触发部署
6. **等待完成** — 轮询直到 running/failed/超时

**重试成功 → 继续进入「完成」步骤；重试失败 → 输出诊断信息后退出。**

输出（仅内部可见，成功时用户只看到最终摘要）：
```
🔧 [3b] 自动诊断+重试...
   📊 诊断中（AI 诊断 + 日志分析）...
   📋 诊断结果：构建缓存问题
   🔄 使用 --force 强制重新构建...
   ⏳ 等待重试部署完成...
   ✅ 重试成功！
（或）
   ❌ 重试后仍然失败：<诊断原因>
```

---

### 完成

```bash
WORKER_END_TIME=$(date +%s)
WORKER_ELAPSED=$((WORKER_END_TIME - WORKER_START_TIME))
WORKER_MINUTES=$((WORKER_ELAPSED / 60))
WORKER_SECONDS=$((WORKER_ELAPSED % 60))
```

**更新持久化状态：**

```bash
cat > "$PROJECT_ROOT/.worker/deploy-state.json" << EOF
{
  "job_id": "$JOB_ID",
  "swimlane": "$SWIMLANE",
  "branch": "$CURRENT_BRANCH",
  "commit_sha": "$COMMIT_SHA",
  "deploy_time": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
  "deploy_status": "success",
  "deploy_url": "$DEPLOY_URL"
}
EOF
```

**更新配置文件中的 swimlane（如果是新创建的泳道）：**

如果配置中 `swimlane` 原本为空，将新创建的泳道名写回 `deploy.json`，便于下次复用：

```bash
ORIGINAL_SWIMLANE=$(echo "$CONFIG" | jq -r '.swimlane // ""')
if [ -z "$ORIGINAL_SWIMLANE" ] && [ -n "$SWIMLANE" ]; then
  echo "$CONFIG" | jq --arg sw "$SWIMLANE" '.swimlane = $sw' > "$CONFIG_FILE"
fi
```

**输出执行摘要：**

```
🎉 [worker-deploy] 执行完成！
   ⏱️  总耗时：${WORKER_MINUTES}m ${WORKER_SECONDS}s

📋 执行摘要：
   [1] Git 提交 → <commit_msg>
   [2] Cargo 部署 → 任务 <job_id>
   [3] 等待完成 → ✅ 部署成功

## 🚀 泳道：$SWIMLANE

| 链接 | 地址 |
|------|------|
| Cargo 泳道 | $DEPLOY_URL |
| 分支 | $CURRENT_BRANCH |
| Commit | $COMMIT_SHA |
```

---

## ARGUMENTS

用户调用格式：

**命令模式：**
```
/worker-deploy                              # 全流程（Git → 部署 → 等待）
/worker-deploy --only=git                   # 只执行 Git 提交推送
/worker-deploy --only=deploy                # 只触发部署（跳过 Git）
/worker-deploy --only=wait                  # 只等待部署完成
/worker-deploy --list-steps                 # 查看所有步骤
```

**自然语言模式：**
```
我在 /Users/xxx/IdeaProjects/giantcps 仓库里的 feature/my-branch 分支上写了版代码，帮我部署一下
帮我把 feature/xxx 分支部署到测试环境
代码写好了，部署一下
把当前分支部到泳道
deploy my branch
帮我部署 giantcps 项目
```

自然语言模式下，AI 从用户消息中提取仓库路径、分支名、泳道名，自动切换到对应仓库和分支，自动生成配置（如不存在），然后执行全流程。

**解析规则：**
- `--list-steps` → 输出步骤列表后立即退出
- `--only=<step>` → 只执行指定步骤
- 无参数 → 全流程（Step 1 → Step 2 → Step 3）

**`--list-steps` 输出：**

| Step | Code | 说明 |
|------|------|------|
| 1 | git | Git 提交推送 |
| 2 | deploy | 触发 Cargo 泳道部署 |
| 3 | wait | 等待部署完成 |

用法示例：
```
/worker-deploy                    # 全流程
/worker-deploy --only=git         # 只提交 Git
/worker-deploy --only=deploy      # 只触发部署（适用于已提交但需要重新部署）
/worker-deploy --only=wait        # 只等待（适用于部署已触发但需要重新等待）
```

ARGUMENTS: <此处由调用者传入实际参数>

---

## 与其他 skill 的集成

### 被 worker-java 调用

后续 worker-java 可在 Step 5~6~10 处调用本 skill，替代原有的 `cargo-cli` 链路：

```
worker-java Step 5 (Git 提交)   → worker-deploy Step 1 (git)
worker-java Step 6 (Cargo 部署) → worker-deploy Step 2 (deploy)
worker-java Step 10 (等待部署)  → worker-deploy Step 3 (wait)
```

### 配置迁移

如果已有 ee-plus 的 `deploy-config.json`，可快速迁移为 worker-deploy 的配置：

```bash
# 从 ee-plus 配置生成 worker-deploy 配置
EE_CONFIG=".claude/skills/ee-plus/deploy-config.json"
if [ -f "$EE_CONFIG" ]; then
  DEPLOY_TYPE=$(jq -r '.deploy_type' "$EE_CONFIG")
  if [ "$DEPLOY_TYPE" = "cargo" ]; then
    jq '{
      deploy_type: .deploy_type,
      release: .release,
      label: (.label // ""),
      label_type: (.label_type // "branch"),
      swimlane: (.swimlane // ""),
      deploy: { pollIntervalSeconds: 30, timeoutMinutes: 10 },
      git: { autoCommit: true, commitMessagePrefix: "feat" }
    }' "$EE_CONFIG" > "$PROJECT_ROOT/.worker/deploy.json"
  fi
fi
```
