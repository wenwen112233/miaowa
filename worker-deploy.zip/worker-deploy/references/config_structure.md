# Deploy-Config.json 配置结构详解

本文档详细说明 `deploy-config.json` 配置文件的完整结构，帮助大模型和用户理解每个字段的含义和用法。

## 目录

1. [概述](#概述)
2. [配置文件结构](#配置文件结构)
3. [字段详解](#字段详解)
4. [示例](#示例)
5. [验证规则](#验证规则)
6. [与部署流程的关系](#与部署流程的关系)

## 概述

`deploy-config.json` 是部署管理 skill 的核心配置文件，存放在项目根目录。它记录了：
- 部署类型（plus 或 cargo）
- 项目和发布项信息
- 部署模版信息
- 要部署的代码版本（分支或 tag）
- 灰度部署相关信息（机器分组等）

通过这个配置文件，部署 skill 可以快速启动部署流程，而不需要用户重复输入信息。

## 配置文件结构

### 完整的 JSON Schema

```json
{
  "deploy_type": string,
  "release": [
    {
      "release_id": number,
      "release_name": string,
      "appkey": string (optional),
      "template": {
        "id": number,
        "name": string,
        "env": string
      },
      "hostRule": {
        "id": number,
        "name": string
      }
    }
  ],
  "label": string,
  "label_type": string,
  "swimlane": string (optional)
}
```

### JSON 结构树

```
deploy-config.json
├── deploy_type [字符串]
├── release [数组]
│   └── [0]
│       ├── release_id [数字]
│       ├── release_name [字符串]
│       ├── appkey [字符串] (可选)
│       └── template [对象]
│           ├── id [数字]
│           ├── name [字符串]
│           └── env [字符串]
│       └── hostRule [对象] (可选)
│           ├── id [数字] (可选)
│           └── name [字符串] (可选)
├── label [字符串]
├── label_type [字符串]
└── swimlane [字符串] (可选)
```

## 字段详解

### 顶层字段

#### deploy_type

**类型**: 字符串 (string)  
**必需**: ✓ 是  
**描述**: 部署类型，指定使用的部署系统  
**允许的值**:
- `plus` - Plus 部署系统
- `cargo` - Cargo 部署系统

**示例**: `"plus"` 或 `"cargo"`  
**用途**: 区分不同的部署系统，两种类型的 API 接口相同，但参数构造略有不同  

---

#### release

**类型**: 数组 (array)  
**必需**: ✓ 是  
**描述**: 包含一个或多个发布项信息的数组，每个发布项包含其对应的部署模版  
**备注**: 虽然是数组格式，当前通常只包含一个发布项  

**数组元素结构**:

##### release[].release_id

**类型**: 数字 (number)  
**必需**: ✓ 是  
**描述**: 发布项的唯一标识符，从发布平台获取  
**示例**: `12345`  
**来源**: 通过 release-info skill 获取  

---

##### release[].release_name

**类型**: 字符串 (string)  
**必需**: ✓ 是  
**描述**: 发布项的可读名称，用于标识和展示  
**示例**: `"我的微服务项目"` 或 `"mobile-app"`  
**来源**: 通过 release-info skill 获取  

---

##### release[].appkey

**类型**: 字符串 (string)  
**必需**: ✗ 否（可选）  
**描述**: 应用的唯一标识符，用于某些部署平台的权限验证  
**示例**: `"com.example.myproject"` 或 `"com.sankuai.stafftraining.demo"`  
**用途**: Cargo 部署系统需要 appkey 来验证权限，Plus 部署系统可选  
**来源**: 通过 release-info skill 获取，或从应用管理平台获取  

---

##### release[].template

**类型**: 对象 (object)  
**必需**: ✓ 是  
**描述**: 包含部署模版的所有必要信息  

**包含的子字段**:

##### release[].template.id

**类型**: 数字 (number)  
**必需**: ✓ 是  
**描述**: 部署模版的唯一标识符  
**示例**: `101`、`205`  
**来源**: 通过 release-info skill 的 `fetch_templates.sh` 获取  
**作用**: 在部署执行时指定要使用的模版  

---

##### release[].template.name

**类型**: 字符串 (string)  
**必需**: ✓ 是  
**描述**: 部署模版的可读名称，便于理解模版的用途  
**示例**: 
- `"生产环境部署"`
- `"测试环境 - 灰度发布"`
- `"开发环境单机部署"`  

**用途**: 在部署前确认和展示时使用  
**备注**: Cargo 部署系统中，此字段也会作为 Template 参数传递给 API  

---

##### release[].template.env

**类型**: 字符串 (string)  
**必需**: ✓ 是  
**描述**: 部署环境标识  
**允许的值**:
- `prod` - 生产环境
- `staging` - 灰度/预发布环境
- `test` - 测试环境
- `dev` - 开发环境
- `beta` - Beta 环境

**示例**: `"prod"`、`"test"`  
**用途**: 用于部署时的环境确认和权限检查  

---

##### release[].hostRule

**类型**: 对象 (object)
**必需**: ✗ 否（可选）
**描述**: 机器分组信息，指定部署到哪些机器

**子字段**:

###### release[].hostRule.id

**类型**: 数字 (number)
**必需**: ✗ 否（可选）
**描述**: 机器分组的唯一标识符
**特殊值**: `-1` 表示使用推荐分组
**示例**: `-1`、`12345`
**来源**: 通过灰度部署 API 获取机器分组列表
**用途**: 在灰度部署时指定目标机器组

---

###### release[].hostRule.name

**类型**: 字符串 (string)
**必需**: ✗ 否（可选）
**描述**: 机器分组的可读名称
**示例**: `"推荐分组"`、`"灰度机器组1"`
**用途**: 展示和确认部署目标

#### label

**类型**: 字符串 (string)  
**必需**: ✓ 是  
**描述**: 要部署的代码版本标签，可以是分支名或 tag 名  
**示例**:
- 分支名: `"main"`、`"develop"`、`"feature/new-api"`
- Tag 名: `"v2.1.0"`、`"v2.0.1"`、`"release-2026-02-05"`

**关联字段**: `label_type` 指定了这个值的含义  
**用途**: 指定要部署的具体代码版本  

---

#### label_type

**类型**: 字符串 (string)  
**必需**: ✓ 是  
**描述**: 指定 `label` 字段的类型  
**允许的值**:
- `branch` - label 是 git 分支名
- `tag` - label 是 git tag 名
- `commit` - label 是 git commit SHA

**示例**:
- `"branch"` - 当 label 是 `"main"` 或 `"develop"` 时
- `"tag"` - 当 label 是 `"v2.1.0"` 时
- `"commit"` - 当 label 是 `"c0534485ba3e1c0be95fa4b8ab0007c7191d3b24"` 时

**用途**: 部署系统根据这个值对 label 进行不同的处理  

---

#### swimlane

**类型**: 字符串 (string)  
**必需**: ✗ 否（可选）  
**描述**: 泳道标识符，用于指定部署的 ProjectID。如果用户指定了泳道，则使用指定的泳道进行部署  
**示例**: `"my-swimlane-123"` 或 `"feature-test-env"`  
**用途**: 
- Cargo 部署中，作为 ProjectID 传递给 API
- 部署完成后，实际的 project_id 会写回到配置中
- 支持用户自定义泳道环境

**来源**: 用户指定或从之前的部署结果中获取  
**备注**: 如果不指定，部署系统会使用默认的 ProjectID  

---

## 示例

### 示例 1：Plus 部署 - 使用 main 分支部署到生产环境

```json
{
  "deploy_type": "plus",
  "release": [
    {
      "release_id": 12345,
      "release_name": "电商平台 - 支付服务",
      "appkey": "com.meituan.payment",
      "template": {
        "id": 101,
        "name": "生产环境部署",
        "env": "prod"
      }
    }
  ],
  "label": "main",
  "label_type": "branch"
}
```

**说明**:
- 使用 Plus 部署系统
- 使用 main 分支的最新代码
- 部署到生产环境
- 使用模版 101（生产环境部署）

---

### 示例 2：Plus 部署 - 使用 tag 部署到生产环境（灰度发布）

```json
{
  "deploy_type": "plus",
  "release": [
    {
      "release_id": 12345,
      "release_name": "电商平台 - 支付服务",
      "appkey": "com.meituan.payment",
      "template": {
        "id": 103,
        "name": "生产环境灰度发布",
        "env": "staging"
      }
    }
  ],
  "label": "v2.1.0",
  "label_type": "tag"
}
```

**说明**:
- 使用 Plus 部署系统
- 使用特定的 tag（v2.1.0）代码
- 部署到 staging 环境（灰度环境）
- 使用模版 103（灰度发布模版）

---

### 示例 3：Cargo 部署 - 使用 commit 部署到测试环境（带泳道）

```json
{
  "deploy_type": "cargo",
  "release": [
    {
      "release_id": 178014,
      "release_name": "员工培训 - Demo 服务",
      "appkey": "com.sankuai.stafftraining.songhuayang.demo",
      "template": {
        "id": 1001,
        "name": "test",
        "env": "test"
      }
    }
  ],
  "label": "c0534485ba3e1c0be95fa4b8ab0007c7191d3b24",
  "label_type": "commit",
  "swimlane": "songhuayang-5e05f"
}
```

**说明**:
- 使用 Cargo 部署系统
- 使用特定的 commit SHA 代码
- 部署到测试环境
- 使用模版 test
- Cargo 部署需要 appkey 字段
- 指定泳道 `songhuayang-5e05f` 作为 ProjectID

---

### 示例 4：Plus 部署 - 使用 develop 分支部署到测试环境

```json
{
  "deploy_type": "plus",
  "release": [
    {
      "release_id": 12345,
      "release_name": "电商平台 - 支付服务",
      "appkey": "com.meituan.payment",
      "template": {
        "id": 102,
        "name": "测试环境部署",
        "env": "test"
      }
    }
  ],
  "label": "develop",
  "label_type": "branch"
}
```

**说明**:
- 使用 Plus 部署系统
- 使用 develop 分支的最新代码
- 部署到测试环境
- 使用模版 102（测试环境部署）

---

### 示例 5：：Plus 灰度发布 - 使用 master 部署到生产环境（灰度发布）

```json
{
  "deploy_type": "plus",
  "release": [
    {
      "release_id": 12345,
      "release_name": "电商平台 - 支付服务",
      "appkey": "com.meituan.payment",
      "template": {
        "id": 101,
        "name": "生产环境部署",
        "env": "prod"
      },
      "hostRule": {
        "id": -1,
        "name": "推荐分组"
     }
    }
  ],
  "label": "main",
  "label_type": "branch"
}
```

**说明**:
- 使用 Plus 部署系统
- 使用 main 分支的最新代码
- 部署到生产环境
- 使用模版 101（生产环境部署）
- 使用机器分组-1 (推荐分组)

---

### 示例 6：Plus 灰度发布 - 使用 tag 部署到生产环境（灰度发布）

```json
{
  "deploy_type": "plus",
  "release": [
    {
      "release_id": 12345,
      "release_name": "电商平台 - 支付服务",
      "appkey": "com.meituan.payment",
      "template": {
        "id": 103,
        "name": "生产环境灰度发布",
        "env": "staging"
      },
      "hostRule": {
        "id": 123,
        "name": "staging全量"
      }
    }
  ],
  "label": "v2.1.0",
  "label_type": "tag"
}
```

**说明**:
- 使用 Plus 部署系统
- 使用特定的 tag（v2.1.0）代码
- 部署到 staging 环境（灰度环境）
- 使用模版 103（灰度发布模版）
- 使用机器分组 123（staging全量）

---

## 验证规则

部署系统会对配置文件进行以下验证：

### 必需字段检查

| 字段 | 类型 | 必需 | 备注 |
|------|------|:----:|------|
| deploy_type | 字符串 | ✓ | 必须是 'plus' 或 'cargo' |
| release | 数组 | ✓ | 至少包含一个发布项 |
| release[].release_id | 数字 | ✓ | 必须是数字 |
| release[].release_name | 字符串 | ✓ | 不能为空 |
| release[].template | 对象 | ✓ | 必须包含三个子字段 |
| release[].template.id | 数字 | ✓ | 必须是数字 |
| release[].template.name | 字符串 | ✓ | 不能为空 |
| release[].template.env | 字符串 | ✓ | 必须是允许的值之一 |
| label | 字符串 | ✓ | 不能为空 |
| label_type | 字符串 | ✓ | 必须是 'branch'、'tag' 或 'commit' |
| release[].appkey | 字符串 | ✗ | Cargo 部署必需，Plus 部署可选 |

### 值的有效性检查

**deploy_type 允许的值**:
```
- plus (Plus 部署系统)
- cargo (Cargo 部署系统)
```

**release[].template.env 允许的值**:
```
- prod (生产环境)
- staging (灰度环境)
- test (测试环境)
- dev (开发环境)
- beta (Beta 环境)
```

**label_type 允许的值**:
```
- branch (git 分支) - Plus 和 Cargo 都支持
- tag (git tag) - Plus 和 Cargo 都支持
- commit (git commit SHA) - Cargo 部署专用
```

### 验证过程

1. **JSON 格式检查** - 确保文件是有效的 JSON
2. **必需字段检查** - 检查所有必需字段是否存在
3. **字段类型检查** - 检查每个字段的数据类型
4. **值的有效性检查** - 检查字段值是否在允许的范围内
5. **一致性检查** - 检查字段之间的逻辑关系

---

## 与部署流程的关系

### 配置在部署流程中的作用

```
流程决策：

1. 检查配置文件
   │
   ├─ 配置完整 ✓
   │  ├─ 使用配置中的 label 和 label_type
   │  └─ 跳过获取当前分支
   │
   └─ 配置不完整或不存在 ✗
      ├─ 调用 release-info skill
      ├─ 让用户选择模版
      ├─ 获取当前分支（作为默认 label）
      └─ 构建部署参数

2. 部署参数确认
   ├─ 展示 release_name 和 release_id
   ├─ 展示 template.name, template.id 和 template.env
   ├─ 展示 label 和 label_type
   │  ├─ label 来自配置（优先）或当前分支
   │  └─ label_type 来自配置（优先）或默认为 'branch'
   └─ 等待用户确认

3. 执行部署
   ├─ 传递 release_id
   ├─ 传递 template.id
   ├─ 传递 label（无需再查询分支）
   └─ 执行部署命令
```

**关键点**：
- 配置中的 `label` 和 `label_type` 是最终的部署值
- 如果配置中有 label，**不需要查询 git 分支**
- 获取当前分支仅在配置缺失 label 时才进行

### 配置更新流程

```
场景: 用户想使用不同的模版

1. 读取现有配置
2. 调用 release-info skill 获取新的模版列表
3. 用户选择新模版
4. 更新配置文件中的 template 字段
5. 重新执行部署
```

---

## 常见配置问题

### Q1: 为什么要分离 template 为对象？

**答**: 这样做有几个优势：
- **结构清晰** - 部署模版的信息聚合在一起
- **易于扩展** - 可以轻松添加更多模版相关的字段
- **大模型友好** - 结构化的数据更容易被大模型理解和处理

### Q2: label 和 label_type 为什么要分开？

**答**: 分开的好处：
- **类型明确** - 部署系统知道如何处理这个 label
- **验证更严格** - 可以验证 label_type 的有效性
- **错误检查** - 防止混淆分支和 tag

### Q3: 什么时候应该使用 branch vs tag？

**答**:
- **使用 branch**:
  - 部署开发/测试版本
  - 需要最新代码时
  - 持续部署到测试环境

- **使用 tag**:
  - 部署生产版本
  - 需要可重复的版本
  - 灰度发布前创建 tag

---

## 配置文件的生成方式

### 方式 1：手动创建

复制示例，填入你的信息：
```json
{
  "release_id": YOUR_ID,
  "release_name": "YOUR_NAME",
  "template": {
    "id": TEMPLATE_ID,
    "name": "TEMPLATE_NAME",
    "env": "prod"
  },
  "label": "main",
  "label_type": "branch"
}
```

### 方式 2：通过部署 Skill 创建

用户在没有配置文件时运行部署，Skill 会：
1. 调用 release-info skill 获取信息
2. 让用户选择模版
3. 自动生成配置文件

### 方式 3：从发布平台导出

某些发布平台可能提供配置导出功能。

---

## 配置版本管理

### 建议做法

1. **保存到 git** - 将 `deploy-config.json` 加入版本控制
2. **文档更新** - 当配置改变时，记录原因
3. **多配置** - 可以维护多个配置：
   - `deploy-config.prod.json` - 生产环境
   - `deploy-config.test.json` - 测试环境
   - `deploy-config.json` - 默认配置

---

## 与大模型的交互

当大模型处理部署请求时，它应该：

1. **理解配置结构** - 知道配置的完整结构
2. **验证配置** - 使用 validate_config.sh 检查配置完整性
3. **提取信息** - 使用 read_config.sh 获取配置数据
4. **展示参数** - 清晰地展示所有配置信息给用户
5. **等待确认** - 部署前必须等待用户确认

---

## 总结

`deploy-config.json` 的设计目标是：
- ✅ **结构清晰** - 每个字段有明确含义
- ✅ **大模型友好** - 易于被 AI 理解和处理
- ✅ **易于验证** - 严格的验证规则防止错误
- ✅ **可扩展** - 方便未来添加新字段
- ✅ **安全** - 部署前必须用户确认

通过理解这个配置结构，大模型可以更有效地帮助用户完成部署任务。
