# 发布项信息管理

获取和缓存发布项的基本信息和部署模版。

## 核心功能

1. **获取发布项信息** - 基于仓库地址、发布项名称或ID获取发布项基本信息和部署模版（ID、名称、AppKey、仓库地址、模版列表）
2. **智能缓存** - 本地缓存机制，减少重复查询

## 设计原则

**脚本自动管理缓存**：
- **脚本**：负责请求 API、自动更新本地缓存、输出 JSON 数据到 stdout，调试信息输出到 stderr
- **大模型**：负责决定是否需要更新数据、调用脚本、解析输出、向用户展示信息

脚本自动处理缓存更新，大模型只需要决定何时读取缓存或调用脚本。

## 工作流程

### 1. 获取发布项信息和部署模版

**脚本**：`.claude/skills/ee-plus/scripts/release/fetch_release_info.sh`

**用法**：
```bash
# 方式 1: 在 git 仓库目录中运行，自动获取仓库地址
.claude/skills/ee-plus/scripts/release/fetch_release_info.sh

# 方式 2: 手动指定仓库地址
.claude/skills/ee-plus/scripts/release/fetch_release_info.sh <repository_url>

# 方式 3: 根据发布项名称获取
.claude/skills/ee-plus/scripts/release/fetch_release_info.sh --name <release_name>

# 方式 4: 根据发布项 ID 获取
.claude/skills/ee-plus/scripts/release/fetch_release_info.sh --id <release_id>
```

**脚本行为**：
1. 支持三种查询模式：
   - **仓库地址模式**（默认）：如果未提供参数，尝试从当前目录的 git 仓库获取 `origin` 远程地址；或手动指定仓库地址
   - **名称模式**：使用 `--name` 标志，先调用 API 获取发布项ID
   - **ID模式**：使用 `--id` 标志，直接使用提供的ID
2. 根据发布项ID调用 API 获取完整的发布项信息和部署模版列表
3. **自动更新两个缓存**：
   - **发布项缓存** - `.claude/skills/ee-plus/.cache/release-info/releases.json`
     - 根据发布项ID检查缓存是否已存在
     - 如果存在，则更新该项信息
     - 如果不存在，则在末尾追加新发布项
   - **部署模版缓存** - `.claude/skills/ee-plus/.cache/release-info/releases/{release_id}/templates.json`
     - 对每个发布项，从返回的数据中提取模版信息
     - 更新或追加模版到对应发布项的缓存文件
4. 输出更新后的发布项缓存文件内容到 stdout，调试信息输出到 stderr

**输出格式**：
```json
{
  "releases": [
    {
      "repository": "git@git.example.com:team/project.git",
      "release_id": 12345,
      "release_name": "项目发布项",
      "appkey": "com.example.project",
      "last_updated": "2026-02-04T10:00:00Z"
    }
  ]
}
```

**大模型职责**：
1. **检查本地缓存**：读取 `.claude/skills/ee-plus/.cache/release-info/releases.json`，查找对应仓库的发布项信息
2. **决策**：
   - 如果缓存文件存在且包含该仓库的信息，且用户未要求更新 → 直接使用缓存数据
   - 如果缓存文件不存在、不包含该仓库信息，或用户要求更新 → 运行脚本
3. **运行脚本**（如需要）：执行 `.claude/skills/ee-plus/scripts/release/fetch_release_info.sh`
   - 脚本会自动更新发布项缓存和模版缓存
   - 脚本返回更新后的发布项缓存文件内容
4. **展示信息**：向用户展示发布项信息和模版列表

**示例对话**：
```
用户: "获取当前仓库的发布项信息"

大模型行为:
1. 读取 .claude/skills/ee-plus/.cache/release-info/releases.json
2. 在数组中查找当前仓库的信息
3. 如果没有找到，运行: .claude/skills/ee-plus/scripts/release/fetch_release_info.sh
   - 脚本自动更新发布项和模版缓存
4. 向用户展示:

发布项信息：
- 仓库: git@git.example.com:team/project.git
- 发布项 ID: 12345
- 发布项名称: 项目发布项
- AppKey: com.example.project

可用部署模版（共 3 个）：
1. [ID: 101] 生产环境部署 (环境: prod)
2. [ID: 102] 测试环境部署 (环境: test)
3. [ID: 103] 灰度发布 (环境: staging)
```

**releases.json 文件格式**：
```json
{
  "releases": [
    {
      "repository": "git@git.example.com:team/project1.git",
      "release_id": 12345,
      "release_name": "项目1发布项",
      "appkey": "com.example.project1",
      "last_updated": "2026-02-04T10:00:00Z"
    },
    {
      "repository": "git@git.example.com:team/project2.git",
      "release_id": 67890,
      "release_name": "项目2发布项",
      "appkey": "com.example.project2",
      "last_updated": "2026-02-04T11:00:00Z"
    }
  ]
}
```

**缓存更新**：
- 脚本自动更新 `.claude/skills/ee-plus/.cache/release-info/releases.json`
- 更新方式：根据发布项ID匹配
  - 如果缓存中已存在该ID的发布项，则更新其信息
  - 如果缓存中不存在该ID的发布项，则在末尾追加新条目
- 其他已存在的发布项信息保持不变
- 大模型无需手动管理缓存文件

## 典型使用场景

### 场景 1: 用户在 git 仓库中直接请求

```
用户: "获取发布项信息"
```

大模型执行：
1. 检查本地缓存
2. 如无缓存，运行 `.claude/skills/ee-plus/scripts/release/fetch_release_info.sh`（无参数，自动从 git 获取仓库地址）
   - 脚本自动更新缓存
3. 展示结果

### 场景 2: 用户指定仓库地址

```
用户: "获取 git@git.example.com:team/another-project.git 的发布项信息"
```

大模型执行：
1. 检查缓存
2. 如无缓存，运行 `.claude/skills/ee-plus/scripts/release/fetch_release_info.sh git@git.example.com:team/another-project.git`
   - 脚本自动更新缓存
3. 展示结果

### 场景 2b: 用户按发布项名称查询

```
用户: "获取 '项目发布项' 的信息"
```

大模型执行：
1. 运行 `.claude/skills/ee-plus/scripts/release/fetch_release_info.sh --name '项目发布项'`
   - 脚本先调用 API 获取发布项ID
   - 再根据ID获取完整信息
   - 自动更新缓存
2. 展示结果

### 场景 2c: 用户按发布项ID查询

```
用户: "获取发布项 12345 的信息"
```

大模型执行：
1. 运行 `.claude/skills/ee-plus/scripts/release/fetch_release_info.sh --id 12345`
   - 脚本直接根据ID获取完整信息
   - 自动更新缓存
2. 展示结果

### 场景 3: 用户要求更新缓存

```
用户: "更新一下发布项信息"
```

大模型执行：
1. 直接运行脚本（跳过缓存检查）
   - 脚本自动更新发布项和模版缓存
2. 展示最新信息

### 场景 4: 其他 skill 自动调用

当 deploy 等其他 skill 需要发布项数据时：
1. 自动调用此 skill 获取数据
2. 优先使用缓存
3. 将数据传递给调用方

## 缓存管理指南

### 缓存目录结构

```
.claude/skills/ee-plus/.cache/release-info/
├── releases.json                   # 所有发布项信息（统一文件）
└── releases/
    └── <release_id>/
        └── templates.json          # 部署模版列表
```

**releases.json 文件说明**：
- 包含所有仓库的发布项信息
- 使用数组存储，每个元素是一个发布项
- 通过 `repository` 字段唯一标识每个发布项
- 由脚本自动维护（添加新条目、更新已存在条目）

### 缓存策略

**默认行为**：
- 优先读取本地缓存
- 向用户展示缓存数据（如果存在）

**触发脚本执行**：
- 缓存文件不存在或不包含该仓库信息
- 用户明确说"更新"、"刷新"、"重新获取"
- 其他 skill 请求最新数据

**缓存自动更新规则**：

✅ **脚本自动更新缓存的情况**：
1. 获取发布项信息 - 自动更新 `releases.json` 和 `releases/${RELEASE_ID}/templates.json`
   - 根据发布项ID匹配：存在则更新，不存在则追加
   - 同时自动更新发布项的部署模版缓存

❌ **脚本不更新缓存的情况**：
1. 脚本执行失败或返回错误

**缓存标识**：
- 发布项信息：所有仓库统一存储在 `releases.json`，通过 `release_id` 字段唯一标识
- 部署模版：使用 `release_id` 作为目录名，存储在 `releases/${RELEASE_ID}/templates.json`，通过 `template_id` 字段唯一标识每个模版

### 读取缓存示例

大模型只需要读取缓存，不需要手动更新。

**读取发布项信息缓存**：
```bash
CACHE_FILE=".claude/skills/ee-plus/.cache/release-info/releases.json"
REPO=$(git remote get-url origin)

# 查找特定仓库的信息
cat "$CACHE_FILE" | jq ".releases[] | select(.repository == \"$REPO\")"
```

**读取模版列表缓存**：
```bash
RELEASE_ID=187194
CACHE_FILE=".claude/skills/ee-plus/.cache/release-info/releases/${RELEASE_ID}/templates.json"

# 读取所有模版
cat "$CACHE_FILE" | jq '.templates'

# 查找 prod 环境模版
cat "$CACHE_FILE" | jq '.templates[] | select(.environment_name == "prod")'

# 查找 test 或 staging 环境的模版
cat "$CACHE_FILE" | jq '.templates[] | select(.environment_name == "test" or .environment_name == "staging")'
```

## 脚本配置

所有脚本共享 `.claude/skills/ee-plus/scripts/release/release-common.sh` 配置文件。

**关键配置**：
```bash
API_HOST="http://plus.sankuai.com"
```

**公共函数**：
- `generate_mws_signature()` - 生成 MWS 鉴权签名（如需要）
- `get_env_name()` - 环境 ID 到名称的映射
- `get_repository_from_git()` - 从 git 获取仓库地址

## 脚本输出规范

所有脚本遵循以下输出规范：

1. **JSON 数据输出到 stdout**：便于大模型解析和重定向到缓存文件
2. **调试信息输出到 stderr**：不影响 JSON 数据的捕获
3. **错误信息输出到 stderr**：配合非零退出码
4. **退出码**：
   - `0`: 成功
   - `1`: 参数错误或 API 错误
   - `2`: 未找到数据

大模型可以轻松捕获 JSON 输出：
```bash
# 捕获 JSON 数据，调试信息仍显示在终端
JSON_OUTPUT=$(.claude/skills/ee-plus/scripts/release/fetch_release_info.sh)
```

## 注意事项

1. **缓存自动管理**：脚本会自动更新缓存，大模型只需要读取缓存或调用脚本

2. **脚本输出格式**：所有脚本都输出标准 JSON 格式，便于大模型解析

3. **错误处理**：脚本遇到错误会返回非零退出码，大模型应检查并向用户说明

4. **依赖工具**：脚本依赖 `curl`、`jq`、`git` 命令

5. **仓库地址识别**：支持 git 仓库自动识别和手动指定两种方式

6. **缓存失效**：当前无自动过期机制，建议在关键操作前提示用户是否需要更新

7. **一体化设计**：发布项和模版信息由单个脚本 `fetch_release_info.sh` 统一管理，调用一次获取两类数据

## 参考文档

详细的缓存数据结构和 API 响应格式请参考 [cache_structure.md](../cache_structure.md)。
