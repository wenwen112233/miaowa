# 部署管理

## 部署方式说明

本 skill 支持两种部署方式：**Plus 部署** 和 **Cargo 部署**。

### 部署方式选择

- **Plus 部署**（默认）：适用于所有发布项的标准部署方式
- **Cargo 部署**：适用于所有发布项的泳道部署方式

**所有发布项都可以选择使用 Plus 或 Cargo 进行部署**，由用户根据实际需求自行选择：

1. **默认行为**：如果用户未明确指定部署方式，系统默认使用 **Plus 部署**
2. **用户指定**：如果用户在对话中明确要求使用 Cargo 部署（例如："使用 cargo 部署"），则采用 **Cargo 部署**
3. **配置优先**：如果现有的 `deploy-config.json` 中 `deploy_type` 为 `cargo`，则继续使用 **Cargo 部署**

### 两种部署方式的区别

| 特性 | Plus 部署 | Cargo 部署 |
|------|----------|-----------|
| **API 接口** | 相同 | 相同 |
| **支持的标签类型** | branch、tag | branch、tag、commit |
| **AppKey 要求** | 可选 | 必需 |
| **请求参数格式** | 使用 `plusTemplateId` | 使用 `appKeyList`，支持 `Branch`/`Tag`/`Commit` |
| **适用场景** | 通用部署 | 需要 泳道部署 或有 特殊要求 |

### 配置示例

**Plus 部署配置**：
```json
{
  "deploy_type": "plus",
  "release": [...],
  "label": "main",
  "label_type": "branch"
}
```

**Cargo 部署配置（使用分支）**：
```json
{
  "deploy_type": "cargo",
  "release": [...],
  "label": "main",
  "label_type": "branch"
}
```

**Cargo 部署配置（使用 commit）**：
```json
{
  "deploy_type": "cargo",
  "release": [...],
  "label": "c0534485ba3e1c0be95fa4b8ab0007c7191d3b24",
  "label_type": "commit"
}
```

---

## 工作流程

部署管理 skill 遵循以下完整的部署流程：

## 前置步骤

**先对 `scripts` 目录下所有脚本授予执行权限，⚠️ 跳过此步骤将导致脚本执行时报 "Permission denied" 错误。**：

```bash
chmod +x scripts/**/*.sh scripts/*.sh 2>/dev/null || chmod +x $(find scripts -name "*.sh")
```


### 第 1 步：读取配置

- **检查 `.claude/skills/ee-plus` 目录是否存在 `deploy-config.json` 文件**
- 如果存在且完整（包含所有必需字段），直接跳转到第 5 步（询问 MCM 变更计划）；MCM 步骤之后再进入第 6 步确认参数
- 如果不存在或不完整，进入第 2 步
- 备注：脚本会优先查找 skill 目录下的配置，其次查找项目根目录

### 第 2 步：获取发布项信息

- **使用 [release-info skill](../release/README.md) 获取发布项信息**
- 从当前 git 仓库自动获取仓库地址，或让用户指定
- 基于发布项 ID 获取所有可用的部署模版

### 第 3 步：用户选择部署模版

- **检查是否有 `AskQuestion` 工具**
  - 如果有 `AskQuestion` 工具：使用工具展示交互式部署模版列表
    - 模版 ID、名称、环境（prod/staging/test/dev/beta）作为可选项
    - 自动触发交互式单选问卷，用户可以直观地选择所需的模版
  - 如果没有 `AskQuestion` 工具：按表格形式展示部署模版列表给用户选择
- **基于用户选择获取对应的模版 ID、名称和环境信息**
- 保存用户选择（可选：保存到 `deploy-config.json`）

### 第 4 步：确定部署标签（分支或 tag）

- **如果配置中没有 label**，自动获取当前 git 分支名称和状态
- 如果配置中已有 label，直接使用配置中的值
- **检测未提交的变更**：
  - 如果当前分支有未提交的变更（modified 或 untracked），询问用户：
    - "检测到当前分支有未提交的变更，需要提交到临时分支部署吗？(Y/n)"
  - 如果用户确认（Y 或回车），执行临时分支提交流程
  - 如果用户拒绝（n），继续使用原分支进行部署
  - ⚠️ **重要**：**绝不能自动提交临时变更**，必须等待用户明确确认

### 第 5 步：询问 MCM 变更计划（基础参数确定后）⭐

> **⚠️ 前置依赖（必读）**：MCM 变更计划查询依赖于已确定的**部署环境**（`template.env`）与**部署标签**（`label` / `label_type`）。
> 因此本步骤**必须在第 1~4 步完成之后**执行——即已经确定：
> - 发布项 ID（`release_id`）
> - 部署模板 ID 与环境（`template.id` / `template.env`）
> - 部署标签与类型（`label` / `label_type`：branch / tag / commit）
>
> 如用户后续修改了**部署模板**或**部署标签**，须清空原 `changePlanId` 并重新查询，不得复用旧值。

**询问是否关联 MCM 变更计划 ID**（非强拦截，仅引导 + 二次提醒）：

可先调用 `scripts/gray/query_mcm_plans.sh` 按 `branch` / `tag` / `commit` 维度查询候选列表（依赖上面确定的 `label_type` 与 `label`，以及 `template.env` 推导的环境值）：

```bash
# 根据 label_type 选择查询维度
./scripts/gray/query_mcm_plans.sh "$appkey" --symbol-name "$label_type" --symbol-value "$label" --env "$environment"
```

- 若有候选列表（`plan_count > 0`）：展示候选计划，追加"手动输入"与"不关联"选项。
- 若无候选列表：简化为"手动输入 ID / 不关联"两项。

```
是否关联 MCM 变更计划 ID？
  1) 从候选列表选择（基于 label_type + label + env 查询）
  2) 手动输入 ID
  3) 不关联
```

- 选项 1/2：记录为纯数字 ID，后续通过 `--change-plan-id <id>` 传给 `submit_deploy_job.sh`，后端透传到上游 Plus `ThirdPlatformParams.mcm.planId`。
- 选项 3 且目标环境为 `prod` / `staging`：**必须**弹出警告并等待用户明确确认：

  ```
  ⚠️  未关联变更计划的线上发布存在变更管控风险，是否确认继续？(y/N)
  ```

- 取值校验：必须为纯数字；留空或省略则表示不关联（请勿传空字符串给脚本）。
- `deploy-config.json` 中也支持持久化该字段（字段名 `change_plan_id`，可选）；建议默认不写入配置，避免把某次变更计划误用于后续部署。

### 第 6 步：确认部署参数

- **向用户展示完整的部署参数，包括**：
  - 发布项名称和 ID
  - 部署模版名称、ID 和环境
  - 要部署的标签（分支名或 tag 名）
  - 标签类型（branch 或 tag）
  - MCM 变更计划 ID（未关联则显示"未关联"）
  - 任何其他相关配置
- **等待用户确认** - 只有用户明确确认，才能执行部署
- **优先使用用户指定参数** - 如果用户在对话中指定参数，则优先使用用户指定参数，而不是配置中的参数
- **调整回跳规则**：如用户在此处要求调整"部署模板"或"部署标签"，必须回到第 5 步**重新查询 MCM**（env / label 变化 ⇒ 候选列表与关联关系可能变化）。
- 用户可以取消部署

### 第 7 步：执行部署

- **一旦用户确认，立即触发部署**
  1. 执行 `execute_deploy.sh` 脚本（如 Step 5 选择关联变更计划，把 `--change-plan-id <id>` 一并透传）
  2. 获取并展示部署结果
  3. 如果遇到 SSOID 相关的报错，提示用户给 CatPaw 提 TT
  4. 如果返回"没有可用的机器"错误，提示用户可以尝试使用 Cargo 部署（详见下方"错误处理：无可用机器"）

### 第 8 步：保存配置

- **保存配置** - 保存或更新配置文件 `deploy-config.json` ，使用本次部署使用的参数

## 配置文件格式

### deploy-config.json

在 `.claude/skills/ee-plus` 目录下创建 `deploy-config.json` 文件可以跳过部分交互步骤。文件格式如下：

**Plus 部署配置示例**：
```json
{
  "deploy_type": "plus",
  "release": [
    {
      "release_id": 12345,
      "release_name": "项目名称",
      "appkey": "com.example.project",
      "template": {
        "id": 101,
        "name": "测试环境部署",
        "env": "test"
      }
    }
  ],
  "label": "main",
  "label_type": "branch"
}
```

**Cargo 部署配置示例（带泳道）**：
```json
{
  "deploy_type": "cargo",
  "release": [
    {
      "release_id": 178014,
      "release_name": "员工培训 - Demo 服务",
      "appkey": "com.sankuai.stafftraining.demo",
      "template": {
        "id": 1001,
        "name": "test",
        "env": "test"
      }
    }
  ],
  "label": "c0534485ba3e1c0be95fa4b8ab0007c7191d3b24",
  "label_type": "commit",
  "swimlane": "songhuayang-5e05f"
}
```

**顶层字段说明**：
- `deploy_type`：部署类型（必需）：`plus` 或 `cargo`
- `release`：发布项数组（必需），包含一个或多个发布项信息
- `label`：要部署的标签（分支名、tag 名或 commit SHA）（必需）
- `label_type`：标签类型（必需）：`branch`、`tag` 或 `commit`
- `swimlane`：泳道标识符/ProjectID（可选），用于指定部署的泳道环境

**release 数组元素字段**：
- `release_id`：发布项 ID（必需）
- `release_name`：发布项名称（必需）
- `appkey`：AppKey（Cargo 必需，Plus 可选）
- `template`：部署模版对象（必需）

**template 对象字段**：
- `id`：部署模版 ID（必需）
- `name`：部署模版名称（必需，Cargo 会将此值作为 Template 参数传递给 API）
- `env`：部署环境（必需）：`prod`、`staging`、`test`、`dev`、`beta`

**label 和 label_type 说明**：
- `label`：分支名（如 `main`）、tag 名（如 `v2.1.0`）或 commit SHA（如 `c0534485...`）
- `label_type`：
  - `branch` - 表示 label 是分支名（Plus 和 Cargo 都支持）
  - `tag` - 表示 label 是 tag 名（Plus 和 Cargo 都支持）
  - `commit` - 表示 label 是 commit SHA（Cargo 部署专用）

**配置优先级**：
- 如果 config 文件完整有效，直接使用
- 如果 config 文件缺少关键字段，提示用户补充或重新选择
- 如果 config 文件不存在或损坏，从头开始获取信息
- 如果 config 文件存在，但用户在对话中指定参数，则以用户指定为准
- 用户指定 > 配置文件 > 当前分支/默认值

详细的配置结构说明，请参考 `references/config_structure.md`。

## 使用场景与操作步骤

### 场景 1：已有 deploy-config.json 配置文件（快速部署）

**前提**：`.claude/skills/ee-plus` 目录下已存在完整的 `deploy-config.json`

**步骤**：

1. **用户请求**：
   ```
   用户说："部署"
   ```

2. **验证配置**：
   ```bash
   ./scripts/deploy/validate_config.sh ./deploy-config.json
   ```
   确认配置完整有效
   
3. **检查是否有未提交的变更**（即使配置中指定了 label）：
   ```bash
   ./scripts/deploy/get_current_branch.sh
   ```
   获取当前分支状态和未提交变更信息

4. **⚠️ 必须使用 `AskQuestion` 工具或表格询问用户是否创建临时分支**：
   
   **有 AskQuestion 工具时**（✅ 推荐）：
   ```javascript
   // 调用 AskQuestion 工具的伪代码
   AskQuestion({
     questions: [{
       id: "temp-branch-confirm",
       prompt: "检测到当前分支有未提交的变更，需要提交到临时分支部署吗？",
         { id: "yes", label: "是，提交到临时分支（推荐）" },
         { id: "yes", label: "是，提交到临时分支" },
         { id: "no", label: "否，直接使用配置的分支" }
       ]
     }]
   })
   ```
   **没有 AskQuestion 工具时**（✅ 备选）：
   - 按表格形式展示选项让用户输入
   
   **执行逻辑**（必须等待用户选择）：
   
   
   - **如果用户选择 "是" (yes)**：
     ```bash
     ./scripts/deploy/commit_to_temp_branch.sh
     ```
   - **⚠️ 不能自动选择或跳过此步骤** - 必须等待用户确认
     - 将变更提交到 `{current_branch}-temp` 临时分支并推送到远程
     - 更新部署标签为 `{current_branch}-temp`
   
   - **如果用户选择 "否" (no)**：
     - 继续使用配置中的 label 进行部署
   
   - **如果 label_type 为 tag**：直接跳过此步骤，使用配置中的 tag 部署

5. **展示参数确认**：
   展示以下参数给用户确认（如有变更，显示最新的部署标签）：
   - 发布项：{release_name} (ID: {release_id})
   - 模版：{template.name} (ID: {template.id}, 环境: {template.env})
   - 部署标签：{label} (type: {label_type})

6. **使用 `AskQuestion` 工具展示部署参数确认**：
   
   ```javascript
   // 调用 AskQuestion 工具的伪代码
   AskQuestion({
     questions: [{
       id: "deploy-confirm",
       prompt: "请确认以下部署参数...（展示发布项、模版、标签等）",
       options: [
         { id: "confirm", label: "确认，开始部署" },
         { id: "cancel", label: "取消部署" }
       ]
     }]
   })
   ```
   
   - 用户在确认对话中选择开始部署或取消部署

7. **执行部署**：
   
   a. 直接执行部署脚本：
   ```bash
   # Plus 部署示例
   ./scripts/deploy/execute_deploy.sh plus 187194 1007723 "测试环境部署" branch main "" ""
   
   # Cargo 部署示例（带泳道）
   ./scripts/deploy/execute_deploy.sh cargo 178014 1001 test commit c0534485ba3e1c0be95fa4b8ab0007c7191d3b24 com.sankuai.stafftraining.demo songhuayang-5e05f
   ```
   或（如果使用了临时分支）：
   ```bash
   ./scripts/deploy/execute_deploy.sh plus 187194 1007723 "测试环境部署" branch main-temp "" ""
   ```
   
   b. 如果遇到 SSOID 相关的报错，提示用户给 CatPaw 提 TT
   
   c. 如果返回“没有可用的机器”错误，提示用户可以尝试使用 Cargo 部署

8. **部署完成后，更新配置**：
   部署成功后，确认配置文件 `deploy-config.json` 中的所有参数都是最新的

9. **返回结果**：
   部署成功后，返回 `job_url` 给用户查看部署详情。展示格式参见下方「部署结果展示规范」，多发布项时使用表格汇总

---

### 场景 2：无 deploy-config.json，需要选择部署模版

**前提**：项目根目录没有 `deploy-config.json`

**步骤**：

1. **用户请求**：
   ```
   用户说："部署"
   ```

2. **调用 [release-info skill](../release/README.md) 获取模版列表**：
   - 从当前 git 仓库获取仓库地址
   - 查询发布项信息
   - 获取所有可用的部署模版

3. **展示模版列表给用户**：
   
   | 模版 ID | 名称 | 环境 |
   |---------|------|------|
   | 1280884 | test | test (测试) |
   | 1280887 | dev | dev (开发) |
   | 1280886 | prod | prod (生产) |

4. **基于是否有 `AskQuestion` 工具来处理用户选择**：
   
   **情况 A：有 `AskQuestion` 工具（推荐）**
   
   ```javascript
   // 调用 AskQuestion 工具的伪代码
   AskQuestion({
     questions: [{
       id: "template-select",
       prompt: "请选择部署模版：",
       options: [
         { id: "1280884", label: "test (测试环境)" },
         { id: "1280887", label: "dev (开发环境)" },
         { id: "1280888", label: "test-不纳入云图统计 (测试环境)" }
       ]
     }]
   })
   ```
   - 用户在可视化的选项列表中选择所需的模版
   - 根据用户选择的 `option.id`，获取对应的模版 ID、名称和环境信息
   **情况 B：没有 `AskQuestion` 工具**
   
   直接按表格形式展示上述模版列表，让用户通过文本指定模版 ID 或序号来选择：
   ```
   请按以下格式选择模版：
   - 输入模版 ID（如：1280883）
   - 或输入序号（如：第 1 个模版）
   ```
   根据用户的文本输入，解析选择的模版 ID 并获取对应信息

5. **获取当前分支并检测未提交的变更**：
   ```bash
   ./scripts/deploy/get_current_branch.sh
   ```
   作为默认的部署标签，同时检查是否有未提交的变更。返回信息包括：
   - `branch`: 当前分支名
   - `has_uncommitted_changes`: 布尔值，是否有未提交的变更
   - `uncommitted_files`: 未提交文件的列表（如果有的话）

6. **询问用户是否创建临时分支（检测到有未提交的变更时）**：
   
   **情况 A：有 `AskQuestion` 工具（推荐）**
   
   ```javascript
   // 调用 AskQuestion 工具的伪代码
   AskQuestion({
     questions: [{
       id: "temp-branch-confirm",
       prompt: "检测到当前分支有未提交的变更，需要提交到临时分支部署吗？",
       options: [
         { id: "yes", label: "是，提交到临时分支" },
         { id: "no", label: "否，直接使用原分支部署" }
       ]
     }]
   })
   ```
   
   **情况 B：没有 `AskQuestion` 工具**
   
   按表格形式展示选项：
   
   | 选项 | 说明 |
   |------|------|
   | yes | 是，提交到临时分支 |
   | no | 否，直接使用原分支部署 |
   
   用户通过输入 "yes" 或 "no" 来选择
   
   **执行逻辑**：
   
   - **如果用户选择 "是" (yes)**：
     ```bash
     ./scripts/deploy/commit_to_temp_branch.sh
     ```
     - 将变更提交到 `{current_branch}-temp` 临时分支并推送到远程
     - 更新部署标签为 `{current_branch}-temp`
     - 保留原分支的本地变更状态（使用 patch 文件）
   
   - **如果用户选择 "否" (no)**：
     - 继续使用原分支进行部署

7. **展示参数确认**：
   展示完整的部署参数：
   - 发布项：{release_name} (ID: {release_id})
   - 模版：{template.name} (ID: {template.id}, 环境: {template.env})
   - 部署标签：{当前分支或临时分支} (type: branch)

8. **部署参数最终确认**：
   
   **情况 A：有 `AskQuestion` 工具（推荐）**
   
   ```javascript
   // 调用 AskQuestion 工具的伪代码
   AskQuestion({
     questions: [{
       id: "deploy-confirm",
       prompt: "请确认以下部署参数...（展示发布项、模版、标签等）",
       options: [
         { id: "confirm", label: "确认，开始部署" },
         { id: "cancel", label: "取消部署" }
       ]
     }]
   })
   ```
   - 用户在确认对话中选择开始部署或取消部署
   
   **情况 B：没有 `AskQuestion` 工具**
   
   按表格或文本形式展示完整的部署参数，然后让用户确认：
   
   | 参数 | 值 |
   |------|-----|
   | 发布项 | {release_name} (ID: {release_id}) |
   | 模版 | {template.name} (ID: {template.id}, 环境: {template.env}) |
   | 部署标签 | {label} (type: {label_type}) |
   
   用户需要输入 "confirm" 确认部署，或输入 "cancel" 取消部署

9. **执行部署**：
   
   a. 直接执行部署脚本：
   ```bash
   # Plus 部署
   ./scripts/deploy/execute_deploy.sh plus 12345 101 "测试环境部署" branch main "" ""
   ```
   或（如果部署的是临时分支）：
   ```bash
   ./scripts/deploy/execute_deploy.sh plus 12345 101 "测试环境部署" branch main-temp "" ""
   ```
   
   b. 如果遇到 SSOID 相关的报错，提示用户给 CatPaw 提 TT
   
   c. 如果返回“没有可用的机器”错误，提示用户可以尝试使用 Cargo 部署

10. **部署完成后，保存配置**：
    部署成功后，在 `.claude/skills/ee-plus` 目录下创建 `deploy-config.json` 文件，保存本次部署的配置。
    
    **Plus 部署配置示例**（无 swimlane）：
    ```json
    {
      "deploy_type": "plus",
      "release": [
        {
          "release_id": 12345,
          "release_name": "项目名称",
          "appkey": "com.example.project",
          "template": {
            "id": 101,
            "name": "测试环境部署",
            "env": "test"
          }
        }
      ],
      "label": "main",
      "label_type": "branch"
    }
    ```
    
    **Cargo 部署配置示例**（包含 swimlane）：
    ```json
    {
      "deploy_type": "cargo",
      "release": [
        {
          "release_id": 12345,
          "release_name": "项目名称",
          "appkey": "com.example.project",
          "template": {
            "id": 101,
            "name": "测试环境部署",
            "env": "test"
          }
        }
      ],
      "label": "main",
      "label_type": "branch",
      "swimlane": "project-abc123"
    }
    ```
    
    便于下次快速部署（见场景 1）
    
    **注意**：
    - Plus 部署返回的响应中不包含 `swimlane` 字段
    - Cargo 部署返回的响应中包含 `swimlane` 字段，应将其写入配置文件中

---

### 场景 3：使用 tag 部署指定版本（Plus）

**前提**：`.claude/skills/ee-plus` 目录下的 deploy-config.json 中配置了 tag

**配置示例**：
```json
{
  "deploy_type": "plus",
  "release": [
    {
      "release_id": 187194,
      "release_name": "支付服务",
      "appkey": "com.example.payment",
      "template": {
        "id": 1007723,
        "name": "测试环境部署",
        "env": "test"
      }
    }
  ],
  "label": "v2.1.0",
  "label_type": "tag"
}
```

**步骤**：

1. **用户请求**：
   ```
   用户说："部署"
   ```

2. **验证配置**：
   ```bash
   ./scripts/deploy/validate_config.sh ./deploy-config.json
   ```
3. **展示参数**：
   ```
   发布项：支付服务 (ID: 187194)
   模版：测试环境部署 (ID: 1007723, 环境: test)
   部署标签：v2.1.0 (type: tag)
   ```
   注意：**不需要查询 git 分支**，直接使用配置中的 tag

4. **用户确认**：
   ```
   用户说："确认"
   ```

5. **执行部署**：
   
   a. 直接执行部署脚本：
   ```bash
   ./scripts/deploy/execute_deploy.sh plus 187194 1007723 "测试环境部署" tag v2.1.0 "" ""
   ```
   
   b. 如果遇到 SSOID 相关的报错，提示用户给 CatPaw 提 TT
   
   c. 如果返回“没有可用的机器”错误，提示用户可以尝试使用 Cargo 部署

6. **部署完成后，更新配置**：
   部署成功后，确认 `deploy-config.json` 文件中的所有信息都是最新的

---

### 场景 4：使用预演模式测试部署参数

**用途**：在实际部署前验证参数是否正确

**步骤**：

1. **执行预演部署**：
   ```bash
   # Plus 部署预演
   ./scripts/deploy/execute_deploy.sh plus 187194 1007723 "测试环境部署" branch main "" "" --dry-run --verbose
   
   # Cargo 部署预演（带泳道，使用分支）
   ./scripts/deploy/execute_deploy.sh cargo 178014 1001 test branch main com.sankuai.stafftraining.demo songhuayang-5e05f --dry-run --verbose
   ```

2. **查看验证结果**：
   ```json
   {
     "status": "pending",
     "message": "预演模式：部署参数验证通过，未执行实际部署"
   }
   ```

3. **确认无误后执行实际部署**：
   ```bash
   # Plus 部署
   ./scripts/deploy/execute_deploy.sh plus 187194 1007723 "测试环境部署" branch main "" ""
   
   # Cargo 部署（带泳道，使用分支）
   ./scripts/deploy/execute_deploy.sh cargo 178014 1001 "test" branch main com.sankuai.stafftraining.demo songhuayang-5e05f
   ```

## 关键流程指导

### 第 1 优先级：检查配置文件并检测未提交的变更

读取 `.claude/skills/ee-plus` 目录下的 `deploy-config.json` 文件（或项目根目录）：
1. 验证配置文件是否存在且完整
2. 如果完整，验证配置有效
3. 验证配置中的环境信息
4. **即使有配置文件，也需要检查未提交的变更**（使用 `get_current_branch.sh`）
5. 如果有未提交的变更：
   - 询问用户是否提交到临时分支
   - 用户可选择提交到临时分支或继续使用配置中的分支
   - **不能自动提交临时变更**
6. 如果配置中 `label_type` 为 `tag`，则无需检查变更
7. 脚本优先级：skill 目录 > 项目根目录

### 第 2 优先级：获取当前分支（仅当配置中无 label 时）

如果配置不完整或不存在，才需要获取当前分支信息：

```bash
./scripts/deploy/get_current_branch.sh
```

**返回示例**:
```json
{
  "branch": "develop",
  "sha": "abc123",
  "has_uncommitted_changes": true,
  "uncommitted_files": ["src/main.ts", "README.md"],
  "timestamp": "2026-02-06T10:30:00Z"
}
```

#### 处理未提交的变更

- 如果 `has_uncommitted_changes` 为 `false`，直接使用当前分支进行部署
- 如果 `has_uncommitted_changes` 为 `true`，需要询问用户是否创建临时分支

#### 用户选择：创建临时分支还是使用原分支

**情况 A：有 `AskQuestion` 工具（推荐）**

```javascript
// 调用 AskQuestion 工具的伪代码
AskQuestion({
  questions: [{
    id: "temp-branch-confirm",
    prompt: "检测到当前分支有未提交的变更，请选择部署方式：",
    options: [
      { id: "yes", label: "是，提交到临时分支部署（推荐，安全快速）" },
      { id: "no", label: "否，直接使用原分支部署" }
    ]
  }]
})
```

**情况 B：没有 `AskQuestion` 工具**

按表格形式展示选项，用户通过输入选择：

| 选项 | 说明 |
|------|------|
| yes | 是，提交到临时分支部署（推荐，安全快速） |
| no | 否，直接使用原分支部署 |

**执行逻辑**：

**选项 A / yes：创建临时分支部署（推荐）**
- 如果用户选择 "是" (yes)，执行临时分支提交流程
- 更新部署标签为 `{current_branch}-temp`

**选项 B / no：直接使用原分支部署**
- 如果用户选择 "否" (no)，继续使用原分支进行部署
- 保持部署标签为当前分支名

### 第 3 优先级：处理临时分支提交（当用户同意时）

如果用户选择提交到临时分支，执行以下步骤：

#### 执行临时分支提交脚本

```bash
./scripts/deploy/commit_to_temp_branch.sh
```

**返回示例**:
```json
{
  "status": "success",
  "original_branch": "develop",
  "temp_branch": "develop-temp",
  "temp_branch_url": "https://github.com/user/repo.git",
  "commit_sha": "def456",
  "message": "Successfully committed changes to temporary branch and pushed to remote",
  "timestamp": "2026-02-06T10:31:00Z"
}
```

#### 脚本执行的工作步骤（内部自动完成）

1. 创建临时分支 `{original_branch}-temp`
2. 添加所有变更到暂存区 (`git add .`)
3. 提交变更到临时分支 (`git commit -m "temp deploy branch"`)
4. 推送临时分支到远程 (`git push --force origin {temp_branch}`)
5. 生成 patch 文件捕获这次提交的变更
6. 切换回原始分支
7. 应用 patch 到原始分支的工作目录
8. 清理 patch 文件和本地临时分支

#### 更新部署参数

- 将 `label` 改为 `{original_branch}-temp`（临时分支）
- 将 `label_type` 保持为 `branch`
- 继续正常的部署流程

#### 优势

- ✅ 安全部署：无需提交本地变更到原分支
- ✅ 保留本地状态：部署完成后，本地分支变更状态保持不变
- ✅ 快速迭代：开发过程中快速测试最新代码
- ✅ 灵活部署：支持在多个分支之间快速切换和部署

### 使用 Release-Info Skill 和 AskQuestion（或表格选择）

当配置不存在或不完整时，调用 [release-info skill](../release/README.md)：
1. 获取发布项基本信息
2. 使用返回的 release_id 获取部署模版列表
3. **基于是否有 `AskQuestion` 工具来展示和处理模版选择**
   - **有 `AskQuestion` 工具**：将模版列表转换为 `AskQuestion` 的可选项
     - 用户可以在交互式界面中直观地选择所需的模版
     - 根据用户的选择获取对应的模版信息
   - **没有 `AskQuestion` 工具**：按表格形式展示模版列表
     - 根据用户的文本输入（模版 ID 或序号）获取对应的模版信息

### 获取并展示部署参数

无论哪个场景，最终都要展示以下信息给用户：
- 发布项名称和 ID
- 部署模版名称、ID 和环境
- **要部署的标签**（从配置或当前分支）
- **标签类型**（branch 或 tag）
- 任何其他相关配置

**使用 `AskQuestion` 工具或表格形式进行最终确认**：
- **有 `AskQuestion` 工具**：将完整的部署参数展示为单一的确认问卷
  - 用户必须在交互式界面中明确选择 "确认部署" 或 "取消部署"
- **没有 `AskQuestion` 工具**：按表格形式展示部署参数
  - 用户需要输入 "confirm" 确认部署，或输入 "cancel" 取消部署
- 只有用户选择确认，才能执行实际部署

### 执行部署

等待用户明确确认后，执行以下步骤：

#### 第 1 步：执行部署脚本

直接执行 `execute_deploy.sh` 脚本，不提前检查 SSOID：

```bash
./scripts/deploy/execute_deploy.sh <deploy_type> <release_id> <template_id> <template_name> <label_type> <label> [appkey] [swimlane] [options]
```

**参数说明**：
- `deploy_type` - 部署类型：`plus` 或 `cargo`（必需）
- `release_id` - 发布项 ID（必需）
- `template_id` - 部署模版 ID（必需）
- `template_name` - 部署模版名称（必需）
- `label_type` - 标签类型：`branch`、`tag` 或 `commit`（必需）
- `label` - 标签值：分支名、tag 名或 commit SHA（必需）
- `appkey` - AppKey（Cargo 必需，Plus 可选）
- `swimlane` - 泳道标识符/ProjectID（可选）
- `--dry-run` - 预演模式（可选）
- `--verbose` - 详细输出模式（可选）

**部署示例 1（Plus 分支部署）**：
```bash
./scripts/deploy/execute_deploy.sh plus 187194 1007723 "测试环境部署" branch main "" ""
```

**部署示例 2（Plus tag 部署）**：
```bash
./scripts/deploy/execute_deploy.sh plus 187194 1007723 "测试环境部署" tag v2.1.0 "" ""
```

**部署示例 3（Cargo 分支部署）**：
```bash
./scripts/deploy/execute_deploy.sh cargo 178014 1001 test branch main com.sankuai.stafftraining.demo songhuayang-5e05f
```

**部署示例 4（Cargo commit 部署）**：
```bash
./scripts/deploy/execute_deploy.sh cargo 178014 1001 test commit c0534485ba3e1c0be95fa4b8ab0007c7191d3b24 com.sankuai.stafftraining.demo songhuayang-5e05f
```

**预演模式示例**：
```bash
./scripts/deploy/execute_deploy.sh plus 187194 1007723 "测试环境部署" branch main "" "" --dry-run --verbose
```

#### 第 2 步：处理部署错误

- 如果部署脚本返回 SSOID 相关的错误，提示用户给 CatPaw 提 TT
- ⚠️ **无可用机器错误处理**：如果部署返回的错误信息包含 **"没有可用的机器"**（如 `该部署模板下没有可用的机器`），说明该发布项的 Plus 部署模版下没有可部署的机器（Cargo 泳道机器会被自动过滤）。此时应 **提示用户可以尝试使用 Cargo 部署**：
  > Plus 部署失败：该部署模板下没有可用的机器。这通常是因为该模版下的机器都属于 Cargo 泳道，Plus 部署会自动过滤这些机器。
  > 
  > 💡 **建议**：您可以尝试使用 **Cargo 部署** 方式来部署此服务。只需将 `deploy_type` 改为 `cargo`，并提供 AppKey 即可（支持 branch、tag 或 commit SHA）。

#### 第 3 步：获取部署结果

脚本执行完成后，返回 JSON 格式的部署结果：

```json
{
  "status": "success",
  "job_id": "job-12345",
  "project_id": "project-67890",
  "job_url": "https://catpaw-plus.sankuai.com/job/12345",
  "message": "部署成功"
}
```

- 如果 `status` 为 `success`，向用户展示 `job_url`
- 如果 `status` 为 `failed` 或 `error`，向用户展示错误信息
- 如果错误信息包含"没有可用的机器"，额外提示用户可以改用 Cargo 部署（参见上方无可用机器错误处理）

**部署结果展示规范**：

单个任务部署成功时：
```
✅ 部署任务创建成功!

  发布项: 项目名称 (ID: 12345)
  部署类型: plus
  任务 ID: job-12345

📎 查看部署详情：https://catpaw-plus.sankuai.com/job/12345
```

多个发布项部署时（配置文件 `release` 数组包含多个发布项），使用表格汇总展示所有任务结果：

```
✅ 部署任务创建完成（共 2 个任务）

| # | 发布项 | 任务 ID | 状态 | 部署链接 |
|---|--------|---------|------|----------|
| 1 | 项目A (ID: 12345) | job-001 | ✅ 成功 | [查看详情](https://catpaw-plus.sankuai.com/job/001) |
| 2 | 项目B (ID: 12346) | job-002 | ✅ 成功 | [查看详情](https://catpaw-plus.sankuai.com/job/002) |
```

若多任务中有部分失败，需明确标注失败原因：

```
| # | 发布项 | 任务 ID | 状态 | 部署链接 |
|---|--------|---------|------|----------|
| 1 | 项目A (ID: 12345) | job-001 | ✅ 成功 | [查看详情](...) |
| 2 | 项目B (ID: 12346) | - | ❌ 失败 | 该部署模板下没有可用的机器 |
```

## 脚本和资源

### scripts/deploy

本 skill 包含以下辅助脚本：

**配置管理**:
- `read_config.sh` - 读取并解析 `deploy-config.json`
- `validate_config.sh` - 验证配置文件的完整性

**分支和标签**:
- `get_current_branch.sh` - 获取当前 git 分支及其状态（包括是否有未提交的变更）
  ```bash
  # 用法：检查当前分支及未提交变更
  ./scripts/deploy/get_current_branch.sh [repo_path]
  
  # 返回示例（JSON）：
  {
    "branch": "develop",
    "sha": "abc123",
    "has_uncommitted_changes": true,
    "uncommitted_files": ["src/main.ts", "README.md"],
    "timestamp": "2026-02-06T10:30:00Z"
  }
  ```

- `commit_to_temp_branch.sh` - 将未提交的变更提交到临时分支并推送
  ```bash
  # 用法：创建临时分支并提交当前变更
  ./scripts/deploy/commit_to_temp_branch.sh [repo_path]
  
  # 返回示例（JSON）：
  {
    "status": "success",
    "original_branch": "develop",
    "temp_branch": "develop-temp",
    "temp_branch_url": "https://github.com/user/repo.git",
    "commit_sha": "def456",
    "message": "Successfully committed changes to temporary branch and pushed to remote",
    "timestamp": "2026-02-06T10:31:00Z"
  }
  
  # 脚本自动执行的步骤：
  # 1. 创建临时分支 {original_branch}-temp
  # 2. 添加所有变更到暂存区 (git add .)
  # 3. 提交变更到临时分支 (git commit -m "temp deploy branch")
  # 4. 推送临时分支到远程 (git push --force origin {temp_branch})
  # 5. 生成 patch 文件（用于保留本地状态）
  # 6. 切换回原始分支
  # 7. 应用 patch 到原始分支工作目录
  # 8. 清理 patch 文件和本地临时分支
  ```

**部署执行**:
- `execute_deploy.sh` - 执行部署的主入口脚本
- `submit_deploy_job.sh` - 提交部署任务到 catpaw-plus 平台（实际执行部署）
  - 与 catpaw-plus 平台通信
  - 从缓存读取 SSOID 并使用
  - 处理部署结果
  - 如果 SSOID 缺失或异常，将返回错误并提示用户给 CatPaw 提 TT

**SSOID 管理**:
- `get_ssoid.sh` - 从 `~/.catpaw/sso_config.json` 读取 SSOID 并检查是否有效（12小时内）
  ```bash
  # 用法：检查 ~/.catpaw/sso_config.json 中的 SSOID
  ./scripts/deploy/get_ssoid.sh
  
  # SSOID 存在且有效时的输出（JSON）：
  {
    "valid": true,
    "cache_exists": true,
    "cache_age": 3600,
    "timestamp": "1707200400"
  }
  
  # SSOID 配置异常时的输出（JSON）：
  {
    "valid": false,
    "cache_exists": false,
    "error": "ssoid_issue",
    "message": "SSOID 配置异常，请给 CatPaw 提 TT"
  }
  ```

每个脚本都可独立运行，输出 JSON 格式的结果。

### references/

详细的文档资源：

- `config_structure.md` - **配置文件结构详解**（大模型必读）
  - 解释每个配置字段的含义
  - 提供完整的示例
  - 说明验证规则
  
- `deploy_api_reference.md` - **部署 API 参考**（大模型必读）
  - catpaw-plus API 详细说明
  - 请求和响应格式
  - 错误处理指南

## 错误处理：无可用机器

当 Plus 部署返回包含 **"没有可用的机器"** 的错误信息时（如 `该部署模板下没有可用的机器，请检查发布项的机器列表配置（Cargo泳道机器会被自动过滤）`），需要向用户提示以下信息：

1. **解释原因**：Plus 部署模式下，后端会自动过滤 Cargo 泳道的机器。如果该部署模版下的所有机器都属于 Cargo 泳道，那么就没有可用于 Plus 部署的机器。
2. **建议使用 Cargo 部署**：提示用户可以切换为 Cargo 部署方式。Cargo 部署支持泳道机器，是一种替代方案。

**提示模板**：
> ⚠️ Plus 部署失败：该部署模板下没有可用的机器。
>
> 这通常是因为该模版下的机器都属于 Cargo 泳道，Plus 部署会自动过滤这些机器。
>
> 💡 **建议**：您可以尝试使用 **Cargo 部署** 方式来部署此服务。Cargo 部署需要：
> - 将 `deploy_type` 改为 `cargo`
> - 提供 AppKey（可从发布项信息中获取）
> - 支持使用 branch、tag 或 commit SHA 作为部署标签

**agent 操作**：如果用户同意切换为 Cargo 部署，agent 应：
1. 获取当前分支最新的 commit SHA（`git rev-parse HEAD`）
2. 从发布项信息中获取 AppKey
3. 将 `deploy-config.json` 中的 `deploy_type` 改为 `cargo`（`label_type` 可保持 `branch` 不变，也可改为 `commit`）
4. 重新执行部署流程

---

## 总结

部署管理 skill 通过以下方式简化部署流程：

1. **智能配置管理** - 优先使用本地 config，无则自动获取
2. **环境安全检查** - 支持全环境部署（dev/test/staging/prod），线上环境需组织授权
3. **灵活的用户交互** - 根据 agent 能力选择：
   - 有 `AskQuestion` 工具时：提供交互式可视化选择
   - 无 `AskQuestion` 工具时：按表格形式展示，用户文本选择
4. **自动分支识别** - 无需手动指定分支，自动使用当前分支
5. **智能变更检测** - 自动检测未提交的变更，提供临时分支部署选项
6. **临时分支支持** - 允许将 diff 提交到临时分支部署，同时保留原分支的本地变更状态
7. **参数确认机制** - 进行参数确认，防止误部署
   - 支持 `AskQuestion` 工具的交互式确认
   - 支持表格形式的文本确认
8. **脚本化执行** - 使用独立脚本确保部署的可靠性和可测试性
9. **SSOID 错误处理** - 如果遇到 SSOID 相关错误，提示用户给 CatPaw 提 TT

## AskQuestion 能力集成（可选方案）

本 skill 在以下关键步骤集成了 `AskQuestion` 工具。**注意**：如果 agent 没有 `AskQuestion` 工具，可以使用表格形式展示信息，让用户通过文本输入选择。

### 1. 模版选择

**触发场景**：无 deploy-config.json 或需要重新选择模版

**情况 A：有 `AskQuestion` 工具**

```javascript
AskQuestion({
  title: "选择部署模版",
  questions: [{
    id: "template-select",
    prompt: "请选择要部署的模版：",
    options: [
      { id: "1280884", label: "test (测试环境)" },
      { id: "1280887", label: "dev (开发环境)" },
      // ... 更多环境模版选项
    ]
  }]
})
```

**情况 B：没有 `AskQuestion` 工具**

按表格形式展示模版列表，用户输入模版 ID 或序号来选择：

| # | 模版 ID | 名称 | 环境 |
|---|---------|------|------|
| 1 | 1280884 | test | test (测试) |
| 2 | 1280887 | dev | dev (开发) |
| ... | ... | ... | ... |

### 2. 临时分支确认

**情况 A：有 `AskQuestion` 工具**

```javascript
AskQuestion({
  title: "处理未提交的变更",
  questions: [{
    id: "temp-branch-confirm",
    prompt: "检测到当前分支有未提交的变更，请选择部署方式：",
    options: [
      { id: "yes", label: "是，提交到临时分支部署（推荐）" },
      { id: "no", label: "否，直接使用原分支部署" }
    ]
  }]
})
```

**情况 B：没有 `AskQuestion` 工具**

展示选项并让用户选择：

| 选项 | 说明 |
|------|------|
| yes | 是，提交到临时分支部署（推荐） |
| no | 否，直接使用原分支部署 |

### 3. 部署参数确认

**触发场景**：在所有参数准备就绪后，执行部署前的最后确认

**情况 A：有 `AskQuestion` 工具**

```javascript
AskQuestion({
  title: "确认部署参数",
  questions: [{
    id: "deploy-confirm",
    prompt: `请确认以下部署参数：
      发布项：${release_name} (ID: ${release_id})
      模版：${template.name} (ID: ${template.id}, 环境: ${template.env})
      标签：${label} (type: ${label_type})
    `,
    options: [
      { id: "confirm", label: "确认，开始部署" },
      { id: "cancel", label: "取消部署" }
    ]
  }]
})
```

**情况 B：没有 `AskQuestion` 工具**

展示参数表格，让用户确认：

| 参数 | 值 |
|------|-----|
| 发布项 | {release_name} (ID: {release_id}) |
| 模版 | {template.name} (ID: {template.id}, 环境: {template.env}) |
| 部署标签 | {label} (type: {label_type}) |

用户输入 "confirm" 确认或 "cancel" 取消

### AskQuestion 的优势

- ✅ **可视化交互** - 用户可以在清晰的选项列表中直观地做出选择
- ✅ **结构化问卷** - 所有选择通过统一的问卷界面进行，保持交互一致性
- ✅ **易于扩展** - 支持单选、多选、复杂问卷组合等多种交互模式
- ✅ **错误防止** - 通过明确的确认步骤减少误操作风险
- ✅ **用户体验** - 相比文本输入，更加直观和易用

### 表格形式的优势（无 AskQuestion 工具时）

- ✅ **兼容性强** - 无需特殊工具支持，所有 agent 都能使用
- ✅ **清晰直观** - 信息以结构化表格形式展示，易于理解
- ✅ **文本交互** - 用户通过简单的文本输入完成选择
- ✅ **备选方案** - 在没有交互式工具时提供完整功能

### 临时分支部署的优势

- **安全部署** - 无需提交本地变更到原分支，直接部署当前工作目录的代码
- **保留本地状态** - 部署完成后，本地分支变更状态保持不变
- **快速迭代** - 开发过程中快速测试最新代码，无需担心本地变更污染分支历史
- **灵活部署** - 支持在多个分支之间快速切换和部署
