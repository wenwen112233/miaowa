# Catpaw-Plus 部署 API 参考

本文档详细说明部署 skill 使用的 catpaw-plus 部署 API。

## API 概述

### 基础信息

- **API Host**: `https://catpaw-plus.sankuai.com`
- **协议**: HTTP
- **Content-Type**: application/json

### 支持的部署类型

1. **Plus 部署** - 使用分支或 tag 部署到 Plus 平台
2. **Cargo 部署** - 使用分支、tag 或 commit SHA 部署到 Cargo 平台（泳道环境）

### 两个主要接口

1. **提交部署任务** - `/deploy`（支持 Plus 和 Cargo 两种部署类型）
2. **查询部署状态** - `/get/job`（查询任务状态并获取详情 URL）

---

## 1. 提交部署任务接口

### 请求

**URL**: `POST /deploy`

**Headers**:
```
Content-Type: application/json
```

### Plus 部署请求

**请求体示例**:
```json
{
  "DeployType": "plus",
  "SSOID": "user-id",
  "SSOEnv": "prod",
  "Resource": {
    "Branch": "main",
    "Tag": "",
    "MetaData": {
      "releaseId": "187194",
      "plusTemplateId": "1007723"
    }
  }
}
```

**Plus 部署字段说明**:

| 字段 | 必需 | 类型 | 说明 |
|------|:----:|------|------|
| DeployType | ✓ | string | 固定值 "plus" |
| SSOID | ✓ | string | 用户 SSO ID，从 MCP 工具获取 |
| SSOEnv | ✓ | string | 固定值 "prod" |
| Resource | ✓ | object | 部署资源对象 |
| Resource.Branch | ✓ | string | Git 分支名（部署分支时填写，tag 部署时为空） |
| Resource.Tag | ✓ | string | Git tag 名（tag 部署时填写，分支部署时为空） |
| Resource.MetaData | ✓ | object | 元数据对象 |
| Resource.MetaData.releaseId | ✓ | string | 发布项 ID |
| Resource.MetaData.plusTemplateId | ✓ | string | 部署模版 ID |

### Cargo 部署请求

**请求体示例（使用分支）**:
```json
{
  "DeployType": "cargo",
  "SSOID": "user-id",
  "SSOEnv": "prod",
  "Env": "test",
  "ProjectID": "songhuayang-5e05f",
  "Resource": {
    "Branch": "main",
    "MetaData": {
      "appKeyList": [
        {
          "AppKey": "com.sankuai.stafftraining.songhuayang.demo",
          "ReleaseID": 178014,
          "Template": "test"
        }
      ]
    }
  }
}
```

**请求体示例（使用 commit SHA）**:
```json
{
  "DeployType": "cargo",
  "SSOID": "user-id",
  "SSOEnv": "prod",
  "Env": "test",
  "ProjectID": "songhuayang-5e05f",
  "Resource": {
    "Commit": "c0534485ba3e1c0be95fa4b8ab0007c7191d3b24",
    "MetaData": {
      "appKeyList": [
        {
          "AppKey": "com.sankuai.stafftraining.songhuayang.demo",
          "ReleaseID": 178014,
          "Template": "test"
        }
      ]
    }
  }
}
```

**Cargo 部署字段说明**:

| 字段 | 必需 | 类型 | 说明 |
|------|:----:|------|------|
| DeployType | ✓ | string | 固定值 "cargo" |
| SSOID | ✓ | string | 用户 SSO ID，从 MCP 工具获取 |
| SSOEnv | ✓ | string | 固定值 "prod" |
| Env | ✓ | string | 部署环境，固定值 "test" |
| ProjectID | ✗ | string | 泳道标识符（可选），为空会自动创建泳道 |
| Resource | ✓ | object | 部署资源对象 |
| Resource.Branch | ✗ | string | Git 分支名（三选一：Branch、Tag、Commit） |
| Resource.Tag | ✗ | string | Git tag 名（三选一：Branch、Tag、Commit） |
| Resource.Commit | ✗ | string | Git commit SHA（三选一：Branch、Tag、Commit） |
| Resource.MetaData | ✓ | object | 元数据对象 |
| Resource.MetaData.appKeyList | ✓ | array | AppKey 列表 |
| Resource.MetaData.appKeyList[].AppKey | ✓ | string | 应用的 AppKey |
| Resource.MetaData.appKeyList[].ReleaseID | ✓ | number | 发布项 ID（数字类型） |
| Resource.MetaData.appKeyList[].Template | ✓ | string | 部署模版名称 |

### 响应

#### 成功响应 (HTTP 200)

**Plus 部署成功响应**:
```json
{
  "Code": 200,
  "Message": "Success",
  "Data": {
    "JobID": "2c6ee563-52ae-4a11-a916-6ceac3db0d0e",
    "ProjectID": "fe49fb2d-8619-43d1-965a-2c99020f9fb1"
  }
}
```

**Cargo 部署成功响应**:
```json
{
  "Code": 200,
  "Message": "Success",
  "Data": {
    "JobID": "db0b9906-4264-4fd0-8dcb-ee66d6eb5c89",
    "ProjectID": "songhuayang-5e05f"
  }
}
```

**响应字段说明**:

| 字段 | 说明 |
|------|------|
| Code | HTTP 状态码，200 表示成功 |
| Message | 状态信息 |
| Data.JobID | 部署任务 ID，用于查询状态 |
| Data.ProjectID | 项目 ID / 泳道标识符 |

#### 错误响应

```json
{
  "Code": 200,
  "Message": "Success",
  "Data": {
    "Status": "failed",
    "Result": {
      "Code": 500,
      "Message": "用户无权限",
      "Data": null
    }
  }
}
```

### 可能的错误信息

| 错误信息 | 适用类型 | 原因 | 解决方案 |
|---------|---------|------|--------|
| 用户无权限 | Plus / Cargo | SSOID 无效或用户无部署权限 | 检查 SSOID，确保用户被添加到权限组 |
| 该部署模板下没有可用的机器 | Plus | 模版下所有机器都属于 Cargo 泳道，被自动过滤 | **建议切换为 Cargo 部署方式**，Cargo 部署支持泳道机器 |
| Invalid metadata | Plus / Cargo | 发布项 ID 或模版 ID 错误 | 验证配置中的 ID 是否正确 |
| Resource not found | Plus / Cargo | 无法找到指定的资源 | 检查发布项和模版是否存在 |
| Branch/Tag not found | Plus / Cargo | 分支或 tag 不存在 | 检查分支/tag 名称 |
| Invalid commit SHA | Cargo | Commit SHA 格式错误或不存在 | 确保提供完整的 40 位 commit SHA |
| AppKey not found | Cargo | AppKey 不存在或无权限 | 检查 AppKey 是否正确，确保有权限 |

---

## 2. 查询部署状态接口

### 请求

**URL**: `GET /get/job?jobID=<JobID>`

**参数**:
- `jobID` (必需) - 从第一个请求返回的 JobID

### 响应

#### Plus 部署成功响应 (HTTP 200)

```json
{
  "Code": 200,
  "Message": "Success",
  "Data": {
    "Status": "success",
    "Result": {
      "Code": 200,
      "Message": "success",
      "Data": {
        "JobUrl": "https://dev.sankuai.com/services/com.sankuai.stafftraining.songhuayang.demo/to-deploy/deploy-detail/job-detail/db0b9906-4264-4fd0-8dcb-ee66d6eb5c89?releaseId=187194&user=&build_template_name=&archive=false&name=",
        "ProjectID": "fe49fb2d-8619-43d1-965a-2c99020f9fb1",
        "Result": {
          "FailLog": "",
          "FailReason": "",
          "Status": ""
        }
      }
    }
  }
}
```

#### Cargo 部署成功响应 (HTTP 200)

```json
{
  "Code": 200,
  "Message": "Success",
  "Data": {
    "Status": "success",
    "Result": {
      "Code": 200,
      "Message": "success",
      "Data": {
        "StackUrl": "http://cargo.sankuai.com/mypage/project/songhuayang-5e05f",
        "ProjectID": "songhuayang-5e05f",
        "Result": {
          "FailLog": "",
          "FailReason": "",
          "Status": ""
        }
      }
    }
  }
}
```

**字段说明**:

| 字段 | Plus | Cargo | 说明 |
|------|:----:|:-----:|------|
| Data.Status | ✓ | ✓ | 部署状态：success/failed/pending 等 |
| Data.Result.Code | ✓ | ✓ | 结果码，200 表示成功 |
| Data.Result.Message | ✓ | ✓ | 结果信息 |
| Data.Result.Data.JobUrl | ✓ | ✗ | Plus 部署详情页面 URL |
| Data.Result.Data.StackUrl | ✗ | ✓ | Cargo 部署详情页面 URL |
| Data.Result.Data.ProjectID | ✓ | ✓ | 项目 ID / 泳道标识符 |

**状态值说明**:

| 状态 | 说明 |
|------|------|
| success | 部署成功 |
| failed | 部署失败 |
| pending | 部署进行中，等待中 |
| processing | 部署处理中 |

**失败响应**:
```json
{
  "Code": 200,
  "Message": "Success",
  "Data": {
    "Status": "failed",
    "Result": {
      "Code": 500,
      "Message": "用户无权限",
      "Data": null
    }
  }
}
```

---

## 使用示例

### cURL 示例

#### Plus 部署

**提交 Plus 部署任务**:
```bash
curl -X POST 'https://catpaw-plus.sankuai.com/deploy' \
  -H 'Content-Type: application/json' \
  -d '{
    "DeployType": "plus",
    "SSOID": "test-user-id",
    "SSOEnv": "prod",
    "Resource": {
      "Branch": "main",
      "Tag": "",
      "MetaData": {
        "releaseId": "187194",
        "plusTemplateId": "1007723"
      }
    }
  }'
```

#### Cargo 部署

**提交 Cargo 部署任务（使用分支）**:
```bash
curl -X POST 'https://catpaw-plus.sankuai.com/deploy' \
  -H 'Content-Type: application/json' \
  -d '{
    "DeployType": "cargo",
    "SSOID": "test-user-id",
    "SSOEnv": "prod",
    "Env": "test",
    "ProjectID": "songhuayang-5e05f",
    "Resource": {
      "Branch": "main",
      "MetaData": {
        "appKeyList": [
          {
            "AppKey": "com.sankuai.stafftraining.songhuayang.demo",
            "ReleaseID": 178014,
            "Template": "test"
          }
        ]
      }
    }
  }'
```

**查询部署状态**:
```bash
curl 'https://catpaw-plus.sankuai.com/get/job?jobID=2c6ee563-52ae-4a11-a916-6ceac3db0d0e'
```

### Bash 脚本示例

见 `deploy_manager` skill 中的 `scripts/submit_deploy_job.sh`

---

## SSOID 来源

SSOID 通过 MCP 工具 `mcp_tool_plus-test_get_sso_id_and_mis` 获取，然后：
- 缓存到 `~/.catpaw/sso_config.json`
- 12 小时内直接使用缓存
- 12 小时后需要重新获取

---

## 部署流程

```
1. 用户请求部署
   ↓
2. 获取 SSOID（从缓存或 MCP）
   ↓
3. 提交部署任务到 /deploy
   ↓
4. 解析返回的 JobID
   ↓
5. 查询 /get/job 获取部署状态
   ↓
6. 解析状态并返回 JobUrl 给用户
```

---

## 错误处理

所有错误都遵循统一的格式：

```json
{
  "error": "error_code",
  "message": "错误信息",
  "api_response": "完整的 API 响应（可选）"
}
```

### 常见错误代码

| 错误代码 | 原因 |
|---------|------|
| ssoid_cache_not_found | SSOID 缓存文件不存在 |
| invalid_ssoid_cache | SSOID 缓存内容无效 |
| missing_parameters | 缺少必需参数 |
| deploy_submission_failed | 部署任务提交失败 |
| invalid_deploy_response | 部署 API 返回无效响应 |
| status_query_failed | 状态查询失败 |
| deployment_failed | 部署任务执行失败 |

---

## 最佳实践

1. **SSOID 缓存** - 使用 12 小时缓存减少 MCP 调用
2. **参数验证** - 在提交前验证所有参数的有效性
3. **详细日志** - 使用 `--verbose` 模式进行调试
4. **错误处理** - 总是检查返回的状态码和错误信息
5. **重试机制** - 对于网络错误应该支持重试

---

## 相关资源

- `deployment_guide.md` - 部署流程指南
- `scripts/submit_deploy_job.sh` - 实现了完整的 API 交互
- 部署平台文档 - 查看更多 API 信息
