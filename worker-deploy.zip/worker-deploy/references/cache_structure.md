# 缓存数据结构说明

## 概述

本文档描述 ee-plus skill 的缓存数据结构和 API 响应格式。缓存由大模型管理，脚本只负责输出 JSON 数据。

## 缓存目录结构

```
.claude/skills/ee-plus/.cache/
├── releases.json                   # 所有发布项信息（统一文件）
├── releases/
│   └── <release_id>/
│       └── templates.json          # 部署模版列表
└── templates/
    └── <template_id>/
        └── machines.json           # 机器列表
```

### 目录命名规则

- **releases.json**：统一存储所有仓库的发布项信息，使用数组结构
- **release_id**：发布项 ID（数字），用于模版缓存目录
- **template_id**：模版 ID（数字），用于机器缓存目录

## 数据格式

### 1. releases.json

所有发布项信息的统一存储文件，包含多个仓库的发布项数据。

```json
{
  "releases": [
    {
      "repository": "git@git.example.com:team/project1.git",
      "release_id": 12345,
      "release_name": "项目1发布项",
      "appkey": "com.example.project1",
      "last_updated": "2026-02-04T10:00:00Z"
    },
    {
      "repository": "git@git.example.com:team/project2.git",
      "release_id": 67890,
      "release_name": "项目2发布项",
      "appkey": "com.example.project2",
      "last_updated": "2026-02-04T11:00:00Z"
    }
  ]
}
```

**字段说明**：
- `releases` (array): 发布项数组
  - `repository` (string): Git 仓库地址（唯一标识）
  - `release_id` (number): 发布项 ID
  - `release_name` (string): 发布项名称
  - `appkey` (string): 应用标识
  - `last_updated` (string): 数据更新时间（ISO 8601 格式）

**维护方式**：
- 大模型负责维护此文件
- 添加新仓库时，追加到 releases 数组
- 更新已存在仓库时，通过 repository 字段匹配并更新
- 保持其他仓库的数据不变

### 2. templates.json

部署模版列表，由 `fetch_templates.sh` 输出。

```json
{
  "release_id": 12345,
  "templates": [
    {
      "template_id": 101,
      "template_name": "生产环境部署",
      "environment": 1,
      "build_template_name": "标准构建",
      "template_value": "{\"Deploy.Strategy.Options\":{...}}"
    },
    {
      "template_id": 102,
      "template_name": "测试环境部署",
      "environment": 3,
      "build_template_name": "测试构建",
      "template_value": "{...}"
    }
  ],
  "last_updated": "2026-02-04T10:00:00Z"
}
```

**字段说明**：
- `release_id` (number): 发布项 ID
- `templates` (array): 模版列表
  - `template_id` (number): 模版 ID
  - `template_name` (string): 模版名称
  - `environment` (number): 环境 ID（1=prod, 2=staging, 3=test, 4=beta, 5=dev）
  - `build_template_name` (string): 构建模版名称
  - `template_value` (string): 模版配置（JSON 字符串）
- `last_updated` (string): 数据更新时间

### 3. machines.json

机器列表，由 `fetch_machines.sh` 输出。

```json
{
  "template_id": 101,
  "machines": [
    {
      "machine_name": "web-server-01",
      "ip_address": "192.168.1.10",
      "idc": "beijing-01",
      "comment": "生产环境 Web 服务器",
      "status": "online",
      "is_offline": false
    },
    {
      "machine_name": "web-server-02",
      "ip_address": "192.168.1.11",
      "idc": "beijing-01",
      "comment": "生产环境 Web 服务器",
      "status": "online",
      "is_offline": false
    }
  ],
  "last_updated": "2026-02-04T10:00:00Z"
}
```

**字段说明**：
- `template_id` (number): 模版 ID
- `machines` (array): 机器列表
  - `machine_name` (string): 机器名称
  - `ip_address` (string): IP 地址
  - `idc` (string): 机房/IDC
  - `comment` (string): 备注说明
  - `status` (string): 状态（如 "online"）
  - `is_offline` (boolean): 是否离线
- `last_updated` (string): 数据更新时间

## API 响应格式

### API 1: 获取发布项信息

**请求**：
```
GET ${API_HOST}/api/v1/code/repo/release?repository=${REPOSITORY}
```

**响应**：
```json
{
  "code": 0,
  "message": "success",
  "data": [
    {
      "Id": 12345,
      "Name": "项目发布项",
      "Appkey": "com.example.project",
      "Repository": "git@git.example.com:team/project.git"
    }
  ]
}
```

### API 2: 获取部署模版

**请求**：
```
GET ${API_HOST}/release/${RELEASE_ID}/template/list
```

**响应格式 1（数组）**：
```json
[
  {
    "Id": 101,
    "Name": "生产环境部署",
    "Env": 1,
    "BuildTemplateName": "标准构建",
    "TemplateValue": "{...}"
  }
]
```

**响应格式 2（对象）**：
```json
{
  "code": 0,
  "message": "success",
  "data": [
    {
      "Id": 101,
      "Name": "生产环境部署",
      "Env": 1,
      "BuildTemplateName": "标准构建",
      "TemplateValue": "{...}"
    }
  ]
}
```

### API 3: 获取机器列表

**请求**：
```
GET ${API_HOST}/api/templateid/${TEMPLATE_ID}/hosts
```

**响应**：
```json
[
  {
    "Name": "web-server-01",
    "Ip": "192.168.1.10",
    "Idc": "beijing-01",
    "Comment": "生产环境 Web 服务器",
    "Status": "online",
    "IsOffline": false
  }
]
```

## 环境 ID 映射

| ID | 环境名称 |
|----|---------|
| 0  | all     |
| 1  | prod    |
| 2  | staging |
| 3  | test    |
| 4  | beta    |
| 5  | dev     |
| 6  | others  |

## 缓存更新策略

### 何时读取缓存

- 用户请求信息但未明确要求更新
- 其他 skill 需要数据且可接受缓存数据

### 何时更新缓存

- 缓存文件不存在
- 用户明确说"更新"、"刷新"、"重新获取"
- 缓存数据可能过期（可选：检查 last_updated 时间）

### 缓存操作示例

**检查 releases.json 是否存在**：
```bash
if [ -f .claude/skills/ee-plus/.cache/releases.json ]; then
    echo "缓存文件存在"
else
    echo "缓存文件不存在"
fi
```

**检查特定仓库是否已缓存**：
```bash
REPO="git@git.example.com:team/project.git"
CACHED=$(cat .claude/skills/ee-plus/.cache/releases.json 2>/dev/null | \
  jq ".releases[] | select(.repository == \"$REPO\")")

if [ -n "$CACHED" ]; then
    echo "该仓库已缓存"
else
    echo "该仓库未缓存"
fi
```

**读取特定仓库的缓存**：
```bash
REPO="git@git.example.com:team/project.git"
cat .claude/skills/ee-plus/.cache/releases.json | \
  jq ".releases[] | select(.repository == \"$REPO\")"
```

**添加新仓库到缓存**：
```bash
CACHE_FILE=".claude/skills/ee-plus/.cache/releases.json"
NEW_DATA=$(.claude/skills/ee-plus/scripts/fetch_release_info.sh "$REPO")

# 初始化文件（如果不存在）
if [ ! -f "$CACHE_FILE" ]; then
    mkdir -p .claude/skills/ee-plus/.cache
    echo '{"releases":[]}' > "$CACHE_FILE"
fi

# 添加新数据
TMP_FILE=$(mktemp)
cat "$CACHE_FILE" | jq --argjson new "$NEW_DATA" \
  '.releases += [$new]' > "$TMP_FILE" && mv "$TMP_FILE" "$CACHE_FILE"
```

**更新已存在仓库的缓存**：
```bash
CACHE_FILE=".claude/skills/ee-plus/.cache/releases.json"
REPO="git@git.example.com:team/project.git"
NEW_DATA=$(.claude/skills/ee-plus/scripts/fetch_release_info.sh "$REPO")

TMP_FILE=$(mktemp)
cat "$CACHE_FILE" | jq --argjson new "$NEW_DATA" \
  '.releases |= map(if .repository == $new.repository then $new else . end)' \
  > "$TMP_FILE" && mv "$TMP_FILE" "$CACHE_FILE"
```

**提取缓存中的特定字段**：
```bash
REPO="git@git.example.com:team/project.git"
RELEASE_ID=$(cat .claude/skills/ee-plus/.cache/releases.json | \
  jq -r ".releases[] | select(.repository == \"$REPO\") | .release_id")
echo "Release ID: $RELEASE_ID"
```

## 注意事项

1. **JSON 解析**：所有缓存文件都是有效的 JSON 格式，可使用 `jq` 解析
2. **原子写入**：更新缓存时建议先写入临时文件，然后 `mv` 替换，避免部分写入
3. **权限**：确保 `.claude/skills/ee-plus/.cache/` 目录有正确的读写权限
4. **容错**：如果缓存文件损坏，应删除并重新获取
5. **并发**：多个进程同时更新同一缓存文件可能导致冲突，需要注意

## 示例：完整工作流

```bash
# 1. 检查并获取发布项信息
RELEASES_FILE=".claude/skills/ee-plus/.cache/releases.json"
REPO="git@git.example.com:team/my-project.git"

# 检查该仓库是否已缓存
CACHED_RELEASE=$(cat "$RELEASES_FILE" 2>/dev/null | \
  jq ".releases[] | select(.repository == \"$REPO\")")

if [ -z "$CACHED_RELEASE" ]; then
    # 获取新数据
    NEW_DATA=$(.claude/skills/ee-plus/scripts/fetch_release_info.sh "$REPO")

    # 初始化文件（如果不存在）
    if [ ! -f "$RELEASES_FILE" ]; then
        mkdir -p .claude/skills/ee-plus/.cache
        echo '{"releases":[]}' > "$RELEASES_FILE"
    fi

    # 添加到缓存
    TMP_FILE=$(mktemp)
    cat "$RELEASES_FILE" | jq --argjson new "$NEW_DATA" \
      '.releases += [$new]' > "$TMP_FILE" && mv "$TMP_FILE" "$RELEASES_FILE"

    CACHED_RELEASE="$NEW_DATA"
fi

# 2. 读取 release_id
RELEASE_ID=$(echo "$CACHED_RELEASE" | jq -r '.release_id')

# 3. 获取部署模版
TEMPLATES_CACHE=".claude/skills/ee-plus/.cache/releases/${RELEASE_ID}/templates.json"
if [ ! -f "$TEMPLATES_CACHE" ]; then
    mkdir -p ".claude/skills/ee-plus/.cache/releases/${RELEASE_ID}"
    .claude/skills/ee-plus/scripts/fetch_templates.sh "$RELEASE_ID" > "$TEMPLATES_CACHE"
fi

# 4. 展示模版列表
cat "$TEMPLATES_CACHE" | jq -r '.templates[] | "\(.template_id): \(.template_name)"'
```
