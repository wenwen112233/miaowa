#!/bin/bash

# talos-common.sh - Talos 前端发布公共函数库
#
# 提供：
#   - talos-cli 可用性检测与 npx 降级
#   - 复用 worker-deploy 的 auth-common.sh 获取 SSO Token（注入 TALOS_ACCESS_TOKEN）
#   - 统一的 talos 命令执行封装 talos_exec()
#
# 依赖：
#   - node >= 16、npm >= 8
#   - jq
#   - ../auth-common.sh（用于获取 SSO Token）

# talos-cli 版本（与 ee-talos / talos-project-publish 保持一致）
TALOS_CLI_VERSION="${TALOS_CLI_VERSION:-1.0.26}"
TALOS_NPM_REGISTRY="${TALOS_NPM_REGISTRY:-http://r.npm.sankuai.com}"

# 全局：是否使用 npx（未全局安装 talos 时为 true）
USE_NPX_TALOS="false"

# ── talos-cli 可用性检测 ─────────────────────────────────────

# 检测 talos-cli，设置 USE_NPX_TALOS
# 返回 0 表示可用（全局命令或 npx），1 表示 node 环境缺失
detect_talos_cli() {
    if ! command -v node >/dev/null 2>&1; then
        echo "[Talos] ❌ 未检测到 node，请先安装 Node.js (>=16)" >&2
        return 1
    fi

    if command -v talos >/dev/null 2>&1; then
        USE_NPX_TALOS="false"
        echo "[Talos] ✅ 检测到全局 talos-cli" >&2
        return 0
    fi

    # 全局未安装，降级使用 npx
    USE_NPX_TALOS="true"
    echo "[Talos] ℹ️  未检测到全局 talos-cli，将使用 npx 执行（首次会自动下载）" >&2
    return 0
}

# ── SSO Token 获取（复用 auth-common.sh） ─────────────────────

# 获取 SSO Token 并注入 TALOS_ACCESS_TOKEN / TALOS_OPERATOR 环境变量
# 返回 0 成功，1 失败
setup_talos_auth() {
    local script_dir
    script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

    # 复用 worker-deploy 的公共鉴权函数库
    # shellcheck disable=SC1091
    source "${script_dir}/../auth-common.sh"

    local auth_result
    auth_result=$(get_auth_token 2>/dev/null)

    local token operator
    token=$(echo "$auth_result" | jq -r '.token // empty' 2>/dev/null)
    operator=$(echo "$auth_result" | jq -r '.operator // empty' 2>/dev/null)

    if [ -z "$token" ] || [ "$token" = "null" ]; then
        echo "[Talos] ❌ 无法获取 SSO Token，请检查认证配置" >&2
        return 1
    fi

    export TALOS_ACCESS_TOKEN="$token"
    if [ -n "$operator" ] && [ "$operator" != "null" ]; then
        export TALOS_OPERATOR="$operator"
    fi
    echo "[Talos] ✅ 已获取 SSO Token（操作人: ${operator:-unknown}）" >&2
    return 0
}

# ── 统一的 talos 命令执行封装 ─────────────────────────────────

# talos_exec <args...>
# 根据 USE_NPX_TALOS 选择执行方式，TALOS_ACCESS_TOKEN 已通过环境变量注入
talos_exec() {
    if [ "$USE_NPX_TALOS" = "true" ]; then
        npx -y --registry="$TALOS_NPM_REGISTRY" "@ee/talos-cli@${TALOS_CLI_VERSION}" "$@"
    else
        talos "$@"
    fi
}
