#!/bin/bash

# get_talos_flow_status.sh - 查询 Talos 发布流水线状态（用于等待发布完成）
#
# 用法：
#   ./get_talos_flow_status.sh <flow_id> <app_id> [platform]
#
# 参数：
#   flow_id  - 流水线 ID（必填）
#   app_id   - 应用 ID（必填）
#   platform - 平台版本 v1 / v2（默认 v2）
#
# 输出（stdout，JSON）：
#   {
#     "success": true,
#     "flow_id": "...",
#     "status": "success" | "running" | "failed" | "unknown",
#     "raw": { ... talos flow describe 原始输出 ... }
#   }

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/talos-common.sh"

FLOW_ID="$1"
APP_ID="$2"
PLATFORM="${3:-v2}"

if [ -z "$FLOW_ID" ] || [ -z "$APP_ID" ]; then
    echo '{"success": false, "error": "missing_parameters", "message": "flow_id 和 app_id 必填"}'
    exit 1
fi

PLATFORM_FLAG=()
[ "$PLATFORM" = "v1" ] && PLATFORM_FLAG=(-P v1)

if ! detect_talos_cli; then
    echo '{"success": false, "error": "talos_cli_unavailable"}'
    exit 1
fi

if ! setup_talos_auth; then
    echo '{"success": false, "error": "auth_failed"}'
    exit 1
fi

RAW=$(talos_exec --output json flow describe "$FLOW_ID" -a "$APP_ID" "${PLATFORM_FLAG[@]}" 2>/dev/null || echo "{}")

# 注意：talos-cli 的 JSON 输出中，某些插件配置字段（如脚本内容）可能包含未转义的
# 控制字符（字面换行），导致整体不是严格合法的 JSON，无法用 jq 完整解析。
# 因此这里优先尝试标准 JSON 解析取顶层 status 字段；解析失败时，退化为用文本方式
# 只提取顶层的 "status": "xxx" 字段（顶层字段出现在文档较早位置，出问题的内容
# 通常在更深的插件配置里，用首次匹配可以规避该问题）。
STATUS_RAW=$(echo "$RAW" | jq -r '(.status // .state // .result // .data.status // empty) | ascii_downcase' 2>/dev/null)

if [ -z "$STATUS_RAW" ]; then
    # jq 解析失败（非法 JSON），退化为文本提取顶层 status 字段。
    # 注意：flow describe 的返回体里，插件流水线的每个步骤也带有自己的
    # "status" 字段（出现在文档较前位置），顶层流水线的整体 status 字段
    # 则出现在顶层对象里，且其下一行固定是 "currentPipeline" 字段，
    # 因此用该字段作为锚点，取紧邻其上一行的 status 作为顶层状态，避免误匹配。
    STATUS_RAW=$(echo "$RAW" \
        | grep -A1 '"status"[[:space:]]*:[[:space:]]*"[^"]*"' \
        | grep -B1 '"currentPipeline"' \
        | grep '"status"' \
        | sed -E 's/.*"status"[[:space:]]*:[[:space:]]*"([^"]*)".*/\1/' \
        | tr '[:upper:]' '[:lower:]')
fi


NORM="unknown"
case "$STATUS_RAW" in
    *success*|*succeed*|*finish*|*done*|*complete*) NORM="success" ;;
    *fail*|*error*|*cancel*|*abort*)               NORM="failed" ;;
    *running*|*build*|*deploy*|*pending*|*progress*|*wait*) NORM="running" ;;
esac

# raw 字段：仅在合法 JSON 时原样附带，否则置空对象，避免 jq --argjson 报错中断整个脚本
RAW_JSON='{}'
if echo "$RAW" | jq -e . >/dev/null 2>&1; then
    RAW_JSON="$RAW"
fi

jq -n \
    --arg flow_id "$FLOW_ID" \
    --arg status "$NORM" \
    --arg status_raw "${STATUS_RAW:-}" \
    --argjson raw "$RAW_JSON" \
    '{
        success: true,
        flow_id: $flow_id,
        status: $status,
        status_raw: $status_raw,
        raw: $raw
    }'

exit 0

