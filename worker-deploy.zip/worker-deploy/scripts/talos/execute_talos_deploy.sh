#!/bin/bash

# execute_talos_deploy.sh - 执行 Talos 前端发布（泳道化部署）
#
# 用法：
#   ./execute_talos_deploy.sh <app_id> <template_id> <branch> <swimlane> [options]
#
# 参数：
#   app_id      - Talos 应用 ID（必填）
#   template_id - 发布模板 ID（必填）
#   branch      - 发布分支（必填）
#   swimlane    - 泳道名（必填，与后端 cargo 泳道名保持一致，避免多人冲突）
#   options：
#     --target <env>       - 目标环境，默认 newtest
#     --platform <v1|v2>   - 平台版本，默认 v2
#     --sub-app-id <id>    - Talos 1.0 Monorepo 子项目 ID（仅 v1）
#     --note <text>        - 发布备注，默认 "worker-deploy 自动发布"
#     --dry-run            - 预演模式，仅打印将执行的命令
#     --verbose            - 详细输出
#
# 输出（stdout，JSON）：
#   {
#     "status": "success" | "error",
#     "flow_id": "<flowId>",
#     "swimlane": "<swimlane>",
#     "url": "<publish-log url>",
#     "message": "...",
#     "timestamp": "..."
#   }
#
# 关键点：
#   - 通过 --swimlane 参数把前端发布到独立泳道，域名形如
#     <swimlane>-sl-xxx.giant.test.sankuai.com，避免多人共用 newtest 冲突。
#   - 认证复用 worker-deploy 的 auth-common.sh（注入 TALOS_ACCESS_TOKEN）。

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/talos-common.sh"

# ── 解析参数 ─────────────────────────────────────────────────
APP_ID="$1"
TEMPLATE_ID="$2"
BRANCH="$3"
SWIMLANE="$4"
shift 4 2>/dev/null || true

TARGET="newtest"
PLATFORM="v2"
SUB_APP_ID=""
NOTE="worker-deploy 自动发布"
DRY_RUN="false"
VERBOSE="false"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --target)      TARGET="$2"; shift 2 ;;
        --platform)    PLATFORM="$2"; shift 2 ;;
        --sub-app-id)  SUB_APP_ID="$2"; shift 2 ;;
        --note)        NOTE="$2"; shift 2 ;;
        --dry-run)     DRY_RUN="true"; shift ;;
        --verbose)     VERBOSE="true"; shift ;;
        *) echo "Unknown option: $1" >&2; exit 1 ;;
    esac
done

# ── 校验必填参数 ─────────────────────────────────────────────
if [ -z "$APP_ID" ] || [ -z "$TEMPLATE_ID" ] || [ -z "$BRANCH" ] || [ -z "$SWIMLANE" ]; then
    jq -n '{status: "error", error: "missing_parameters", message: "app_id、template_id、branch、swimlane 均为必填"}'
    exit 1
fi

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# 平台参数
PLATFORM_FLAG=()
[ "$PLATFORM" = "v1" ] && PLATFORM_FLAG=(-P v1)

# 子项目参数（仅 v1 Monorepo）
SUB_FLAG=()
[ -n "$SUB_APP_ID" ] && SUB_FLAG=(-s "$SUB_APP_ID")

# 组装 talos flow publish 参数
PUBLISH_ARGS=(flow publish
    -a "$APP_ID"
    "${SUB_FLAG[@]}"
    -t "$TEMPLATE_ID"
    --target "$TARGET"
    -b "$BRANCH"
    --swimlane "$SWIMLANE"
    -n "$NOTE"
    "${PLATFORM_FLAG[@]}")

if [ "$VERBOSE" = "true" ] || [ "$DRY_RUN" = "true" ]; then
    echo "[Talos] 将执行：talos ${PUBLISH_ARGS[*]}" >&2
fi

if [ "$DRY_RUN" = "true" ]; then
    jq -n \
        --arg swimlane "$SWIMLANE" \
        --arg ts "$TIMESTAMP" \
        '{status: "pending", mode: "dry-run", swimlane: $swimlane, message: "预演模式：参数校验通过，未执行发布", timestamp: $ts}'
    exit 0
fi

# ── 检测 talos-cli + 认证 ────────────────────────────────────
if ! detect_talos_cli; then
    jq -n '{status: "error", error: "talos_cli_unavailable", message: "node 环境缺失，无法使用 talos-cli"}'
    exit 1
fi

if ! setup_talos_auth; then
    jq -n '{status: "error", error: "auth_failed", message: "无法获取 SSO Token"}'
    exit 1
fi

# ── 执行发布 ─────────────────────────────────────────────────
echo "[Talos] 触发前端发布到泳道 $SWIMLANE ..." >&2
PUBLISH_RESULT=$(talos_exec --output json "${PUBLISH_ARGS[@]}" 2>/dev/null || echo "")

if [ -z "$PUBLISH_RESULT" ]; then
    jq -n \
        --arg swimlane "$SWIMLANE" \
        --arg ts "$TIMESTAMP" \
        '{status: "error", error: "publish_failed", swimlane: $swimlane, message: "talos flow publish 未返回结果，请检查参数或用 --verbose 排查", timestamp: $ts}'
    exit 1
fi

# 提取 flowId
FLOW_ID=$(echo "$PUBLISH_RESULT" | jq -r '.id // .flowId // .data.id // empty' 2>/dev/null)

# 组装发布日志链接
if [ "$PLATFORM" = "v1" ]; then
    URL="https://talos.sankuai.com/#/project/${APP_ID}/log/${FLOW_ID}"
else
    URL="https://talos-better.sankuai.com/publish-log?appId=${APP_ID}&flowId=${FLOW_ID}"
fi

jq -n \
    --arg flow_id "${FLOW_ID:-}" \
    --arg swimlane "$SWIMLANE" \
    --arg url "$URL" \
    --arg app_id "$APP_ID" \
    --arg branch "$BRANCH" \
    --arg ts "$TIMESTAMP" \
    '{
        status: "success",
        flow_id: $flow_id,
        swimlane: $swimlane,
        app_id: $app_id,
        branch: $branch,
        url: $url,
        message: "前端发布已触发",
        timestamp: $ts
    }'

exit 0
