#!/bin/bash

# fetch_talos_info.sh - 查询当前 git 仓库对应的 Talos 应用与发布模板
#
# 用法：
#   ./fetch_talos_info.sh [project_root] [platform] [target]
#
# 参数：
#   project_root - 仓库根目录（默认当前目录）
#   platform     - 平台版本 v1 / v2（默认 v2）
#   target       - 目标环境（默认 newtest），用于过滤模板
#
# 输出（stdout，JSON）：
#   {
#     "success": true,
#     "platform": "v2",
#     "apps": [ ... talos app ls -c 的原始 JSON ... ],
#     "templates": [ ... talos template ls <appId> 的原始 JSON ... ]
#   }
#
# 说明：
#   - 本脚本只做“查询”，不做发布。appId/templateId 的最终选择由上层
#     （SKILL.md 中的 AI agent）根据数量决定（1 个自动选，多个询问用户）。
#   - 认证通过 talos-common.sh 复用 auth-common.sh 注入 TALOS_ACCESS_TOKEN。

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/talos-common.sh"

PROJECT_ROOT="${1:-$PWD}"
PLATFORM="${2:-v2}"
TARGET="${3:-newtest}"

cd "$PROJECT_ROOT"

# 平台参数
PLATFORM_FLAG=()
if [ "$PLATFORM" = "v1" ]; then
    PLATFORM_FLAG=(-P v1)
fi

# 1. 检测 talos-cli
if ! detect_talos_cli; then
    echo '{"success": false, "error": "talos_cli_unavailable", "message": "node 环境缺失，无法使用 talos-cli"}'
    exit 1
fi

# 2. 获取认证
if ! setup_talos_auth; then
    echo '{"success": false, "error": "auth_failed", "message": "无法获取 SSO Token"}'
    exit 1
fi

# 3. 查询当前仓库对应的 talos 应用
echo "[Talos] 查询当前仓库对应的应用..." >&2
APPS_JSON=$(talos_exec --output json app ls -c "${PLATFORM_FLAG[@]}" 2>/dev/null || echo "")

if [ -z "$APPS_JSON" ]; then
    echo '{"success": false, "error": "app_query_failed", "message": "未查询到当前仓库对应的 Talos 应用，请确认仓库已在 Talos 平台注册"}'
    exit 1
fi

# 提取第一个 appId（供查询模板用；多个应用时上层需询问用户）
APP_ID=$(echo "$APPS_JSON" | jq -r 'if type=="array" then .[0].id // .[0].appId // empty else (.id // .appId // (.data[0].id // .data[0].appId)) // empty end' 2>/dev/null)

TEMPLATES_JSON="[]"
if [ -n "$APP_ID" ] && [ "$APP_ID" != "null" ]; then
    echo "[Talos] 查询应用 $APP_ID 的发布模板（target=$TARGET）..." >&2
    TEMPLATES_JSON=$(talos_exec --output json template ls "$APP_ID" --target "$TARGET" "${PLATFORM_FLAG[@]}" 2>/dev/null || echo "[]")
fi

# 4. 组装输出
jq -n \
    --arg platform "$PLATFORM" \
    --argjson apps "${APPS_JSON:-[]}" \
    --argjson templates "${TEMPLATES_JSON:-[]}" \
    '{
        success: true,
        platform: $platform,
        apps: $apps,
        templates: $templates
    }'

exit 0
