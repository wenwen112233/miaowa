#!/bin/bash

# get_ssoid.sh - 获取认证凭证（支持六种鉴权方式）
#
# 用法：
#   ./get_ssoid.sh [method]
#
# 参数：
#   method - 可选，强制使用特定鉴权方式：
#            env     - 环境变量认证
#            catdesk - CatDesk CLI 认证（CatPaw 自身 SSO 会话）
#            ciba    - CIBA 认证（大象 App 推送）
#            browser - 浏览器 SSO 登录
#            catpaw  - CatPaw 配置文件降级
#
# 输出：
#   JSON 格式的结果到 stdout
#   成功：
#   {
#     "success": true,
#     "token": "xxx",
#     "auth_method": "catdesk",
#     "operator": "zhangsan",
#     "environment": "prod"
#   }
#
#   失败：
#   {
#     "success": false,
#     "error": "auth_failed",
#     "message": "无法获取认证凭证",
#     "auth_method": "none"
#   }
#
# 鉴权方式优先级（决策树）：
#   1. PLUS_ACCESS_TOKEN 环境变量（最高）
#   2. CatDesk CLI 认证（catdesk auth token，自动刷新）
#   3. 已保存的有效 token（~/.config/plus-cli/config.json）
#   4. CatClaw 环境 → CIBA 认证
#      非 CatClaw 环境 → 浏览器 SSO 登录
#   5. NoCode SSO 配置文件（/root/nocode_task/.secret/sso.json）
#   6. CatPaw 配置文件降级（兜底）

set -e

# 获取脚本目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 加载公共鉴权函数库
source "${SCRIPT_DIR}/../auth-common.sh"

# 解析参数
FORCE_METHOD="${1:-}"

# 获取认证凭证
AUTH_RESULT=$(get_auth_token "$FORCE_METHOD")

# 输出结果
echo "$AUTH_RESULT"

# 根据结果设置退出码
if echo "$AUTH_RESULT" | jq -e '.success' > /dev/null 2>&1; then
    exit 0
else
    exit 1
fi
