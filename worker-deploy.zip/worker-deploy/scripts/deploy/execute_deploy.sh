#!/bin/bash

# execute_deploy.sh - 执行部署命令（支持 Plus 和 Cargo）
#
# 用法：
#   ./execute_deploy.sh <deploy_type> <release_id> <template_id> <template_name> <label_type> <label> [appkey] [swimlane] [options]
#
# 参数：
#   deploy_type - 部署类型（plus 或 cargo）
#   release_id - 发布项 ID
#   template_id - 部署模版 ID
#   template_name - 部署模版名称（cargo 需要）
#   label_type - 标签类型（branch、tag 或 commit）
#   label - 要部署的标签值（分支名、tag 名或 commit SHA）
#   appkey - AppKey（cargo 必需，plus 可选）
#   swimlane - 泳道标识符/ProjectID（可选）
#   --change-plan-id <id> - 关联的 MCM 变更计划 ID（可选）
#   --dry-run - 预演模式（不实际执行）
#   --verbose - 详细输出模式
#
# 输出：
#   JSON 格式的部署结果到 stdout
#   - status: "success" | "pending" | "error"
#   - deploy_id: 部署任务 ID（如果成功）
#   - message: 状态信息
#   - timestamp: 操作时间戳

set -e

# 解析参数
DEPLOY_TYPE="$1"
RELEASE_ID="$2"
TEMPLATE_ID="$3"
TEMPLATE_NAME="$4"
LABEL_TYPE="$5"
LABEL="$6"
APPKEY="$7"
SWIMLANE="$8"
CHANGE_PLAN_ID=""
DRY_RUN="false"
VERBOSE="false"

shift 8

# 解析可选参数
while [[ $# -gt 0 ]]; do
    case $1 in
        --change-plan-id)
            CHANGE_PLAN_ID="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN="true"
            shift
            ;;
        --verbose)
            VERBOSE="true"
            shift
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# 验证必需参数
if [ -z "$DEPLOY_TYPE" ] || [ -z "$RELEASE_ID" ] || [ -z "$TEMPLATE_ID" ] || [ -z "$LABEL_TYPE" ] || [ -z "$LABEL" ]; then
    echo "Error: Missing required parameters" >&2
    echo "{\"error\": \"missing_parameters\", \"message\": \"deploy_type, release_id, template_id, label_type, and label are required\"}"
    exit 1
fi

# 验证 deploy_type 值
if [[ ! "$DEPLOY_TYPE" =~ ^(plus|cargo)$ ]]; then
    echo "Error: deploy_type must be either 'plus' or 'cargo'" >&2
    jq -n \
        --arg deploy_type "$DEPLOY_TYPE" \
        '{
            error: "invalid_deploy_type",
            message: "deploy_type must be either '"'"'plus'"'"' or '"'"'cargo'"'"'",
            provided: $deploy_type
        }'
    exit 1
fi

# 验证 label_type 值
if [[ ! "$LABEL_TYPE" =~ ^(branch|tag|commit)$ ]]; then
    echo "Error: label_type must be either 'branch', 'tag' or 'commit'" >&2
    jq -n \
        --arg label_type "$LABEL_TYPE" \
        '{
            error: "invalid_label_type",
            message: "label_type must be either '"'"'branch'"'"', '"'"'tag'"'"' or '"'"'commit'"'"'",
            provided: $label_type
        }'
    exit 1
fi

# 验证参数格式
if ! [[ "$RELEASE_ID" =~ ^[0-9]+$ ]]; then
    echo "Error: release_id must be a number" >&2
    echo "{\"error\": \"invalid_release_id\", \"message\": \"release_id must be numeric\"}"
    exit 1
fi

if ! [[ "$TEMPLATE_ID" =~ ^[0-9]+$ ]]; then
    echo "Error: template_id must be a number" >&2
    echo "{\"error\": \"invalid_template_id\", \"message\": \"template_id must be numeric\"}"
    exit 1
fi

# 准备部署参数
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
DEPLOY_ID="deploy-${RELEASE_ID}-${TEMPLATE_ID}-$(date +%s)"

if [ "$DRY_RUN" = "true" ]; then
    # 预演模式：只验证参数，不执行实际部署
    if [ "$VERBOSE" = "true" ]; then
        echo "Dry-run mode enabled" >&2
        echo "Deploy Type: $DEPLOY_TYPE" >&2
        echo "Release ID: $RELEASE_ID" >&2
        echo "Template ID: $TEMPLATE_ID" >&2
        echo "Template Name: $TEMPLATE_NAME" >&2
        echo "Label Type: $LABEL_TYPE" >&2
        echo "Label Value: $LABEL" >&2
        echo "AppKey: $APPKEY" >&2
        echo "Swimlane: $SWIMLANE" >&2
        echo "Change Plan ID: $CHANGE_PLAN_ID" >&2
    fi
    
    jq -n \
        --arg status "pending" \
        --arg deploy_id "$DEPLOY_ID" \
        --arg message "预演模式：部署参数验证通过，未执行实际部署" \
        --arg timestamp "$TIMESTAMP" \
        --arg mode "dry-run" \
        '{
            status: $status,
            deploy_id: $deploy_id,
            message: $message,
            timestamp: $timestamp,
            mode: $mode
        }'
else
    # 实际部署模式
    # 调用 submit_deploy_job.sh 脚本提交部署任务
    
    if [ "$VERBOSE" = "true" ]; then
        echo "Deployment mode: normal" >&2
        echo "Deploy Type: $DEPLOY_TYPE" >&2
        echo "Release ID: $RELEASE_ID" >&2
        echo "Template ID: $TEMPLATE_ID" >&2
        echo "Template Name: $TEMPLATE_NAME" >&2
        echo "Label Type: $LABEL_TYPE" >&2
        echo "Label Value: $LABEL" >&2
        echo "AppKey: $APPKEY" >&2
        echo "Swimlane: $SWIMLANE" >&2
        echo "Change Plan ID: $CHANGE_PLAN_ID" >&2
    fi
    
    # 获取脚本所在目录
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    SUBMIT_SCRIPT="${SCRIPT_DIR}/submit_deploy_job.sh"
    
    # 检查提交脚本是否存在
    if [ ! -f "$SUBMIT_SCRIPT" ]; then
        echo "Error: submit_deploy_job.sh not found at $SUBMIT_SCRIPT" >&2
        jq -n \
            --arg error "script_not_found" \
            --arg message "submit_deploy_job.sh script not found" \
            '{
                error: $error,
                message: $message
            }'
        exit 1
    fi
    
    # 调用提交脚本
    EXTRA_FLAGS=()
    if [ "$VERBOSE" = "true" ]; then
        EXTRA_FLAGS+=(--verbose)
    fi
if [ -n "$CHANGE_PLAN_ID" ]; then
EXTRA_FLAGS+=(--change-plan-id "$CHANGE_PLAN_ID")
fi
    
    "$SUBMIT_SCRIPT" "$DEPLOY_TYPE" "$RELEASE_ID" "$TEMPLATE_ID" "$TEMPLATE_NAME" "$LABEL_TYPE" "$LABEL" "$APPKEY" "$SWIMLANE" "${EXTRA_FLAGS[@]}"
fi

exit 0
