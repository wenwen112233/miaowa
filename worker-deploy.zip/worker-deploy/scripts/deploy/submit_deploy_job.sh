#!/bin/bash

# submit_deploy_job.sh - 提交部署任务（支持 Plus 和 Cargo）
#
# 用法：
#   ./submit_deploy_job.sh <deploy_type> <release_id> <template_id> <template_name> <label_type> <label> [appkey] [swimlane] [--change-plan-id <id>] [--dry-run] [--verbose]
#
# 参数：
#   deploy_type - 部署类型（plus 或 cargo）
#   release_id - 发布项 ID
#   template_id - 部署模版 ID
#   template_name - 部署模版名称（cargo 需要）
#   label_type - 标签类型（branch、tag 或 commit）
#   label - 要部署的标签值（分支名、tag 名或 commit SHA）
#   appkey - AppKey（cargo 必需，plus 可选）
#   swimlane - 泳道标识符/ProjectID（可选）
#   --change-plan-id <id> - 关联的 MCM 变更计划 ID（可选，skill 模式仅引导与二次提醒，不做强拦截）
#   --dry-run - 预演模式（验证参数但不执行）
#   --verbose - 详细输出模式
#
# 输出：
#   JSON 格式的部署结果到 stdout
#   - status: "success" | "pending" | "error"
#   - job_id: 部署任务 ID
#   - project_id: 项目 ID（从 API 返回的实际 ProjectID）
#   - swimlane: 泳道标识符（仅 Cargo 部署返回，与 project_id 相同，用于写回配置）
#   - job_url: 部署详情页面 URL
#   - message: 状态信息
#   - error_message: 错误信息（如有）
#   
#   Plus 部署响应示例：
#   {
#     "status": "success",
#     "job_id": "job-12345",
#     "project_id": "project-67890",
#     "job_url": "https://catpaw-plus.sankuai.com/job/12345",
#     "deploy_type": "plus",
#     "message": "创建部署任务成功"
#   }
#   
#   Cargo 部署响应示例：
#   {
#     "status": "success",
#     "job_id": "job-12345",
#     "project_id": "project-67890",
#     "swimlane": "project-67890",
#     "job_url": "https://catpaw-plus.sankuai.com/job/12345",
#     "deploy_type": "cargo",
#     "message": "创建部署任务成功"
#   }

set -e

# 获取脚本目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 加载公共鉴权函数库
source "${SCRIPT_DIR}/../auth-common.sh"

# 配置
# 默认指向 catpaw-deploy 线上环境，可通过 PLUS_API_HOST 环境变量覆盖为其他地址
API_HOST="${PLUS_API_HOST:-https://catpaw-plus.sankuai.com}"
DEPLOY_ENDPOINT="${API_HOST}/deploy"
JOB_STATUS_ENDPOINT="${API_HOST}/get/job"

# 解析参数
DEPLOY_TYPE="$1"
RELEASE_ID="$2"
TEMPLATE_ID="$3"
TEMPLATE_NAME="$4"
LABEL_TYPE="$5"
LABEL="$6"
APPKEY="$7"
SWIMLANE="$8"
CHANGE_PLAN_ID=""
DRY_RUN="false"
VERBOSE="false"

shift 8

while [[ $# -gt 0 ]]; do
    case $1 in
        --change-plan-id)
            CHANGE_PLAN_ID="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN="true"
            shift
            ;;
        --verbose)
            VERBOSE="true"
            shift
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# 校验 change-plan-id 必须为数字（允许留空表示不关联）
if [ -n "$CHANGE_PLAN_ID" ] && ! [[ "$CHANGE_PLAN_ID" =~ ^[0-9]+$ ]]; then
    echo "Error: --change-plan-id must be numeric" >&2
    jq -n \
        --arg change_plan_id "$CHANGE_PLAN_ID" \
        '{
            error: "invalid_change_plan_id",
            message: "--change-plan-id must be numeric",
            provided: $change_plan_id
        }'
    exit 1
fi

# 验证必需参数
if [ -z "$DEPLOY_TYPE" ] || [ -z "$RELEASE_ID" ] || [ -z "$TEMPLATE_ID" ] || [ -z "$LABEL_TYPE" ] || [ -z "$LABEL" ]; then
    echo "Error: Missing required parameters" >&2
    jq -n '{
        error: "missing_parameters",
        message: "deploy_type, release_id, template_id, label_type, and label are required"
    }'
    exit 1
fi

# 验证 deploy_type 值
if [[ ! "$DEPLOY_TYPE" =~ ^(plus|cargo)$ ]]; then
    echo "Error: deploy_type must be either 'plus' or 'cargo'" >&2
    jq -n \
        --arg deploy_type "$DEPLOY_TYPE" \
        '{
            error: "invalid_deploy_type",
            message: "deploy_type must be either '"'"'plus'"'"' or '"'"'cargo'"'"'",
            provided: $deploy_type
        }'
    exit 1
fi

# 验证 label_type 值
if [[ ! "$LABEL_TYPE" =~ ^(branch|tag|commit)$ ]]; then
    echo "Error: label_type must be either 'branch', 'tag' or 'commit'" >&2
    jq -n \
        --arg label_type "$LABEL_TYPE" \
        '{
            error: "invalid_label_type",
            message: "label_type must be either '"'"'branch'"'"', '"'"'tag'"'"' or '"'"'commit'"'"'",
            provided: $label_type
        }'
    exit 1
fi

# Cargo 部署需要 appkey
if [ "$DEPLOY_TYPE" = "cargo" ] && [ -z "$APPKEY" ]; then
    echo "Error: appkey is required for cargo deployment" >&2
    jq -n '{
        error: "missing_appkey",
        message: "appkey is required for cargo deployment type"
    }'
    exit 1
fi

# 获取认证凭证（支持四种鉴权方式）
AUTH_RESULT=$(get_auth_token)
if ! echo "$AUTH_RESULT" | jq -e '.success' > /dev/null 2>&1; then
    echo "Error: 认证失败" >&2
    echo "$AUTH_RESULT" | jq '{
        error: .error,
        message: .message,
        auth_method: .auth_method
    }'
    exit 1
fi

# 提取 token 和操作人信息
SSOID=$(echo "$AUTH_RESULT" | jq -r '.token')
AUTH_METHOD=$(echo "$AUTH_RESULT" | jq -r '.auth_method')
OPERATOR=$(echo "$AUTH_RESULT" | jq -r '.operator')

if [ "$VERBOSE" = "true" ]; then
    echo "Deploy Type: $DEPLOY_TYPE" >&2
    echo "Release ID: $RELEASE_ID" >&2
    echo "Template ID: $TEMPLATE_ID" >&2
    echo "Template Name: $TEMPLATE_NAME" >&2
    echo "Label Type: $LABEL_TYPE" >&2
    echo "Label Value: $LABEL" >&2
    echo "AppKey: $APPKEY" >&2
    echo "Swimlane: $SWIMLANE" >&2
    echo "Change Plan ID: $CHANGE_PLAN_ID" >&2
    echo "Auth Method: $AUTH_METHOD" >&2
    echo "Operator: $OPERATOR" >&2
    echo "SSOID: $SSOID" >&2
fi

# 根据 deploy_type 和 label_type 确定请求参数
BRANCH=""
TAG=""
COMMIT=""

if [ "$LABEL_TYPE" = "tag" ]; then
    TAG="$LABEL"
elif [ "$LABEL_TYPE" = "branch" ]; then
    BRANCH="$LABEL"
elif [ "$LABEL_TYPE" = "commit" ]; then
    COMMIT="$LABEL"
fi

if [ "$DRY_RUN" = "true" ]; then
    # 预演模式：只验证参数
    if [ "$VERBOSE" = "true" ]; then
        echo "Dry-run mode: validating parameters" >&2
    fi
    
    jq -n \
        --arg status "pending" \
        --arg message "预演模式：参数验证通过，未提交实际部署" \
        --arg release_id "$RELEASE_ID" \
        --arg template_id "$TEMPLATE_ID" \
        --arg label_type "$LABEL_TYPE" \
        --arg label "$LABEL" \
        '{
            status: $status,
            message: $message,
            mode: "dry-run",
            parameters: {
                release_id: $release_id,
                template_id: $template_id,
                label_type: $label_type,
                label: $label
            }
        }'
    exit 0
fi

# 第 1 步：提交部署任务
if [ "$VERBOSE" = "true" ]; then
    echo "Submitting deploy job to $DEPLOY_ENDPOINT" >&2
fi

# 根据 deploy_type 构建不同的请求 payload
if [ "$DEPLOY_TYPE" = "plus" ]; then
    # Plus 部署请求格式
    DEPLOY_PAYLOAD=$(jq -n \
        --arg DeployType "plus" \
        --arg SSOID "$SSOID" \
        --arg SSOEnv "prod" \
        --arg Branch "$BRANCH" \
        --arg Tag "$TAG" \
        --arg releaseId "$RELEASE_ID" \
        --arg plusTemplateId "$TEMPLATE_ID" \
        --arg ProjectID "$SWIMLANE" \
        --arg changePlanId "$CHANGE_PLAN_ID" \
        '{
            DeployType: $DeployType,
            SSOID: $SSOID,
            SSOEnv: $SSOEnv,
            Resource: {
                Branch: $Branch,
                Tag: $Tag,
                MetaData: (
                    {
                        releaseId: $releaseId,
                        plusTemplateId: $plusTemplateId
                    }
                    + (if $changePlanId != "" then {changePlanId: $changePlanId} else {} end)
                )
            }
        } + (if $ProjectID != "" then {ProjectID: $ProjectID} else {} end)')
elif [ "$DEPLOY_TYPE" = "cargo" ]; then
    # Cargo 部署请求格式（支持 commit、branch、tag）
    DEPLOY_PAYLOAD=$(jq -n \
        --arg DeployType "cargo" \
        --arg SSOID "$SSOID" \
        --arg SSOEnv "prod" \
        --arg Env "test" \
        --arg Commit "$COMMIT" \
        --arg Branch "$BRANCH" \
        --arg Tag "$TAG" \
        --arg AppKey "$APPKEY" \
        --arg ReleaseID "$RELEASE_ID" \
        --arg Template "$TEMPLATE_NAME" \
        --arg ProjectID "$SWIMLANE" \
        --arg changePlanId "$CHANGE_PLAN_ID" \
        '{
            DeployType: $DeployType,
            SSOID: $SSOID,
            SSOEnv: $SSOEnv,
            Env: $Env,
            Resource: {
                Commit: $Commit,
                Branch: $Branch,
                Tag: $Tag,
                MetaData: (
                    {
                        appKeyList: [
                            {
                                AppKey: $AppKey,
                                ReleaseID: ($ReleaseID | tonumber),
                                Template: $Template
                            }
                        ]
                    }
                    + (if $changePlanId != "" then {changePlanId: $changePlanId} else {} end)
                )
            }
        } + (if $ProjectID != "" then {ProjectID: $ProjectID} else {} end)')
fi

if [ "$VERBOSE" = "true" ]; then
    echo "Deploy payload: $DEPLOY_PAYLOAD" >&2
fi

DEPLOY_RESPONSE=$(curl -s --location "$DEPLOY_ENDPOINT" \
    --header 'Content-Type: application/json' \
    --data "$DEPLOY_PAYLOAD")

if [ "$VERBOSE" = "true" ]; then
    echo "Deploy response: $DEPLOY_RESPONSE" >&2
fi

# 检查第一个请求是否成功
DEPLOY_CODE=$(echo "$DEPLOY_RESPONSE" | jq -r '.Code // 0' 2>/dev/null)
if [ "$DEPLOY_CODE" != "200" ]; then
    ERROR_MESSAGE=$(echo "$DEPLOY_RESPONSE" | jq -r '.Message // "Unknown error"' 2>/dev/null)
    # 线上环境拦截时追加管理员联系信息
    if echo "$ERROR_MESSAGE" | grep -q "暂不支持线上环境" 2>/dev/null; then
        if echo "$ERROR_MESSAGE" | grep -q "联系管理员" 2>/dev/null; then
            ERROR_MESSAGE="${ERROR_MESSAGE}（请提 Plus TT: https://tt.sankuai.com/ticket/create?cid=435&tid=4340&iid=9861）"
        else
            ERROR_MESSAGE="${ERROR_MESSAGE}，如需开通请提 Plus TT: https://tt.sankuai.com/ticket/create?cid=435&tid=4340&iid=9861"
        fi
    fi
    jq -n \
        --arg status "error" \
        --arg message "$ERROR_MESSAGE" \
        --arg response "$DEPLOY_RESPONSE" \
        '{
            status: $status,
            message: $message,
            error_type: "deploy_submission_failed",
            api_response: $response
        }'
    exit 1
fi

# 解析第一个响应获取 JobID 和 ProjectID
JOB_ID=$(echo "$DEPLOY_RESPONSE" | jq -r '.Data.JobID // ""' 2>/dev/null)
PROJECT_ID=$(echo "$DEPLOY_RESPONSE" | jq -r '.Data.ProjectID // ""' 2>/dev/null)

if [ -z "$JOB_ID" ] || [ -z "$PROJECT_ID" ]; then
    jq -n \
        --arg status "error" \
        --arg message "Invalid response from deploy API" \
        --arg response "$DEPLOY_RESPONSE" \
        '{
            status: $status,
            message: $message,
            error_type: "invalid_deploy_response",
            api_response: $response
        }'
    exit 1
fi

if [ "$VERBOSE" = "true" ]; then
    echo "Job ID: $JOB_ID" >&2
    echo "Project ID: $PROJECT_ID" >&2
fi

# 第 2 步：查询部署任务状态（轮询直到获取到 JobUrl）
STATUS_URL="${JOB_STATUS_ENDPOINT}?jobID=${JOB_ID}"

# 轮询配置
MAX_RETRIES=60
RETRY_INTERVAL=1
RETRY_COUNT=0

if [ "$VERBOSE" = "true" ]; then
    echo "Polling job status from $STATUS_URL (max $MAX_RETRIES attempts, interval ${RETRY_INTERVAL}s)" >&2
fi

while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
    RETRY_COUNT=$((RETRY_COUNT + 1))
    
    if [ "$VERBOSE" = "true" ]; then
        echo "Attempt $RETRY_COUNT/$MAX_RETRIES..." >&2
    fi
    
    STATUS_RESPONSE=$(curl -s --location "$STATUS_URL")

    if [ "$VERBOSE" = "true" ]; then
        echo "Status response: $STATUS_RESPONSE" >&2
    fi

    # 检查状态查询是否成功
    STATUS_CODE=$(echo "$STATUS_RESPONSE" | jq -r '.Code // 0' 2>/dev/null)
    if [ "$STATUS_CODE" != "200" ]; then
        ERROR_MESSAGE=$(echo "$STATUS_RESPONSE" | jq -r '.Message // "Unknown error"' 2>/dev/null)
        jq -n \
            --arg status "error" \
            --arg message "$ERROR_MESSAGE" \
            --arg response "$STATUS_RESPONSE" \
            '{
                status: $status,
                message: $message,
                error_type: "status_query_failed",
                job_id: "'$JOB_ID'",
                api_response: $response
            }'
        exit 1
    fi

    # 解析状态响应
    JOB_STATUS=$(echo "$STATUS_RESPONSE" | jq -r '.Data.Status // ""' 2>/dev/null)
    RESULT=$(echo "$STATUS_RESPONSE" | jq -r '.Data.Result // {}' 2>/dev/null)
    RESULT_CODE=$(echo "$RESULT" | jq -r '.Code // 0' 2>/dev/null)
    RESULT_MESSAGE=$(echo "$RESULT" | jq -r '.Message // ""' 2>/dev/null)
    
    # 根据 deploy_type 获取不同的 URL
    if [ "$DEPLOY_TYPE" = "cargo" ]; then
        # Cargo 部署返回 StackUrl
        JOB_URL=$(echo "$RESULT" | jq -r '.Data.StackUrl // ""' 2>/dev/null)
    else
        # Plus 部署返回 JobUrl
        JOB_URL=$(echo "$RESULT" | jq -r '.Data.JobUrl // ""' 2>/dev/null)
    fi

    # 判断部署状态
    if [ "$JOB_STATUS" = "failed" ]; then
        # 线上环境拦截时追加管理员联系信息
        if echo "$RESULT_MESSAGE" | grep -q "暂不支持线上环境" 2>/dev/null; then
            if echo "$RESULT_MESSAGE" | grep -q "联系管理员" 2>/dev/null; then
                RESULT_MESSAGE="${RESULT_MESSAGE}（请提 Plus TT: https://tt.sankuai.com/ticket/create?cid=435&tid=4340&iid=9861）"
            else
                RESULT_MESSAGE="${RESULT_MESSAGE}，如需开通请提 Plus TT: https://tt.sankuai.com/ticket/create?cid=435&tid=4340&iid=9861"
            fi
        fi
        if [ "$DEPLOY_TYPE" = "cargo" ]; then
            jq -n \
                --arg status "failed" \
                --arg message "$RESULT_MESSAGE" \
                --arg job_id "$JOB_ID" \
                --arg project_id "$PROJECT_ID" \
                --arg swimlane "$PROJECT_ID" \
                --arg job_url "$JOB_URL" \
                --arg deploy_type "$DEPLOY_TYPE" \
                '{
                    status: $status,
                    message: $message,
                    job_id: $job_id,
                    project_id: $project_id,
                    swimlane: $swimlane,
                    job_url: $job_url,
                    deploy_type: $deploy_type,
                    error_type: "deployment_failed"
                }'
        else
            jq -n \
                --arg status "failed" \
                --arg message "$RESULT_MESSAGE" \
                --arg job_id "$JOB_ID" \
                --arg project_id "$PROJECT_ID" \
                --arg job_url "$JOB_URL" \
                --arg deploy_type "$DEPLOY_TYPE" \
                '{
                    status: $status,
                    message: $message,
                    job_id: $job_id,
                    project_id: $project_id,
                    job_url: $job_url,
                    deploy_type: $deploy_type,
                    error_type: "deployment_failed"
                }'
        fi
        exit 1
    elif [ "$JOB_STATUS" = "success" ] && [ -n "$JOB_URL" ]; then
        # 成功且有 URL（JobUrl 或 StackUrl）
        if [ "$DEPLOY_TYPE" = "cargo" ]; then
            jq -n \
                --arg status "success" \
                --arg message "创建部署任务成功" \
                --arg job_id "$JOB_ID" \
                --arg project_id "$PROJECT_ID" \
                --arg swimlane "$PROJECT_ID" \
                --arg job_url "$JOB_URL" \
                --arg deploy_type "$DEPLOY_TYPE" \
                '{
                    status: $status,
                    message: $message,
                    job_id: $job_id,
                    project_id: $project_id,
                    swimlane: $swimlane,
                    job_url: $job_url,
                    deploy_type: $deploy_type
                }'
        else
            jq -n \
                --arg status "success" \
                --arg message "创建部署任务成功" \
                --arg job_id "$JOB_ID" \
                --arg project_id "$PROJECT_ID" \
                --arg job_url "$JOB_URL" \
                --arg deploy_type "$DEPLOY_TYPE" \
                '{
                    status: $status,
                    message: $message,
                    job_id: $job_id,
                    project_id: $project_id,
                    job_url: $job_url,
                    deploy_type: $deploy_type
                }'
        fi
        exit 0
    elif [ -n "$JOB_URL" ]; then
        # 有 URL 但状态不是成功或失败（pending/processing/running 等）
        if [ "$DEPLOY_TYPE" = "cargo" ]; then
            jq -n \
                --arg status "$JOB_STATUS" \
                --arg message "部署进行中，请查看详情页面" \
                --arg job_id "$JOB_ID" \
                --arg project_id "$PROJECT_ID" \
                --arg swimlane "$PROJECT_ID" \
                --arg job_url "$JOB_URL" \
                --arg deploy_type "$DEPLOY_TYPE" \
                '{
                    status: $status,
                    message: $message,
                    job_id: $job_id,
                    project_id: $project_id,
                    swimlane: $swimlane,
                    job_url: $job_url,
                    deploy_type: $deploy_type
                }'
        else
            jq -n \
                --arg status "$JOB_STATUS" \
                --arg message "部署进行中，请查看详情页面" \
                --arg job_id "$JOB_ID" \
                --arg project_id "$PROJECT_ID" \
                --arg job_url "$JOB_URL" \
                --arg deploy_type "$DEPLOY_TYPE" \
                '{
                    status: $status,
                    message: $message,
                    job_id: $job_id,
                    project_id: $project_id,
                    job_url: $job_url,
                    deploy_type: $deploy_type
                }'
        fi
        exit 0
    else
        # 还没有 URL，继续等待
        if [ "$VERBOSE" = "true" ]; then
            if [ "$DEPLOY_TYPE" = "cargo" ]; then
                echo "StackUrl not available yet, waiting ${RETRY_INTERVAL}s..." >&2
            else
                echo "JobUrl not available yet, waiting ${RETRY_INTERVAL}s..." >&2
            fi
        fi
        
        if [ $RETRY_COUNT -lt $MAX_RETRIES ]; then
            sleep $RETRY_INTERVAL
        fi
    fi
done

# 超时：达到最大重试次数仍未获取到 URL
if [ "$DEPLOY_TYPE" = "cargo" ]; then
    TIMEOUT_MESSAGE="查询部署状态超时，未能获取到 StackUrl"
    jq -n \
        --arg status "timeout" \
        --arg message "$TIMEOUT_MESSAGE" \
        --arg job_id "$JOB_ID" \
        --arg project_id "$PROJECT_ID" \
        --arg swimlane "$PROJECT_ID" \
        --arg deploy_type "$DEPLOY_TYPE" \
        '{
            status: $status,
            message: $message,
            job_id: $job_id,
            project_id: $project_id,
            swimlane: $swimlane,
            deploy_type: $deploy_type,
            error_type: "status_query_timeout"
        }'
else
    TIMEOUT_MESSAGE="查询部署状态超时，未能获取到 JobUrl"
    jq -n \
        --arg status "timeout" \
        --arg message "$TIMEOUT_MESSAGE" \
        --arg job_id "$JOB_ID" \
        --arg project_id "$PROJECT_ID" \
        --arg deploy_type "$DEPLOY_TYPE" \
        '{
            status: $status,
            message: $message,
            job_id: $job_id,
            project_id: $project_id,
            deploy_type: $deploy_type,
            error_type: "status_query_timeout"
        }'
fi
exit 1
