#!/bin/bash

# get_current_branch.sh - 获取当前 git 分支名称及其状态
#
# 用法：
#   ./get_current_branch.sh [repo_path]
#
# 参数：
#   repo_path (可选) - git 仓库路径，默认为当前目录
#
# 输出：
#   JSON 格式的分支信息到 stdout
#   - branch: 当前分支名
#   - sha: 当前 commit SHA（完整形式）
#   - has_uncommitted_changes: 是否有未提交的变更
#   - uncommitted_files: 未提交的文件列表（如果有的话）
#   - timestamp: 获取时间

set -e

# 获取仓库路径
REPO_PATH="${1:-.}"

# 检查是否是 git 仓库
if ! git -C "$REPO_PATH" rev-parse --git-dir > /dev/null 2>&1; then
    echo "Error: Not a git repository: $REPO_PATH" >&2
    echo "{\"error\": \"not_a_git_repo\", \"message\": \"Path is not a git repository\"}"
    exit 1
fi

# 获取当前分支名
BRANCH=$(git -C "$REPO_PATH" rev-parse --abbrev-ref HEAD 2>/dev/null)
if [ -z "$BRANCH" ]; then
    echo "Error: Unable to determine current branch" >&2
    echo "{\"error\": \"unable_to_get_branch\", \"message\": \"Could not determine current git branch\"}"
    exit 1
fi

# 获取当前 commit SHA（完整形式）
SHA=$(git -C "$REPO_PATH" rev-parse HEAD 2>/dev/null)

# 获取当前时间戳
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# 检查是否有未提交的变更（包括 modified、untracked 等所有变更）
HAS_UNCOMMITTED_CHANGES="false"
UNCOMMITTED_FILES_ARRAY="[]"

# 使用 git status 检查工作目录状态
# 如果没有输出 "nothing to commit, working tree clean" 则表示有未提交的变更
GIT_STATUS=$(git -C "$REPO_PATH" status --porcelain)
if [ -n "$GIT_STATUS" ]; then
    HAS_UNCOMMITTED_CHANGES="true"
    # 获取所有未提交文件的列表（提取第3列开始的文件名）
    UNCOMMITTED_FILES_ARRAY=$(echo "$GIT_STATUS" | awk '{print $NF}' | jq -R -s -c 'split("\n") | map(select(length > 0))')
fi

# 输出结果
jq -n \
    --arg branch "$BRANCH" \
    --arg sha "$SHA" \
    --arg timestamp "$TIMESTAMP" \
    --arg has_uncommitted_changes "$HAS_UNCOMMITTED_CHANGES" \
    --argjson uncommitted_files "$UNCOMMITTED_FILES_ARRAY" \
    '{
        branch: $branch,
        sha: $sha,
        has_uncommitted_changes: ($has_uncommitted_changes == "true"),
        uncommitted_files: $uncommitted_files,
        timestamp: $timestamp
    }'

exit 0
