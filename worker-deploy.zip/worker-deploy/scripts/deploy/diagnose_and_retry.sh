#!/bin/bash

# diagnose_and_retry.sh — 部署失败后自动诊断 + 重试
#
# 依赖：cargo-cli（npm install -g @ee/cargo-cli）
#
# 用法：
#   ./diagnose_and_retry.sh <stack_uuid> <appkey> <release_name> <branch> [template] [max_retries]
#
# 流程：
#   1. cargo-cli stack status 获取部署状态和 runnerUUID
#   2. 如果有 runnerUUID → cargo-cli stack deploy-diagnose（AI 诊断）
#   3. 根据诊断结果决定重试策略：
#      - 分支不存在 → 提示推送分支，不重试
#      - 构建缓存问题 → 加 --force 重试
#      - 资源不足/机器问题 → 等待 30 秒后重试
#      - 其他 → 直接重试一次
#   4. 重试后继续轮询，最多 max_retries 次（默认 1 次）
#
# 输出：JSON 格式
#   成功：{"success": true, "status": "running", "swimlane": "...", "runner_uuid": "..."}
#   失败：{"success": false, "error": "...", "diagnosis": "...", "retried": true/false}

set -euo pipefail

STACK_UUID="$1"
APPKEY="$2"
RELEASE_NAME="$3"
BRANCH="$4"
TEMPLATE="${5:-test}"
MAX_RETRIES="${6:-1}"

RETRY_COUNT=0
POLL_INTERVAL=15
MAX_POLL_TIME=300  # 5 分钟
MAX_POLL_ATTEMPTS=$((MAX_POLL_TIME / POLL_INTERVAL))

# 获取脚本目录（用于日志输出）
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log() {
    echo "[Diagnose] $*" >&2
}

output_json() {
    local success="$1"
    local rest="$2"
    if [ "$success" = "true" ]; then
        echo "{\"success\": true${rest}}"
    else
        echo "{\"success\": false${rest}}"
    fi
}

# 等待部署达到终态（running / failed / error）
wait_for_terminal_state() {
    local uuid="$1"
    local attempt=0
    local status=""
    local runner_uuid=""
    local err_reason=""

    while [ $attempt -lt $MAX_POLL_ATTEMPTS ]; do
        attempt=$((attempt + 1))
        sleep $POLL_INTERVAL

        local status_json
        status_json=$(cargo-cli --output json stack status --uuid "$uuid" 2>/dev/null)

        if [ -z "$status_json" ]; then
            log "无法获取状态（第 $attempt 次），继续等待..."
            continue
        fi

        status=$(echo "$status_json" | jq -r '.stackStatus // "unknown"')
        local running=$(echo "$status_json" | jq -r '.runningCount // 0')
        local error=$(echo "$status_json" | jq -r '.errorCount // 0')
        local total=$(echo "$status_json" | jq -r '.totalCount // 0')

        runner_uuid=$(echo "$status_json" | jq -r '.runners[0].runnerUUID // empty')
        err_reason=$(echo "$status_json" | jq -r '.runners[0].errReason // empty')
        local runner_status=$(echo "$status_json" | jq -r '.runners[0].status // "unknown"')

        log "[$((attempt * POLL_INTERVAL))s] 状态: $status | runner: $runner_status | running: $running | error: $error"

        # 检查是否达到终态
        if [ "$running" -gt 0 ] 2>/dev/null; then
            log "✅ 部署成功（running）"
            echo "$status_json"
            return 0
        fi

        if [ "$error" -gt 0 ] 2>/dev/null; then
            log "❌ 部署失败（error）"
            echo "$status_json"
            return 1
        fi

        # runner 状态为 failed
        if [ "$runner_status" = "failed" ] || [ "$runner_status" = "error" ]; then
            log "❌ runner 状态: $runner_status"
            echo "$status_json"
            return 1
        fi
    done

    log "⏱️ 等待超时（${MAX_POLL_TIME}秒）"
    echo "$status_json"
    return 2
}

# 执行 AI 诊断
run_diagnosis() {
    local runner_uuid="$1"

    if [ -z "$runner_uuid" ]; then
        log "runnerUUID 为空，无法执行 AI 诊断"
        echo '{"diagnoseAvailable": false, "diagnose": []}'
        return
    fi

    log "正在执行 AI 诊断（runnerUUID: $runner_uuid）..."
    local diagnose_result
    diagnose_result=$(cargo-cli --output json stack deploy-diagnose --runner-uuid "$runner_uuid" 2>/dev/null)

    if [ -z "$diagnose_result" ]; then
        log "AI 诊断无返回"
        echo '{"diagnoseAvailable": false, "diagnose": []}'
        return
    fi

    local available=$(echo "$diagnose_result" | jq -r '.diagnoseAvailable // false')
    local diagnose_count=$(echo "$diagnose_result" | jq -r '.diagnose | length // 0')

    if [ "$available" = "true" ] && [ "$diagnose_count" -gt 0 ] 2>/dev/null; then
        log "✅ AI 诊断有结果"
        echo "$diagnose_result" | jq '{diagnoseAvailable: true, diagnose: .diagnose}'
    else
        log "AI 诊断无命中，尝试读取构建日志..."
        # 尝试获取构建状态
        local build_status
        build_status=$(cargo-cli --output json stack build-status --uuid "$STACK_UUID" 2>/dev/null)
        local task_uuid=$(echo "$build_status" | jq -r '.[0].taskUUID // empty' 2>/dev/null)

        if [ -n "$task_uuid" ]; then
            log "查看构建日志（taskUUID: $task_uuid）..."
            local build_log
            build_log=$(cargo-cli --output json stack build-log --task-uuid "$task_uuid" 2>/dev/null)
            local fail_reason=$(echo "$build_log" | jq -r '.failReason // .errReason // empty' 2>/dev/null)
            if [ -n "$fail_reason" ]; then
                log "构建失败原因: $fail_reason"
                echo "{\"diagnoseAvailable\": true, \"diagnose\": [{\"errReason\": \"$fail_reason\", \"proposedSolution\": \"检查构建配置\"}]}"
                return
            fi
        fi

        # 尝试读取深度日志
        if [ -n "$runner_uuid" ]; then
            local log_list
            log_list=$(cargo-cli --output json stack deploy-log-list --runner-uuid "$runner_uuid" 2>/dev/null)
            local first_log=$(echo "$log_list" | jq -r '.[0].path // empty' 2>/dev/null)
            if [ -n "$first_log" ]; then
                local log_content
                log_content=$(cargo-cli --output json stack deploy-log-read --runner-uuid "$runner_uuid" --path "$first_log" --lines -50 2>/dev/null)
                local log_tail=$(echo "$log_content" | jq -r '.content // empty' 2>/dev/null | tail -20)
                if [ -n "$log_tail" ]; then
                    log "日志尾部内容:\n$log_tail"
                    echo "{\"diagnoseAvailable\": true, \"diagnose\": [{\"errReason\": \"日志异常\", \"proposedSolution\": \"查看日志详情\"}], \"logTail\": \"$log_tail\"}"
                    return
                fi
            fi
        fi

        echo '{"diagnoseAvailable": false, "diagnose": []}'
    fi
}

# 根据诊断结果决定重试策略
decide_retry_strategy() {
    local diagnosis="$1"
    local err_reason="$2"

    local available=$(echo "$diagnosis" | jq -r '.diagnoseAvailable // false')
    local first_solution=$(echo "$diagnosis" | jq -r '.diagnose[0].proposedSolution // empty' 2>/dev/null)
    local first_reason=$(echo "$diagnosis" | jq -r '.diagnose[0].errReason // empty' 2>/dev/null)

    # 合并 err_reason
    local combined_reason="${first_reason:-${err_reason:-unknown}}"

    # 策略1：分支不存在 → 不重试
    if echo "$combined_reason" | grep -qiE "分支不存在|branch.*not.*exist"; then
        echo "no_retry_branch"
        return
    fi

    # 策略2：构建缓存/编译问题 → force 重试
    if echo "$combined_reason" | grep -qiE "cache|缓存|compile|编译|build.*fail|构建.*失败"; then
        echo "retry_force"
        return
    fi

    # 策略3：资源不足/机器调度 → 等待后重试
    if echo "$combined_reason" | grep -qiE "resource|资源|machine|机器|schedule|调度|no.*available"; then
        echo "retry_wait"
        return
    fi

    # 策略4：其他 → 直接重试
    if [ "$available" = "true" ]; then
        echo "retry_normal"
        return
    fi

    # 无诊断结果 → 默认直接重试
    echo "retry_normal"
}

# 主流程
main() {
    if [ -z "$STACK_UUID" ] || [ -z "$APPKEY" ] || [ -z "$RELEASE_NAME" ] || [ -z "$BRANCH" ]; then
        output_json false ", \"error\": \"参数不完整\""
        exit 1
    fi

    # 检查 cargo-cli 是否可用
    if ! command -v cargo-cli >/dev/null 2>&1; then
        log "cargo-cli 未安装，无法诊断"
        output_json false ", \"error\": \"cargo-cli not installed\""
        exit 1
    fi

    # 首先获取当前状态
    local status_json
    status_json=$(cargo-cli --output json stack status --uuid "$STACK_UUID" 2>/dev/null)

    if [ -z "$status_json" ]; then
        log "无法获取编排状态"
        output_json false ", \"error\": \"无法获取编排状态\""
        exit 1
    fi

    local running=$(echo "$status_json" | jq -r '.runningCount // 0')
    local error=$(echo "$status_json" | jq -r '.errorCount // 0')
    local runner_uuid=$(echo "$status_json" | jq -r '.runners[0].runnerUUID // empty')
    local err_reason=$(echo "$status_json" | jq -r '.runners[0].errReason // empty')
    local runner_status=$(echo "$status_json" | jq -r '.runners[0].status // "unknown"')
    local swimlane=$(echo "$status_json" | jq -r '.swimlane // empty')

    # 如果已经在 running 状态，直接返回成功
    if [ "$running" -gt 0 ] 2>/dev/null; then
        log "✅ 部署已成功（running）"
        output_json true ", \"status\": \"running\", \"swimlane\": \"$swimlane\", \"runner_uuid\": \"$runner_uuid\""
        exit 0
    fi

    # 如果还在 deploying/creating，先等待达到终态
    if [ "$runner_status" = "deploying" ] || [ "$runner_status" = "creating" ] || [ "$runner_status" = "pending" ]; then
        log "部署仍在进行中，等待达到终态..."
        status_json=$(wait_for_terminal_state "$STACK_UUID")
        local wait_result=$?

        running=$(echo "$status_json" | jq -r '.runningCount // 0')
        error=$(echo "$status_json" | jq -r '.errorCount // 0')
        runner_uuid=$(echo "$status_json" | jq -r '.runners[0].runnerUUID // empty')
        err_reason=$(echo "$status_json" | jq -r '.runners[0].errReason // empty')
        runner_status=$(echo "$status_json" | jq -r '.runners[0].status // "unknown"')

        if [ "$running" -gt 0 ] 2>/dev/null; then
            log "✅ 等待后部署成功"
            output_json true ", \"status\": \"running\", \"swimlane\": \"$swimlane\", \"runner_uuid\": \"$runner_uuid\""
            exit 0
        fi

        if [ "$wait_result" -eq 2 ]; then
            log "等待超时"
            output_json false ", \"error\": \"等待超时\", \"status\": \"$runner_status\""
            exit 1
        fi
    fi

    # 部署失败，执行诊断
    log "❌ 部署失败（runner: $runner_status, reason: $err_reason）"
    log "开始自动诊断..."

    local diagnosis
    diagnosis=$(run_diagnosis "$runner_uuid")

    local diag_available=$(echo "$diagnosis" | jq -r '.diagnoseAvailable // false')
    local diag_reason=$(echo "$diagnosis" | jq -r '.diagnose[0].errReason // empty' 2>/dev/null)
    local diag_solution=$(echo "$diagnosis" | jq -r '.diagnose[0].proposedSolution // empty' 2>/dev/null)

    log "诊断结果: available=$diag_available, reason=$diag_reason, solution=$diag_solution"

    # 决定重试策略
    local strategy
    strategy=$(decide_retry_strategy "$diagnosis" "$err_reason")
    log "重试策略: $strategy"

    if [ "$strategy" = "no_retry_branch" ]; then
        output_json false ", \"error\": \"分支不存在，请推送分支后重试\", \"diagnosis\": \"$diag_reason\", \"retried\": false"
        exit 1
    fi

    # 执行重试
    if [ $RETRY_COUNT -ge $MAX_RETRIES ]; then
        log "已达到最大重试次数 ($MAX_RETRIES)"
        output_json false ", \"error\": \"部署失败\", \"diagnosis\": \"${diag_reason:-$err_reason}\", \"retried\": true"
        exit 1
    fi

    RETRY_COUNT=$((RETRY_COUNT + 1))

    # 根据策略执行重试
    local deploy_cmd="cargo-cli --output json stack deploy --uuid $STACK_UUID --services"

    local services_json="[{\"appkey\":\"$APPKEY\",\"release\":\"$RELEASE_NAME\",\"branch\":\"$BRANCH\",\"template\":\"$TEMPLATE\"}]"

    case "$strategy" in
        retry_force)
            log "🔄 使用 --force 强制重新构建..."
            deploy_output=$(cargo-cli stack deploy --uuid "$STACK_UUID" --services "$services_json" --force 2>&1)
            ;;
        retry_wait)
            log "⏳ 等待 30 秒后重试..."
            sleep 30
            deploy_output=$(cargo-cli stack deploy --uuid "$STACK_UUID" --services "$services_json" 2>&1)
            ;;
        retry_normal|*)
            log "🔄 直接重试..."
            deploy_output=$(cargo-cli stack deploy --uuid "$STACK_UUID" --services "$services_json" 2>&1)
            ;;
    esac

    local deploy_exit=$?
    if [ $deploy_exit -ne 0 ]; then
        log "重试部署触发失败"
        output_json false ", \"error\": \"重试部署触发失败\", \"diagnosis\": \"${diag_reason:-$err_reason}\", \"retried\": true"
        exit 1
    fi

    log "✅ 重试已触发，等待部署完成..."

    # 等待重试后的部署完成
    status_json=$(wait_for_terminal_state "$STACK_UUID")
    local wait_result=$?

    running=$(echo "$status_json" | jq -r '.runningCount // 0')
    runner_uuid=$(echo "$status_json" | jq -r '.runners[0].runnerUUID // empty')
    swimlane=$(echo "$status_json" | jq -r '.swimlane // empty')

    if [ "$running" -gt 0 ] 2>/dev/null; then
        log "✅ 重试后部署成功！"
        output_json true ", \"status\": \"running\", \"swimlane\": \"$swimlane\", \"runner_uuid\": \"$runner_uuid\", \"retried\": true"
        exit 0
    fi

    log "❌ 重试后仍然失败"
    output_json false ", \"error\": \"重试后仍然失败\", \"diagnosis\": \"${diag_reason:-$err_reason}\", \"retried\": true"
    exit 1
}

main
