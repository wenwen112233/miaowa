#!/bin/bash

# commit_to_temp_branch.sh - 将未提交的变更提交到临时分支并推送
#
# 用法：
#   ./commit_to_temp_branch.sh [repo_path]
#
# 参数：
#   repo_path (可选) - git 仓库路径，默认为当前目录
#
# 输出：
#   JSON 格式的结果到 stdout
#   - status: "success" | "error"
#   - original_branch: 原始分支名
#   - temp_branch: 临时分支名
#   - temp_branch_url: 临时分支推送 URL
#   - commit_sha: 新提交的 SHA
#   - message: 操作信息

set -e

# 获取仓库路径
REPO_PATH="${1:-.}"

# 检查是否是 git 仓库
if ! git -C "$REPO_PATH" rev-parse --git-dir > /dev/null 2>&1; then
    echo "Error: Not a git repository: $REPO_PATH" >&2
    jq -n \
        --arg status "error" \
        --arg message "Path is not a git repository" \
        '{
            status: $status,
            error: "not_a_git_repo",
            message: $message
        }'
    exit 1
fi

# 获取原始分支名
ORIGINAL_BRANCH=$(git -C "$REPO_PATH" rev-parse --abbrev-ref HEAD 2>/dev/null)
if [ -z "$ORIGINAL_BRANCH" ]; then
    echo "Error: Unable to determine current branch" >&2
    jq -n \
        --arg status "error" \
        --arg message "Could not determine current git branch" \
        '{
            status: $status,
            error: "unable_to_get_branch",
            message: $message
        }'
    exit 1
fi

# 构建临时分支名
TEMP_BRANCH="${ORIGINAL_BRANCH}-temp"

# 获取仓库 URL
REPO_URL=$(git -C "$REPO_PATH" config --get remote.origin.url 2>/dev/null)
if [ -z "$REPO_URL" ]; then
    echo "Error: Unable to get remote origin URL" >&2
    jq -n \
        --arg status "error" \
        --arg message "Could not determine remote origin URL" \
        '{
            status: $status,
            error: "no_remote_url",
            message: $message
        }'
    exit 1
fi

# 尝试执行临时分支提交流程，并获取临时分支的 commit SHA
COMMIT_SHA=""
if ! (
    cd "$REPO_PATH"
    # 创建临时分支
    git checkout -b "$TEMP_BRANCH" 2>/dev/null || git checkout "$TEMP_BRANCH" 2>/dev/null
    # 添加所有变更
    git add .
    # 提交
    git commit -m "temp deploy branch" 2>/dev/null || true
    # 强制推送到远程
    git push --force origin "$TEMP_BRANCH" 2>/dev/null
    # 获取临时分支的 commit SHA（在切回原始分支之前）
    git rev-parse HEAD > /tmp/temp_commit_sha_$$.txt 2>/dev/null
    # 生成 patch 文件
    git diff HEAD^ > commit.patch 2>/dev/null || true
    # 返回原始分支
    git checkout "$ORIGINAL_BRANCH" 2>/dev/null
    # 应用 patch
    git apply commit.patch 2>/dev/null || true
    # 清理 patch 文件
    rm -f commit.patch
    # 删除本地临时分支
    git branch -D "$TEMP_BRANCH" 2>/dev/null || true
); then
    echo "Error: Failed to create temporary branch and commit changes" >&2
    rm -f /tmp/temp_commit_sha_$$.txt
    jq -n \
        --arg status "error" \
        --arg message "Failed to create temporary branch or push changes" \
        --arg original_branch "$ORIGINAL_BRANCH" \
        '{
            status: $status,
            error: "commit_failed",
            message: $message,
            original_branch: $original_branch
        }'
    exit 1
fi

# 读取临时分支的 commit SHA
if [ -f /tmp/temp_commit_sha_$$.txt ]; then
    COMMIT_SHA=$(cat /tmp/temp_commit_sha_$$.txt)
    rm -f /tmp/temp_commit_sha_$$.txt
else
    COMMIT_SHA=""
fi

# 获取当前时间戳
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# 输出成功结果
jq -n \
    --arg status "success" \
    --arg original_branch "$ORIGINAL_BRANCH" \
    --arg temp_branch "$TEMP_BRANCH" \
    --arg temp_branch_url "$REPO_URL" \
    --arg commit_sha "$COMMIT_SHA" \
    --arg message "Successfully committed changes to temporary branch and pushed to remote" \
    --arg timestamp "$TIMESTAMP" \
    '{
        status: $status,
        original_branch: $original_branch,
        temp_branch: $temp_branch,
        temp_branch_url: $temp_branch_url,
        commit_sha: $commit_sha,
        message: $message,
        timestamp: $timestamp
    }'

exit 0
