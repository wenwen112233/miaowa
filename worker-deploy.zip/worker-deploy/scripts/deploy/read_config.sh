#!/bin/bash

# read_config.sh - 读取并解析 deploy-config.json
#
# 用法：
#   ./read_config.sh [config_file_path]
#
# 参数：
#   config_file_path (可选) - deploy-config.json 的完整路径，默认为 ./deploy-config.json
#
# 输出：
#   成功：JSON 格式的配置信息输出到 stdout
#   失败：错误信息输出到 stderr，退出码非 0

set -e

# 获取配置文件路径
# 优先级：命令行参数 > skill 目录 > 项目根目录
if [ -n "$1" ]; then
    CONFIG_FILE="$1"
    if [ -d "$CONFIG_FILE" ]; then
        CONFIG_FILE="$CONFIG_FILE/deploy-config.json"
    fi
else
    # 检查 skill 目录中的配置
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    SKILL_DIR="$(dirname "$SCRIPT_DIR")"
    SKILL_CONFIG="${SKILL_DIR}/deploy-config.json"
    
    # 检查项目根目录中的配置
    PROJECT_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || echo '.')"
    PROJECT_CONFIG="${PROJECT_ROOT}/deploy-config.json"
    
    # 优先使用 skill 目录中的配置，其次是项目根目录
    if [ -f "$SKILL_CONFIG" ]; then
        CONFIG_FILE="$SKILL_CONFIG"
    elif [ -f "$PROJECT_CONFIG" ]; then
        CONFIG_FILE="$PROJECT_CONFIG"
    else
        CONFIG_FILE="$SKILL_CONFIG"  # 默认指向 skill 目录
    fi
fi

# 检查文件是否存在
if [ ! -f "$CONFIG_FILE" ]; then
    echo "Error: Config file not found: $CONFIG_FILE" >&2
    echo "{\"error\": \"config_not_found\", \"message\": \"Config file not found at $CONFIG_FILE\"}" | jq '.' 2>/dev/null || echo '{"error": "config_not_found", "message": "Config file not found"}'
    exit 2
fi

# 尝试解析 JSON 并验证格式
if ! jq empty "$CONFIG_FILE" 2>/dev/null; then
    echo "Error: Invalid JSON format in $CONFIG_FILE" >&2
    echo "{\"error\": \"invalid_json\", \"message\": \"Config file contains invalid JSON\"}" | jq '.' 2>/dev/null || echo '{"error": "invalid_json"}'
    exit 1
fi

# 读取并输出配置
jq '{config_file: $CONFIG_FILE, deploy_type, release, label, label_type, swimlane}' \
    --arg CONFIG_FILE "$CONFIG_FILE" \
    "$CONFIG_FILE" 2>/dev/null || {
    # 如果 jq 处理失败，直接输出原始配置
    cat "$CONFIG_FILE"
}

exit 0
