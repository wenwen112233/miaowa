#!/bin/bash

# validate_config.sh - 验证配置文件的完整性和有效性
#
# 用法：
#   ./validate_config.sh [config_file_path]
#
# 参数：
#   config_file_path (可选) - deploy-config.json 的完整路径，默认为 ./deploy-config.json
#
# 输出：
#   JSON 格式的验证结果到 stdout
#   - is_valid: true/false - 配置是否有效
#   - is_complete: true/false - 配置是否完整
#   - missing_fields: [] - 缺少的必需字段列表
#   - errors: [] - 发现的错误列表
#   - config: {} - 解析的配置内容（如果有效）

set -e

# 获取配置文件路径
# 优先级：命令行参数 > skill 目录 > 项目根目录
if [ -n "$1" ]; then
    CONFIG_FILE="$1"
    if [ -d "$CONFIG_FILE" ]; then
        CONFIG_FILE="$CONFIG_FILE/deploy-config.json"
    fi
else
    # 检查 skill 目录中的配置
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    SKILL_DIR="$(dirname "$SCRIPT_DIR")"
    SKILL_CONFIG="${SKILL_DIR}/deploy-config.json"
    
    # 检查项目根目录中的配置
    PROJECT_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || echo '.')"
    PROJECT_CONFIG="${PROJECT_ROOT}/deploy-config.json"
    
    # 优先使用 skill 目录中的配置，其次是项目根目录
    if [ -f "$SKILL_CONFIG" ]; then
        CONFIG_FILE="$SKILL_CONFIG"
    elif [ -f "$PROJECT_CONFIG" ]; then
        CONFIG_FILE="$PROJECT_CONFIG"
    else
        CONFIG_FILE="$SKILL_CONFIG"  # 默认指向 skill 目录
    fi
fi

# 初始化结果对象
IS_VALID="false"
IS_COMPLETE="false"
MISSING_FIELDS=()
ERRORS=()

# 检查文件是否存在
if [ ! -f "$CONFIG_FILE" ]; then
    ERRORS+=("config_file_not_found: Config file not found at $CONFIG_FILE")
else
    # 验证 JSON 格式
    if ! jq empty "$CONFIG_FILE" 2>/dev/null; then
        ERRORS+=("invalid_json: Config file contains invalid JSON")
    else
        IS_VALID="true"
        
        # 检查必需字段
        REQUIRED_FIELDS=("deploy_type" "release" "label" "label_type")
        IS_COMPLETE="true"
        
        for field in "${REQUIRED_FIELDS[@]}"; do
            if [ "$field" = "deploy_type" ]; then
                deploy_type=$(jq -r ".deploy_type // \"\"" "$CONFIG_FILE" 2>/dev/null)
                if [ -z "$deploy_type" ] || [ "$deploy_type" = "null" ]; then
                    MISSING_FIELDS+=("deploy_type")
                    IS_COMPLETE="false"
                fi
                # 验证 deploy_type 值
                if [[ ! "$deploy_type" =~ ^(plus|cargo)$ ]] && [ -n "$deploy_type" ] && [ "$deploy_type" != "null" ]; then
                    ERRORS+=("invalid_deploy_type: deploy_type must be either 'plus' or 'cargo'")
                    IS_VALID="false"
                fi
            elif [ "$field" = "release" ]; then
                # release 是数组，检查至少有一个元素
                release_length=$(jq -r ".release | length // 0" "$CONFIG_FILE" 2>/dev/null)
                if [ "$release_length" = "0" ] || [ "$release_length" = "null" ]; then
                    MISSING_FIELDS+=("release")
                    IS_COMPLETE="false"
                else
                    # 检查第一个 release 元素的必需字段
                    release_id=$(jq -r ".release[0].release_id // \"\"" "$CONFIG_FILE" 2>/dev/null)
                    release_name=$(jq -r ".release[0].release_name // \"\"" "$CONFIG_FILE" 2>/dev/null)
                    template_id=$(jq -r ".release[0].template.id // \"\"" "$CONFIG_FILE" 2>/dev/null)
                    template_name=$(jq -r ".release[0].template.name // \"\"" "$CONFIG_FILE" 2>/dev/null)
                    template_env=$(jq -r ".release[0].template.env // \"\"" "$CONFIG_FILE" 2>/dev/null)
                    
                    if [ -z "$release_id" ] || [ "$release_id" = "null" ]; then
                        MISSING_FIELDS+=("release[0].release_id")
                        IS_COMPLETE="false"
                    fi
                    if [ -z "$release_name" ] || [ "$release_name" = "null" ]; then
                        MISSING_FIELDS+=("release[0].release_name")
                        IS_COMPLETE="false"
                    fi
                    if [ -z "$template_id" ] || [ "$template_id" = "null" ]; then
                        MISSING_FIELDS+=("release[0].template.id")
                        IS_COMPLETE="false"
                    fi
                    if [ -z "$template_name" ] || [ "$template_name" = "null" ]; then
                        MISSING_FIELDS+=("release[0].template.name")
                        IS_COMPLETE="false"
                    fi
                    if [ -z "$template_env" ] || [ "$template_env" = "null" ]; then
                        MISSING_FIELDS+=("release[0].template.env")
                        IS_COMPLETE="false"
                    fi
                    
                    # 验证环境值
                    if [[ ! "$template_env" =~ ^(prod|staging|test|dev|beta)$ ]] && [ -n "$template_env" ] && [ "$template_env" != "null" ]; then
                        ERRORS+=("invalid_environment: release[0].template.env must be one of: prod, staging, test, dev, beta")
                        IS_VALID="false"
                    fi
                fi
            else
                value=$(jq -r ".${field} // \"\"" "$CONFIG_FILE" 2>/dev/null)
                if [ -z "$value" ] || [ "$value" = "null" ]; then
                    MISSING_FIELDS+=("$field")
                    IS_COMPLETE="false"
                fi
            fi
        done
        
        # 验证 label_type 值
        label_type=$(jq -r ".label_type // \"\"" "$CONFIG_FILE" 2>/dev/null)
        if [[ ! "$label_type" =~ ^(branch|tag|commit)$ ]] && [ -n "$label_type" ] && [ "$label_type" != "null" ]; then
            ERRORS+=("invalid_label_type: label_type must be either 'branch', 'tag' or 'commit'")
            IS_VALID="false"
        fi
        
        # swimlane 是可选字段，不需要验证是否存在，但如果存在则验证是否为字符串
        swimlane=$(jq -r ".swimlane // \"\"" "$CONFIG_FILE" 2>/dev/null)
        if [ -n "$swimlane" ] && [ "$swimlane" != "null" ]; then
            # swimlane 存在且有值，检查是否为有效字符串（非空）
            if [ -z "$swimlane" ]; then
                ERRORS+=("invalid_swimlane: swimlane must be a non-empty string if provided")
                IS_VALID="false"
            fi
        fi
    fi
fi

# 生成输出 JSON
{
    echo "{"
    echo "  \"is_valid\": $IS_VALID,"
    echo "  \"is_complete\": $IS_COMPLETE,"
    echo "  \"missing_fields\": ["
    
    # 输出缺失字段
    if [ ${#MISSING_FIELDS[@]} -gt 0 ]; then
        for i in "${!MISSING_FIELDS[@]}"; do
            echo -n "    \"${MISSING_FIELDS[$i]}\""
            if [ $i -lt $((${#MISSING_FIELDS[@]} - 1)) ]; then
                echo ","
            else
                echo ""
            fi
        done
    fi
    
    echo "  ],"
    echo "  \"errors\": ["
    
    # 输出错误列表
    if [ ${#ERRORS[@]} -gt 0 ]; then
        for i in "${!ERRORS[@]}"; do
            echo -n "    \"${ERRORS[$i]}\""
            if [ $i -lt $((${#ERRORS[@]} - 1)) ]; then
                echo ","
            else
                echo ""
            fi
        done
    fi
    
    echo "  ]"
    
    # 如果有效，添加配置内容
    if [ "$IS_VALID" = "true" ]; then
        echo ","
        echo "  \"config\": "
        jq '{deploy_type, release, label, label_type}' "$CONFIG_FILE" | sed 's/^/  /'
    fi
    
    echo "}"
} | jq '.' 2>/dev/null

exit 0
