#!/bin/bash

# auth-common.sh - 公共鉴权函数库
#
# 实现按 Wiki 决策树的五种鉴权方式：
# 方式1：环境变量认证（PLUS_ACCESS_TOKEN）- 最高优先级
# 方式2：CIBA 认证（大象 App 推送确认）- CatClaw/OpenClaw 环境默认
# 方式3：浏览器 SSO 登录（OAuth2 OIDC）- 非 CatClaw 环境默认
# 方式4：NoCode SSO 配置文件认证 - 沙箱 NoCode 环境兜底
# 方式5：CatPaw 配置文件降级认证 - 最低优先级兜底
#
# CIBA 接口说明：
#   沙箱环境使用 supabase.sankuai.com 封装接口（与 talos-cli 一致）
#   接入文档：https://km.sankuai.com/collabpage/2732221228
#
# 用法：
#   source auth-common.sh
#   AUTH_RESULT=$(get_auth_token)
#   # AUTH_RESULT 是 JSON 格式，包含 token, auth_method, operator 等字段

# ── 前置依赖检查 ─────────────────────────────────────────────
# jq 是必需的依赖，用于 JSON 构造和解析
_JQ_LOCAL_DIR="${HOME}/.local/bin"
_JQ_LOCAL_PATH="${_JQ_LOCAL_DIR}/jq"

# 如果本地安装过 jq 但不在 PATH 中，先加入 PATH
if [ -x "$_JQ_LOCAL_PATH" ] && ! command -v jq >/dev/null 2>&1; then
    export PATH="${_JQ_LOCAL_DIR}:${PATH}"
fi

if ! command -v jq >/dev/null 2>&1; then
    echo "[Auth] jq 未安装，正在自动安装..." >&2

    # 方式1：使用系统包管理器安装
    if command -v brew >/dev/null 2>&1; then
        brew install jq >/dev/null 2>&1
    elif command -v apt-get >/dev/null 2>&1; then
        apt-get update -qq >/dev/null 2>&1 && apt-get install -y -qq jq >/dev/null 2>&1
    elif command -v yum >/dev/null 2>&1; then
        yum install -y -q jq >/dev/null 2>&1
    elif command -v apk >/dev/null 2>&1; then
        apk add --quiet jq >/dev/null 2>&1
    fi

    # 方式2：包管理器失败时，下载预编译二进制
    if ! command -v jq >/dev/null 2>&1; then
        echo "[Auth] 包管理器安装失败，尝试下载预编译二进制..." >&2
        mkdir -p "$_JQ_LOCAL_DIR"
        _JQ_OS=$(uname -s | tr '[:upper:]' '[:lower:]')
        _JQ_ARCH=$(uname -m)
        _JQ_URL=""
        case "${_JQ_OS}-${_JQ_ARCH}" in
            linux-x86_64)  _JQ_URL="https://github.com/jqlang/jq/releases/download/jq-1.7.1/jq-linux-amd64" ;;
            linux-aarch64) _JQ_URL="https://github.com/jqlang/jq/releases/download/jq-1.7.1/jq-linux-arm64" ;;
            darwin-x86_64) _JQ_URL="https://github.com/jqlang/jq/releases/download/jq-1.7.1/jq-macos-amd64" ;;
            darwin-arm64)  _JQ_URL="https://github.com/jqlang/jq/releases/download/jq-1.7.1/jq-macos-arm64" ;;
        esac
        if [ -n "$_JQ_URL" ]; then
            if curl -fsSL -o "$_JQ_LOCAL_PATH" "$_JQ_URL" 2>/dev/null || wget -qO "$_JQ_LOCAL_PATH" "$_JQ_URL" 2>/dev/null; then
                chmod +x "$_JQ_LOCAL_PATH"
                export PATH="${_JQ_LOCAL_DIR}:${PATH}"
                echo "[Auth] ✅ jq 二进制下载成功 (${_JQ_LOCAL_PATH})" >&2
            fi
        fi
    fi

    # 最终验证
    if ! command -v jq >/dev/null 2>&1; then
        echo "[Auth] ⚠️  jq 自动安装失败，请手动安装" >&2
        echo "[Auth] macOS: brew install jq" >&2
        echo "[Auth] Linux: apt-get install -y jq 或 yum install -y jq" >&2
        echo "[Auth] 脚本依赖 jq 进行 JSON 处理，无法继续" >&2
        echo '{"success":false,"error":"jq_not_found","message":"jq is required but not installed","auth_method":"none"}'
        return 1 2>/dev/null || exit 1
    fi
    echo "[Auth] ✅ jq 安装成功" >&2
fi

# ── 配置 ─────────────────────────────────────────────────────

# catpaw-deploy 后端 API 端点（用于灰度发布等业务请求）
AUTH_API_HOST="${PLUS_API_HOST:-https://catpaw-plus.sankuai.com}"

# CIBA 认证端点（沙箱平台封装的 SSO CIBA 接口）
# 参考 talos-cli: https://supabase.sankuai.com
CIBA_BASE_URL="${CIBA_BASE_URL:-https://supabase.sankuai.com}"
CIBA_AUTH_ENDPOINT="${CIBA_BASE_URL}/api/sandbox/sso/ciba-auth"
CIBA_TOKEN_ENDPOINT="${CIBA_BASE_URL}/api/sandbox/sso/ciba-token"
CIBA_EXCHANGE_ENDPOINT="${CIBA_BASE_URL}/api/sandbox/sso/exchange-token-by-client-ids"

# catpaw-deploy 后端验票使用的 SSO clientId
# 后端 sso.go 中硬编码为 dff0983ff1，验票时检查 token audience 是否包含此 clientId
PLUS_BACKEND_SSO_CLIENT_ID="${PLUS_BACKEND_SSO_CLIENT_ID:-dff0983ff1}"
# Plus Agent 的 SSO clientId（CIBA 认证发起方，被后端信任）
PLUS_AGENT_SSO_CLIENT_ID="${PLUS_AGENT_SSO_CLIENT_ID:-1452823222}"

# SSO 官方接口（用于获取用户信息等）
SSO_ONLINE_HOST="https://ssosv.sankuai.com"
SSO_USERINFO_ENDPOINT="${SSO_ONLINE_HOST}/api/oauth2/userinfo"

# CIBA 轮询配置
CIBA_POLL_INTERVAL=5      # 轮询间隔（秒）
CIBA_MAX_POLL_TIME=180    # 最大轮询时间（秒）

# 配置文件路径
CATPAW_SSO_CONFIG="${HOME}/.catpaw/sso_config.json"
PLUS_CLI_CONFIG="${HOME}/.config/plus-cli/config.json"
NOCODE_SSO_CONFIG="/root/nocode_task/.secret/sso.json"

# CatDesk CLI 路径（用于 catdesk auth token 取有效 SSO Token）
CATDESK_CLI="${CATDESK_CLI:-${HOME}/.catdesk/bin/catdesk}"

# Token 有效期（12 小时）
TOKEN_VALID_DURATION=43200

# ── 辅助函数 ───────────────────────────────────────────────

# 输出错误 JSON
auth_error() {
    local error="$1"
    local message="$2"
    local auth_method="${3:-none}"
    jq -n \
        --arg error "$error" \
        --arg message "$message" \
        --arg auth_method "$auth_method" \
        '{
            success: false,
            error: $error,
            message: $message,
            auth_method: $auth_method
        }'
}

# 输出成功 JSON
auth_success() {
    local token="$1"
    local auth_method="$2"
    local operator="${3:-}"
    local environment="${4:-prod}"
    local expires_at="${5:-}"
    jq -n \
        --arg token "$token" \
        --arg auth_method "$auth_method" \
        --arg operator "$operator" \
        --arg environment "$environment" \
        --arg expires_at "$expires_at" \
        '{
            success: true,
            token: $token,
            auth_method: $auth_method,
            operator: $operator,
            environment: $environment,
            expires_at: $expires_at
        }'
}

# 检测是否在 CatClaw/OpenClaw/沙箱 环境
is_catclaw_environment() {
    # 显式环境变量标记
    [ "${CATCLAW:-false}" = "true" ] || \
    [ "${OPENCLAW:-false}" = "true" ] || \
    [ "${PLUS_CLI_CATCLAW:-false}" = "true" ] || \
    # 沙箱配置文件
    [ -f "/root/.openclaw/config/sandbox.json" ] || \
    [ -f "/root/.catclaw/config.json" ] || \
    # OpenClaw 容器特征：存在 .openclaw 目录结构
    [ -d "/root/.openclaw" ] || \
    # 存在 mt_sso_config 目录（OpenClaw 沙箱常见）
    [ -d "/root/.mt_sso_config" ] || \
    # OpenClaw/CatClaw 容器中常见的 sandbox 标识文件
    [ -f "/etc/openclaw-sandbox" ] || \
    [ -f "/etc/catclaw-sandbox" ] || \
    # hostname 包含 sandbox 关键字（如 sandbox-ide-510840-0）
    hostname 2>/dev/null | grep -qi "sandbox" || \
    # IDENTIFIER 环境变量已设置（说明调用方已明确提供沙箱标识）
    [ -n "${IDENTIFIER:-}" ] || \
    # nocode_task 目录存在（沙箱 IDE 常见工作目录）
    [ -d "/root/nocode_task" ] || \
    # 以 root 运行且在容器中（Docker / Kubernetes）
    { [ "$(whoami 2>/dev/null)" = "root" ] && [ -f "/.dockerenv" ]; }
}

# 获取 identifier（沙箱 ID）
get_identifier() {
    # 优先级：环境变量 > 沙箱配置文件
    if [ -n "${IDENTIFIER:-}" ]; then
        echo "$IDENTIFIER"
        return 0
    fi

    if [ -f "/root/.openclaw/config/sandbox.json" ]; then
        local id=$(jq -r '.identifier // empty' "/root/.openclaw/config/sandbox.json" 2>/dev/null)
        if [ -n "$id" ]; then
            echo "$id"
            return 0
        fi
    fi

    if [ -f "/root/.catclaw/config.json" ]; then
        local id=$(jq -r '.identifier // empty' "/root/.catclaw/config.json" 2>/dev/null)
        if [ -n "$id" ]; then
            echo "$id"
            return 0
        fi
    fi

    return 1
}

# 获取 MIS ID
get_mis_id() {
    # 优先级：环境变量 > plus-cli 配置 > catpaw 配置 > 沙箱配置
    if [ -n "${MIS_ID:-}" ]; then
        echo "$MIS_ID"
        return 0
    fi

    if [ -f "$PLUS_CLI_CONFIG" ]; then
        local mis=$(jq -r '.operator // empty' "$PLUS_CLI_CONFIG" 2>/dev/null)
        if [ -n "$mis" ]; then
            echo "$mis"
            return 0
        fi
    fi

    if [ -f "$CATPAW_SSO_CONFIG" ]; then
        local mis=$(jq -r '.misId // empty' "$CATPAW_SSO_CONFIG" 2>/dev/null)
        if [ -n "$mis" ]; then
            echo "$mis"
            return 0
        fi
    fi

    # NoCode SSO 配置文件
    if [ -f "$NOCODE_SSO_CONFIG" ]; then
        local mis=$(jq -r '.misId // empty' "$NOCODE_SSO_CONFIG" 2>/dev/null)
        if [ -n "$mis" ]; then
            echo "$mis"
            return 0
        fi
    fi

    # 沙箱配置中可能有 mis 信息
    local sandbox_paths=("/root/.openclaw/config/sandbox.json" "/root/.catclaw/config.json")
    for sb_path in "${sandbox_paths[@]}"; do
        if [ -f "$sb_path" ]; then
            local mis=$(jq -r '.misId // .mis // empty' "$sb_path" 2>/dev/null)
            if [ -n "$mis" ]; then
                echo "$mis"
                return 0
            fi
        fi
    done

    return 1
}

# 解析 Token 中的 clientId / audience 信息（用于诊断）
# 支持 JWT 格式和 MTSSO 自定义格式
debug_token_info() {
    local token="$1"
    if [ -z "$token" ]; then
        echo "[TokenDebug] token 为空" >&2
        return 1
    fi

    # 打印 token 前缀（用于判断格式）
    local token_prefix="${token:0:20}"
    echo "[TokenDebug] Token 前缀: ${token_prefix}..." >&2
    echo "[TokenDebug] Token 长度: ${#token}" >&2

    # 尝试解析 JWT 格式（三段式 base64，用 . 分隔）
    if echo "$token" | grep -q '\..*\.' 2>/dev/null; then
        echo "[TokenDebug] 检测到 JWT 格式 Token" >&2
        # 提取 header
        local header_b64=$(echo "$token" | cut -d'.' -f1)
        local header=$(echo "$header_b64" | base64 -d 2>/dev/null || echo "$header_b64" | base64 --decode 2>/dev/null)
        if [ -n "$header" ]; then
            local kid=$(echo "$header" | jq -r '.kid // empty' 2>/dev/null)
            local alg=$(echo "$header" | jq -r '.alg // empty' 2>/dev/null)
            echo "[TokenDebug] JWT Header - kid: $kid, alg: $alg" >&2
        fi

        # 提取 payload（需要补齐 base64 padding）
        local payload_b64=$(echo "$token" | cut -d'.' -f2)
        # 补齐 base64 padding
        local padding=$((4 - ${#payload_b64} % 4))
        if [ $padding -ne 4 ]; then
            payload_b64="${payload_b64}$(printf '=%.0s' $(seq 1 $padding))"
        fi
        local payload=$(echo "$payload_b64" | base64 -d 2>/dev/null || echo "$payload_b64" | base64 --decode 2>/dev/null)
        if [ -n "$payload" ]; then
            local client_id=$(echo "$payload" | jq -r '.client_id // empty' 2>/dev/null)
            local aud=$(echo "$payload" | jq -r '.aud // empty' 2>/dev/null)
            local sub=$(echo "$payload" | jq -r '.sub // empty' 2>/dev/null)
            local iss=$(echo "$payload" | jq -r '.iss // empty' 2>/dev/null)
            echo "[TokenDebug] JWT Payload:" >&2
            echo "[TokenDebug]   client_id: $client_id" >&2
            echo "[TokenDebug]   aud: $aud" >&2
            echo "[TokenDebug]   sub: $sub" >&2
            echo "[TokenDebug]   iss: $iss" >&2
            # 如果 aud 是数组，打印所有元素
            local aud_array=$(echo "$payload" | jq -r '.aud | if type == "array" then join(", ") else . end' 2>/dev/null)
            if [ -n "$aud_array" ]; then
                echo "[TokenDebug]   aud (展开): $aud_array" >&2
            fi
        fi
    else
        echo "[TokenDebug] 非 JWT 格式 Token（MTSSO 自定义格式）" >&2
        # MTSSO 格式无法直接解析 clientId，需要通过 SSO 接口查询
        echo "[TokenDebug] 需要通过 SSO 验票接口获取详细信息" >&2
    fi
}

# 通过 SSO accessToken 获取用户 MIS ID
get_mis_by_token() {
    local access_token="$1"
    if [ -z "$access_token" ]; then
        return 1
    fi

    local userinfo_response
    userinfo_response=$(curl -s -H "Authorization: Bearer $access_token" "$SSO_USERINFO_ENDPOINT" 2>/dev/null)

    local mis=$(echo "$userinfo_response" | jq -r '.login // .mis // empty' 2>/dev/null)
    if [ -n "$mis" ]; then
        echo "$mis"
        return 0
    fi

    return 1
}

# ── 方式0：CatDesk CLI 认证（catdesk auth token） ───────────
#
# 调用 CatPaw Desk 自带的 `catdesk auth token` 获取当前有效的 SSO Token。
# 该 Token 由 CatPaw 官方 SSO 会话签发（用户自身身份，无需任何额外应用授权），
# 且 catdesk 会在临近过期时自动刷新，是最推荐、最省心的取票方式。
#
# 输出格式：{ "accessToken": "AT_...", ... }
# 取到的 accessToken 直接作为 SSOID 传给 catpaw-plus 后端（X-SSO-ID header）。

auth_by_catdesk() {
    # 检查 catdesk CLI 是否存在
    local catdesk_bin="$CATDESK_CLI"
    if [ ! -x "$catdesk_bin" ]; then
        # 尝试从 PATH 中查找
        if command -v catdesk >/dev/null 2>&1; then
            catdesk_bin="$(command -v catdesk)"
        else
            return 1
        fi
    fi

    # 调用 catdesk auth token 获取有效 Token（自动刷新）
    local token_response
    token_response=$("$catdesk_bin" auth token 2>/dev/null)
    if [ -z "$token_response" ]; then
        return 1
    fi

    local token=$(echo "$token_response" | jq -r '.accessToken // empty' 2>/dev/null)
    if [ -z "$token" ] || [ "$token" = "null" ]; then
        return 1
    fi

    # 通过 catdesk auth info 获取操作人 MIS（可选）
    local operator=""
    local info_response
    info_response=$("$catdesk_bin" auth info 2>/dev/null)
    if [ -n "$info_response" ]; then
        operator=$(echo "$info_response" | jq -r '.mis // empty' 2>/dev/null)
    fi

    echo "[CatDesk] ✅ 从 catdesk auth token 获取有效 SSO Token（操作人: ${operator:-unknown}）" >&2

    # 持久化到 plus-cli 配置，便于下次快速复用
    save_token_to_config "$token" "$operator" "catdesk"

    auth_success "$token" "catdesk" "$operator" "prod"
    return 0
}

# ── 方式1：环境变量认证 ─────────────────────────────────────

auth_by_env_token() {
    # 检查 PLUS_ACCESS_TOKEN 环境变量
    if [ -z "${PLUS_ACCESS_TOKEN:-}" ]; then
        return 1
    fi

    local token="$PLUS_ACCESS_TOKEN"
    local operator="${PLUS_OPERATOR:-}"
    local environment="${PLUS_ENVIRONMENT:-prod}"

    # 验证 token 格式（非空即可）
    if [ -z "$token" ]; then
        return 1
    fi

    auth_success "$token" "env_token" "$operator" "$environment"
    return 0
}

# ── 方式2：CIBA 认证（大象 App 推送） ───────────────────────
#
# 使用沙箱平台封装的 CIBA 接口（与 talos-cli 一致）
# 基于 https://km.sankuai.com/collabpage/2750337362
#
# 流程（2步，不需要 exchange）：
# 1. ciba-auth：传入 identifier + misId，获取 authReqId
# 2. ciba-token：轮询等待用户大象确认，获取 accessToken（即 SSOID）
#
# 获取到的 accessToken 直接作为 SSOID 传给 catpaw-deploy 后端
# 后端通过 X-SSO-ID header 接收，再调用 SSO 服务查用户 MIS

auth_by_ciba() {
    local identifier mis_id

    identifier=$(get_identifier)
    if [ -z "$identifier" ]; then
        echo "[CIBA] 无法获取沙箱标识符（IDENTIFIER），跳过 CIBA 认证" >&2
        return 1
    fi

    mis_id=$(get_mis_id)
    if [ -z "$mis_id" ]; then
        echo "[CIBA] 无法获取 MIS ID，请设置 MIS_ID 环境变量" >&2
        return 1
    fi

    echo "" >&2
    echo "╔══════════════════════════════════════════════════════════╗" >&2
    echo "║  🦞 CIBA 认证（大象 App 确认授权）                       ║" >&2
    echo "╠══════════════════════════════════════════════════════════╣" >&2
    echo "║  请在大象 App 中确认授权请求                             ║" >&2
    echo "╚══════════════════════════════════════════════════════════╝" >&2
    echo "" >&2
    echo "[CIBA] Identifier: $identifier" >&2
    echo "[CIBA] MIS ID: $mis_id" >&2
    echo "[CIBA] 📱 等待 $mis_id 在大象 App 中确认授权..." >&2

    # 步骤1：发起 CIBA 认证请求
    # 调用 supabase.sankuai.com 封装接口
    local ciba_response
    ciba_response=$(curl -s --noproxy "*" --connect-timeout 10 --max-time 30 -X POST "$CIBA_AUTH_ENDPOINT" \
        -H "Content-Type: application/json" \
        -d "{\"identifier\": \"$identifier\", \"misId\": \"$mis_id\"}")

    # supabase 封装接口返回格式：{ code: 0, data: { authReqId: "xxx" } }
    # 注意：authorization_pending 时 code 也为 0，但 authReqId 为 null，需从 existingAuthReqId 获取
    local response_code=$(echo "$ciba_response" | jq -r '.code // -1' 2>/dev/null)
    echo "[CIBA] ciba-auth 响应 code=$response_code" >&2

    local auth_req_id=""

    if [ "$response_code" != "0" ]; then
        # code 非 0：检查是否有已存在的请求（某些版本返回非 0 + existingAuthReqId）
        local existing_id=$(echo "$ciba_response" | jq -r '.data.existingAuthReqId // .extra_info.existing_auth_req_id // empty' 2>/dev/null)
        if [ -n "$existing_id" ]; then
            echo "[CIBA] 检测到已有进行中的认证请求（code≠0），使用 existingAuthReqId" >&2
            auth_req_id="$existing_id"
        else
            local err_msg=$(echo "$ciba_response" | jq -r '.msg // .data.errorDescription // .message // "未知错误"' 2>/dev/null)
            echo "[CIBA] 认证请求失败: $err_msg" >&2
            echo "[CIBA] 原始响应: $ciba_response" >&2
            return 1
        fi
    else
        # code 为 0：先尝试取 authReqId
        auth_req_id=$(echo "$ciba_response" | jq -r '.data.authReqId // .authReqId // empty' 2>/dev/null)

        # authReqId 为空时，检查是否为 authorization_pending（已有进行中的请求）
        if [ -z "$auth_req_id" ] || [ "$auth_req_id" = "null" ]; then
            local ciba_error=$(echo "$ciba_response" | jq -r '.data.error // empty' 2>/dev/null)
            local existing_id=$(echo "$ciba_response" | jq -r '.data.existingAuthReqId // .extra_info.existing_auth_req_id // empty' 2>/dev/null)

            if [ -n "$existing_id" ] && [ "$existing_id" != "null" ]; then
                echo "[CIBA] 检测到已有进行中的认证请求 (error=$ciba_error)，使用 existingAuthReqId" >&2
                auth_req_id="$existing_id"
            else
                echo "[CIBA] authReqId 为空且无 existingAuthReqId (error=$ciba_error)" >&2
                echo "[CIBA] 原始响应: $ciba_response" >&2
            fi
        fi
    fi

    if [ -z "$auth_req_id" ] || [ "$auth_req_id" = "null" ]; then
        echo "[CIBA] 未获取到 authReqId" >&2
        return 1
    fi

    echo "[CIBA] ✅ 已发送授权请求，请在大象 App 中点击「确认」" >&2

    # 步骤2：轮询等待用户确认
    local max_attempts=$((CIBA_MAX_POLL_TIME / CIBA_POLL_INTERVAL))
    local attempt=0
    local access_token=""

    while [ $attempt -lt $max_attempts ]; do
        attempt=$((attempt + 1))
        sleep $CIBA_POLL_INTERVAL

        echo "[CIBA] 等待确认... ($attempt/$max_attempts)" >&2

        local token_response
        token_response=$(curl -s --noproxy "*" --connect-timeout 10 --max-time 30 -X POST "$CIBA_TOKEN_ENDPOINT" \
            -H "Content-Type: application/json" \
            -d "{\"authReqId\": \"$auth_req_id\"}")

        # supabase 封装接口返回格式：{ code: 0, data: { accessToken: "xxx" } }
        local token_code=$(echo "$token_response" | jq -r '.code // -1' 2>/dev/null)

        if [ "$token_code" = "0" ]; then
            access_token=$(echo "$token_response" | jq -r '.data.accessToken // .accessToken // empty' 2>/dev/null)
            if [ -n "$access_token" ]; then
                break
            fi
        fi

        # 检查非 authorization_pending 的错误
        if [ "$token_code" != "0" ]; then
            local err_msg=$(echo "$token_response" | jq -r '.message // .data.errorDescription // .msg // ""' 2>/dev/null)
            # authorization_pending 继续轮询
            if echo "$err_msg" | grep -q "authorization_pending" 2>/dev/null; then
                continue
            fi
            # access_denied / expired_token 等错误直接退出
            if echo "$err_msg" | grep -qE "access_denied|expired_token|rejected" 2>/dev/null; then
                echo "[CIBA] 认证失败: $err_msg" >&2
                return 1
            fi
        fi
    done

    if [ -z "$access_token" ]; then
        echo "[CIBA] 认证超时（${CIBA_MAX_POLL_TIME}秒），请在大象 App 中确认后重试" >&2
        return 1
    fi

    echo "[CIBA] ✅ 大象授权成功，已获取 SSO Token" >&2

    # 打印原始 token 诊断信息
    debug_token_info "$access_token"

    # 步骤3：换票 — 用 accessToken + 后端 clientId 换取包含正确 audience 的 token
    # 使用 supabase 的 exchange-token-by-client-ids 接口
    # 后端 sso.go 用 dff0983ff1 调 SSO 验票，SSO 会检查 token audience 是否包含此 clientId
    # 因此换票必须传入 dff0983ff1，否则后端验票时报 "clientId不在audience列表"
    echo "[CIBA] 🔄 正在换取业务系统 Token (clientIds: $PLUS_BACKEND_SSO_CLIENT_ID)..." >&2

    local exchange_response
    local exchanged_token=""
    local exchange_attempt=0
    local exchange_max_attempts=3

    while [ $exchange_attempt -lt $exchange_max_attempts ]; do
        exchange_attempt=$((exchange_attempt + 1))

        # 使用 --noproxy "*" 避免沙箱环境代理导致的网络问题
        # 使用 --connect-timeout 和 --max-time 避免请求挂起
        exchange_response=$(curl -s --noproxy "*" --connect-timeout 10 --max-time 30 \
            -X POST "$CIBA_EXCHANGE_ENDPOINT" \
            -H "Content-Type: application/json" \
            -d "{\"accessToken\": \"$access_token\", \"clientIds\": [\"$PLUS_BACKEND_SSO_CLIENT_ID\"]}")

        local curl_exit=$?
        if [ $curl_exit -ne 0 ]; then
            echo "[CIBA] 换票请求网络错误 (curl exit=$curl_exit, attempt=$exchange_attempt/$exchange_max_attempts)" >&2
            if [ $exchange_attempt -lt $exchange_max_attempts ]; then
                sleep 2
                continue
            fi
            break
        fi

        local exchange_code=$(echo "$exchange_response" | jq -r '.code // -1' 2>/dev/null)

        if [ "$exchange_code" = "0" ]; then
            exchanged_token=$(echo "$exchange_response" | jq -r '.data // empty' 2>/dev/null)
            # data 可能直接是 token 字符串，或者是对象
            if [ -z "$exchanged_token" ] || [ "$exchanged_token" = "null" ]; then
                exchanged_token=$(echo "$exchange_response" | jq -r '.data.token // .data.accessToken // empty' 2>/dev/null)
            fi
            if [ -n "$exchanged_token" ] && [ "$exchanged_token" != "null" ]; then
                break
            fi
        fi

        echo "[CIBA] 换票响应异常 (code=$exchange_code, attempt=$exchange_attempt/$exchange_max_attempts)" >&2
        if [ $exchange_attempt -lt $exchange_max_attempts ]; then
            sleep 2
        fi
    done

    local final_token=""
    if [ -n "$exchanged_token" ] && [ "$exchanged_token" != "null" ]; then
        final_token="$exchanged_token"
        echo "[CIBA] ✅ 换票成功" >&2
        debug_token_info "$final_token"
    else
        # 换票失败，回退使用原始 token
        local exchange_err=$(echo "$exchange_response" | jq -r '.msg // .message // "未知错误"' 2>/dev/null)
        echo "[CIBA] ⚠️  换票失败: $exchange_err" >&2
        echo "[CIBA] ⚠️  原始响应: $exchange_response" >&2
        echo "[CIBA] ⚠️  回退使用原始 SSO Token（后端验票可能因 audience 不匹配而失败）" >&2
        echo "[CIBA] 💡 提示: 后端 sso.go 使用 clientId=$PLUS_BACKEND_SSO_CLIENT_ID 验票" >&2
        echo "[CIBA] 💡 提示: 若持续换票失败，请检查 supabase 接口可用性或联系平台支持" >&2
        final_token="$access_token"
    fi

    # 获取用户 MIS（通过 SSO userinfo 接口验证 token 有效性）
    local operator="$mis_id"
    local fetched_mis=$(get_mis_by_token "$final_token")
    if [ -z "$fetched_mis" ]; then
        # 换票后的 token 可能不适合 userinfo，尝试用原始 token
        fetched_mis=$(get_mis_by_token "$access_token")
    fi
    if [ -n "$fetched_mis" ]; then
        operator="$fetched_mis"
        echo "[CIBA] 用户: $operator" >&2
    fi

    # 保存到配置文件
    save_token_to_config "$final_token" "$operator" "ciba"

    # 返回换票后的 token，catpaw-deploy 后端通过 X-SSO-ID 接收
    auth_success "$final_token" "ciba" "$operator" "prod"
    return 0
}

# ── 方式3：浏览器 SSO 登录 ───────────────────────────────────

auth_by_browser() {
    # 使用 @mtfe/sso-web-oidc-cli SDK 实现浏览器 SSO 登录
    # 自动打开浏览器，用户完成 SSO 扫码/登录，获取并存储 token
    #
    # 必要前置条件：
    # 1. 已在应用开放平台启用 OIDC 协议
    # 2. 已配置以下本地回调地址（在应用开放平台）：
    #    - http://localhost:9152/websso/oauth/callback
    #    - http://localhost:10152/websso/oauth/callback
    #    - http://localhost:11152/websso/oauth/callback
    #    - http://localhost:12152/websso/oauth/callback
    # 3. 检查是否收到 "Invalid parameter: redirect_uri" 错误？
    #    原因：SDK 使用的回调地址与平台配置不一致
    #    解决：登录 https://open.sankuai.com 检查并补全上述所有回调地址
    # 4. Node.js 已安装
    # 5. @mtfe/sso-web-oidc-cli SDK 已安装：npm install -g @mtfe/sso-web-oidc-cli

    # 检测是否有图形界面环境，无图形界面时快速失败以回退到其他认证方式

    # 如果在 CatClaw/OpenClaw 容器环境中，即使有 DISPLAY 也跳过浏览器
    # （容器中的 DISPLAY 如 :1 通常是 Xvfb 虚拟显示，无法完成交互式登录）
    if is_catclaw_environment; then
        echo "[Browser] 检测到 CatClaw/OpenClaw 沙箱环境，跳过浏览器 SSO" >&2
        return 1
    fi

    # Linux 环境：无 DISPLAY 也无 WAYLAND_DISPLAY 也无 BROWSER 时跳过
    if [ "$(uname)" = "Linux" ] && [ -z "${DISPLAY:-}" ] && [ -z "${WAYLAND_DISPLAY:-}" ] && [ -z "${BROWSER:-}" ]; then
        echo "[Browser] 检测到无图形界面环境（无 DISPLAY/WAYLAND_DISPLAY），跳过浏览器 SSO" >&2
        return 1
    fi

    # Linux 容器环境检测：DISPLAY 存在但可能不可用
    # 通过检查 /.dockerenv 或 cgroup 判断是否在容器中
    if [ "$(uname)" = "Linux" ] && [ -n "${DISPLAY:-}" ]; then
        local in_container=false
        # Docker 容器标志
        if [ -f "/.dockerenv" ]; then
            in_container=true
        fi
        # cgroup 中含有 docker/kubepods 关键字
        if [ -f "/proc/1/cgroup" ] && grep -qE 'docker|kubepods|containerd' /proc/1/cgroup 2>/dev/null; then
            in_container=true
        fi
        # 检查是否能真正使用浏览器（尝试检测常见浏览器是否存在）
        if [ "$in_container" = "true" ]; then
            local has_real_browser=false
            for browser_cmd in google-chrome chromium-browser chromium firefox; do
                if command -v "$browser_cmd" >/dev/null 2>&1; then
                    has_real_browser=true
                    break
                fi
            done
            if [ "$has_real_browser" = "false" ]; then
                echo "[Browser] 检测到容器环境（DISPLAY=${DISPLAY} 可能为虚拟显示）且无可用浏览器，跳过浏览器 SSO" >&2
                return 1
            fi
        fi
    fi

    # macOS 下检测是否有 SSH 远程会话且无桌面访问
    if [ "$(uname)" = "Darwin" ] && [ -n "${SSH_CONNECTION:-}" ] && ! command -v open >/dev/null 2>&1; then
        echo "[Browser] 检测到 SSH 远程会话且无法打开浏览器，跳过浏览器 SSO" >&2
        return 1
    fi

    echo "[Browser] 正在启动浏览器 SSO 登录..." >&2

    local script_dir
    script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

    # 尝试主脚本
    local browser_sso_script="${script_dir}/browser-sso-login.js"
    if [ -f "$browser_sso_script" ]; then
        local result
        result=$(node --no-deprecation "$browser_sso_script" 2>&1)
        local exit_code=$?
        
        if [ $exit_code -eq 0 ]; then
            # 浏览器登录成功，获取 OAuth Token（即 SSOID）
            local oauth_token=$(echo "$result" | jq -r '.token // empty' 2>/dev/null)
            
            if [ -z "$oauth_token" ]; then
                auth_error "browser_sso_invalid_response" "浏览器 SSO 返回的响应无效"
                return 1
            fi
            
            # 获取用户 MIS ID
            local user_mis_id=$(echo "$result" | jq -r '.user_mis_id // .operator // empty' 2>/dev/null)
            
            # 如果浏览器 SSO 没返回 MIS，尝试通过 token 获取
            if [ -z "$user_mis_id" ]; then
                user_mis_id=$(get_mis_by_token "$oauth_token")
            fi
            
            local auth_method=$(echo "$result" | jq -r '.auth_method // "browser_sso"' 2>/dev/null)
            
            # 保存到配置文件
            save_token_to_config "$oauth_token" "$user_mis_id" "$auth_method"
            
            # 直接返回 OAuth Token 作为 SSOID
            # catpaw-deploy 后端通过 X-SSO-ID header 接收，再调用 SSO 查 MIS
            auth_success "$oauth_token" "$auth_method" "$user_mis_id" "prod"
            return 0
        fi
        
        # 检查是否是 SDK 未找到的错误
        local error=$(echo "$result" | jq -r '.error // empty' 2>/dev/null)
        if [ "$error" = "sso_sdk_not_found" ]; then
            # 输出诊断信息
            echo "[Browser] SDK 加载失败，请安装：npm install -g @mtfe/sso-web-oidc-cli" >&2
        else
            # 其他错误，直接返回
            echo "$result"
            return 1
        fi
    fi

    # 都失败了
    auth_error "browser_sso_unavailable" \
        "浏览器 SSO 登录不可用。请检查：1) Node.js 是否已安装；2) @mtfe/sso-web-oidc-cli SDK 是否已安装" \
        "browser_sso"
    return 1
}

# ── 方式4：NoCode SSO 配置文件认证 ─────────────────────────
#
# 从 /root/nocode_task/.secret/sso.json 读取 SSO 信息
# 该文件由 NoCode 沙箱平台自动注入，包含多个服务的认证 token
# 使用 catpaw 字段作为 SSO Token，misId 作为操作人

auth_by_nocode_sso() {
    if [ ! -f "$NOCODE_SSO_CONFIG" ]; then
        return 1
    fi

    # 优先使用 catpaw 字段的 token
    local token=$(jq -r '.catpaw // empty' "$NOCODE_SSO_CONFIG" 2>/dev/null)
    if [ -z "$token" ]; then
        # 回退尝试 nocode 字段
        token=$(jq -r '.nocode // empty' "$NOCODE_SSO_CONFIG" 2>/dev/null)
    fi

    if [ -z "$token" ]; then
        echo "[NoCodeSSO] sso.json 中未找到可用的 token (catpaw/nocode)" >&2
        return 1
    fi

    local operator=$(jq -r '.misId // empty' "$NOCODE_SSO_CONFIG" 2>/dev/null)
    local environment=$(jq -r '.env // "prod"' "$NOCODE_SSO_CONFIG" 2>/dev/null)

    echo "[NoCodeSSO] ✅ 从 NoCode SSO 配置文件获取认证信息" >&2
    echo "[NoCodeSSO] 操作人: $operator, 环境: $environment" >&2

    auth_success "$token" "nocode_sso" "$operator" "$environment"
    return 0
}

# ── 方式5：CatPaw 配置文件降级认证 ───────────────────────────

auth_by_catpaw_config() {
    if [ ! -f "$CATPAW_SSO_CONFIG" ]; then
        return 1
    fi

    # 读取 ssoid
    local ssoid=$(jq -r '.ssoid // empty' "$CATPAW_SSO_CONFIG" 2>/dev/null)
    if [ -z "$ssoid" ]; then
        return 1
    fi

    # 检查是否过期（12 小时）
    local updated_at=$(jq -r '.updatedAt // 0' "$CATPAW_SSO_CONFIG" 2>/dev/null)
    local current_time=$(date +%s)
    local cache_time=$((updated_at / 1000))
    local cache_age=$((current_time - cache_time))

    if [ $cache_age -ge $TOKEN_VALID_DURATION ]; then
        echo "[CatPaw] SSOID 已过期（${cache_age}秒），请重新登录" >&2
        return 1
    fi

    local mis_id=$(jq -r '.misId // empty' "$CATPAW_SSO_CONFIG" 2>/dev/null)

    auth_success "$ssoid" "catpaw_config" "$mis_id" "prod"
    return 0
}

# ── 持久化存储 ───────────────────────────────────────────────

save_token_to_config() {
    local token="$1"
    local operator="$2"
    local auth_method="$3"

    local config_dir=$(dirname "$PLUS_CLI_CONFIG")
    mkdir -p "$config_dir" 2>/dev/null

    local current_time=$(date +%s)

    jq -n \
        --arg token "$token" \
        --arg operator "$operator" \
        --arg auth_method "$auth_method" \
        --arg updated_at "$current_time" \
        '{
            token: $token,
            operator: $operator,
            auth_method: $auth_method,
            updated_at: ($updated_at | tonumber)
        }' > "$PLUS_CLI_CONFIG" 2>/dev/null
}

# 从配置文件读取已保存的 token
auth_by_saved_config() {
    if [ ! -f "$PLUS_CLI_CONFIG" ]; then
        return 1
    fi

    local token=$(jq -r '.token // empty' "$PLUS_CLI_CONFIG" 2>/dev/null)
    if [ -z "$token" ]; then
        return 1
    fi

    # 检查是否过期（使用 expiresAt 字段如果存在）
    local expires_at=$(jq -r '.expiresAt // empty' "$PLUS_CLI_CONFIG" 2>/dev/null)
    if [ -z "$expires_at" ]; then
        # 备选方案：使用 updated_at + TOKEN_VALID_DURATION
        local updated_at=$(jq -r '.updated_at // 0' "$PLUS_CLI_CONFIG" 2>/dev/null)
        local current_time=$(date +%s)
        local cache_age=$((current_time - updated_at))
        
        if [ $cache_age -ge $TOKEN_VALID_DURATION ]; then
            return 1
        fi
    else
        # 使用 expiresAt 检查过期
        local current_time=$(date +%s)
        if [ $current_time -ge $expires_at ]; then
            echo "[SavedConfig] Token 已过期" >&2
            return 1
        fi
    fi

    local operator=$(jq -r '.operator // empty' "$PLUS_CLI_CONFIG" 2>/dev/null)
    local auth_method=$(jq -r '.auth_method // "saved"' "$PLUS_CLI_CONFIG" 2>/dev/null)

    # 直接使用保存的 token（不需要 exchange，token 就是 SSOID）
    auth_success "$token" "$auth_method" "$operator" "prod"
    return 0
}

# ── 主入口：决策树 ───────────────────────────────────────────

get_auth_token() {
    local force_method="${1:-}"  # 可选：强制使用特定方式

    # 如果指定了强制方式
    case "$force_method" in
        catdesk)
            auth_by_catdesk
            return $?
            ;;
        env)
            auth_by_env_token
            return $?
            ;;
        ciba)
            auth_by_ciba
            return $?
            ;;
        browser)
            auth_by_browser
            return $?
            ;;
        nocode)
            auth_by_nocode_sso
            return $?
            ;;
        catpaw)
            auth_by_catpaw_config
            return $?
            ;;
    esac

    # 决策树：按优先级尝试

    # 方式1：环境变量认证（最高优先级）
    local result
    result=$(auth_by_env_token)
    if [ $? -eq 0 ]; then
        echo "$result"
        return 0
    fi

    # 方式0：CatDesk CLI 认证（catdesk auth token，自动刷新，用户自身身份，无需额外授权）
    result=$(auth_by_catdesk)
    if [ $? -eq 0 ]; then
        echo "$result"
        return 0
    fi

    # 检查是否有已保存的有效 token
    result=$(auth_by_saved_config)
    if [ $? -eq 0 ]; then
        echo "$result"
        return 0
    fi

    # 判断环境：CatClaw/OpenClaw 用 CIBA，否则先尝试浏览器再回退 CIBA
    if is_catclaw_environment; then
        # 方式2：CIBA 认证（CatClaw/OpenClaw 环境默认）
        echo "[Auth] 检测到 CatClaw/OpenClaw 环境，使用 CIBA 认证" >&2
        result=$(auth_by_ciba)
        if [ $? -eq 0 ]; then
            echo "$result"
            return 0
        fi
        # CIBA 失败（如缺少 identifier），沙箱环境无法使用浏览器 SSO，直接尝试配置文件兆底
        echo "[Auth] CIBA 认证不可用，尝试配置文件兆底方案..." >&2
        echo "[Auth] 💡 提示：可通过以下方式解决：" >&2
        echo "[Auth]   1. 设置环境变量: export IDENTIFIER=<沙箱标识符>" >&2
        echo "[Auth]   2. 确保沙箱配置文件存在: /root/.openclaw/config/sandbox.json" >&2
        echo "[Auth]   3. 或直接设置 Token: export PLUS_ACCESS_TOKEN=<token>" >&2
    else
        # 方式3：浏览器 SSO 登录（非 CatClaw 环境默认）
        result=$(auth_by_browser)
        if [ $? -eq 0 ]; then
            echo "$result"
            return 0
        fi

        # 浏览器 SSO 失败后，回退尝试 CIBA（需要 identifier 和 mis_id）
        echo "[Auth] 浏览器 SSO 不可用，尝试回退到 CIBA 认证..." >&2
        result=$(auth_by_ciba 2>/dev/null)
        if [ $? -eq 0 ]; then
            echo "$result"
            return 0
        fi
    fi

    # 方式4：NoCode SSO 配置文件（沙箱 NoCode 环境兜底）
    result=$(auth_by_nocode_sso)
    if [ $? -eq 0 ]; then
        echo "$result"
        return 0
    fi

    # 方式5：CatPaw 配置文件降级（兜底）
    result=$(auth_by_catpaw_config)
    if [ $? -eq 0 ]; then
        echo "$result"
        return 0
    fi

    # 所有方式都失败
    auth_error "auth_failed" "无法获取认证凭证，请设置 PLUS_ACCESS_TOKEN 环境变量或手动登录" "none"
    return 1
}

# ── 便捷函数 ─────────────────────────────────────────────────

# 获取 token 字符串（用于 API 调用）
get_token_string() {
    local result=$(get_auth_token "$1")
    echo "$result" | jq -r '.token // empty'
}

# 检查认证状态
check_auth_status() {
    local result=$(get_auth_token)
    if echo "$result" | jq -e '.success' > /dev/null 2>&1; then
        echo "✓ 认证有效"
        echo "  方式: $(echo "$result" | jq -r '.auth_method')"
        echo "  操作人: $(echo "$result" | jq -r '.operator')"
        echo "  环境: $(echo "$result" | jq -r '.environment')"
        return 0
    else
        echo "✗ 认证无效"
        echo "  错误: $(echo "$result" | jq -r '.error')"
        echo "  信息: $(echo "$result" | jq -r '.message')"
        return 1
    fi
}
