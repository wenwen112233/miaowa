#!/usr/bin/env node

// ── 标准库引入 ─────────────────────────────────────────────
const fs = require('fs');
const path = require('path');
const os = require('os');

// ── 配置路径定义 ───────────────────────────────────────────
const configDir = process.env.PLUS_CLI_CONFIG_DIR || path.join(os.homedir(), '.config', 'plus-cli');
const configFile = path.join(configDir, 'config.json');
const tokenCacheDir = path.join(os.homedir(), '.config', 'talos-cli-nodejs');
const tokenCacheFile = path.join(tokenCacheDir, 'config.json');

// ── 错误处理函数 ───────────────────────────────────────────
function errorExit(error, message) {
  console.log(
    JSON.stringify({
      success: false,
      error,
      message,
    })
  );
  process.exit(1);
}

// ── SSO SDK 模块加载 ────────────────────────────────────────
let SSOCliClient, SSOAccessEnvType;

async function initSSO() {
  const SDK_NAME = '@mtfe/sso-web-oidc-cli';

  // 候选加载路径：默认 require 解析 → 常见全局安装位置 → npm root -g 动态解析
  // 兼容 nvm / homebrew / 系统 Node 等各种安装方式
  const candidates = ['', '/opt/homebrew/lib/node_modules', '/usr/local/lib/node_modules'];

  // 通过 npm root -g 动态获取全局模块目录（覆盖 nvm 场景）
  try {
    const { execSync } = require('child_process');
    const npmGlobalRoot = execSync('npm root -g', { encoding: 'utf-8' }).trim();
    if (npmGlobalRoot && !candidates.includes(npmGlobalRoot)) {
      candidates.push(npmGlobalRoot);
    }
  } catch (e) {
    // npm root -g 失败时忽略，继续尝试其他候选路径
  }

  for (const base of candidates) {
    try {
      const modPath = base ? path.join(base, SDK_NAME) : SDK_NAME;
      const ssoModule = require(modPath);
      SSOCliClient = ssoModule.SSOCliClient;
      SSOAccessEnvType = ssoModule.SSOAccessEnvType;
      if (SSOCliClient) {
        return;
      }
    } catch (e) {
      // 尝试下一个候选路径
    }
  }

  errorExit(
    'sso_sdk_not_found',
    '@mtfe/sso-web-oidc-cli SDK 未安装。请运行: npm install -g @mtfe/sso-web-oidc-cli'
  );
}

// ── Token 存储器实现 ────────────────────────────────────────
class FileTokenStorage {
  constructor(filePath) {
    this.filePath = filePath;
  }

  async get() {
    try {
      if (fs.existsSync(this.filePath)) {
        const content = fs.readFileSync(this.filePath, 'utf-8');
        return JSON.parse(content);
      }
    } catch (e) {
      console.error('[FileTokenStorage] 读取失败:', e.message);
    }
    return {};
  }

  async set(token) {
    try {
      const dir = path.dirname(this.filePath);
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(this.filePath, JSON.stringify(token, null, 2));
      console.error(`[FileTokenStorage] 已保存: ${this.filePath}`);
    } catch (e) {
      console.error('[FileTokenStorage] 保存失败:', e.message);
    }
  }
}

// ── SSO 登录主逻辑 ─────────────────────────────────────────
async function performSSOLogin() {
  // 本地端口列表（SDK 只支持 localhost 回调地址）
  // ⚠️ 重要：必须在应用开放平台配置所有这些端口的回调地址
  // 配置路径：https://open.sankuai.com/developer/app/list -> 选择应用 -> 编辑 OIDC 协议 -> 回调地址
  // 
  // 需要配置的回调地址格式：
  // - http://localhost:9152/websso/oauth/callback
  // - http://localhost:10152/websso/oauth/callback
  // - http://localhost:11152/websso/oauth/callback
  // - http://localhost:12152/websso/oauth/callback
  //
  // 🔍 如果收到 "Invalid parameter: redirect_uri" 错误：
  //    检查上述地址是否已在应用开放平台完整配置（不支持通配符）
  const localPortList = [8080];
  
  try {
    await initSSO();

    console.error('[Browser SSO] 初始化 SSO 客户端...');

    // 【关键】使用固定的 clientId（应用 ID）用于 OIDC 认证流程
    // 可通过环境变量 PLUS_SSO_CLIENT_ID 覆盖（用于测试不同的 clientId）
    // 注：这是应用本身的标识，不是用户的 clientId
    const clientId = process.env.PLUS_SSO_CLIENT_ID || '1452823222';

    // Token 存储文件
    const tokenStorageFile = path.join(
      os.homedir(),
      '.config/talos-cli-nodejs/sso-token.json'
    );

    // 根据 PLUS_CLI_ENV 环境变量确定环境（默认生产环境）
    const env = process.env.PLUS_CLI_ENV || 'product';
    const accessEnv = env === 'test' ? SSOAccessEnvType.test : SSOAccessEnvType.product;

    console.error(`[Browser SSO] 使用环境: ${env} (${accessEnv})`);
    console.error(`[Browser SSO] 使用 Client ID: ${clientId}`);
    console.error(`[Browser SSO] 本地回调地址：http://localhost:{port}`);
    console.error(`[Browser SSO] 尝试端口: ${localPortList.join(', ')}`);

    // 创建 SSO 客户端实例 - 根据文档必须提供所有必填参数
    const ssoClient = new SSOCliClient({
      clientId,                                                    // 必填：应用 ID
      accessEnv,                                                   // 必填：访问环境
      localPortList,                                               // 必填：本地回调端口列表
      tokenStorage: new FileTokenStorage(tokenStorageFile),       // 可选：Token 存储器
      isDebug: process.env.DEBUG === 'true' || process.env.DEBUG === '1', // 调试模式
    });

    console.error('[Browser SSO] 启动浏览器 SSO 登录...');
    console.error('[Browser SSO] 请在打开的浏览器窗口中完成登录');
    console.error('[Browser SSO] 登录超时时间：60 秒');

    // 执行登录流程 - 会自动打开浏览器
    const result = await ssoClient.login();

    console.error('[Browser SSO] 登录成功！');

    if (!result || !result.access_token) {
      errorExit(
        'browser_sso_failed',
        `未获取到 access_token。返回数据: ${JSON.stringify(result)}`
      );
    }

    const oauthAccessToken = result.access_token;
    const refreshToken = result.refresh_token || '';
    const expiresIn = result.expires_in || 3600;
    const expiresAt = Math.floor(Date.now() / 1000) + expiresIn;

    console.error(`[Browser SSO] Token 有效期: ${expiresIn} 秒`);
    
    // 从 access_token 中解析用户信息
    // Token 格式：AT_...**mtsso**...**base64(user_info)
    let userMisId = '';
    try {
      const tokenParts = oauthAccessToken.split('**');
      if (tokenParts.length >= 4) {
        // 最后一部分是 base64 编码的用户信息
        const encodedUserInfo = tokenParts[3];
        const userInfoStr = Buffer.from(encodedUserInfo, 'base64').toString('utf-8');
        
        // 格式：ID,misId,name,email,... (逗号分隔)
        const fields = userInfoStr.split(',');
        if (fields.length >= 2) {
          userMisId = fields[1]; // 第二个字段是 misId
          console.error(`[Browser SSO] 从 Token 中提取用户 MIS ID: ${userMisId}`);
        }
      }
    } catch (e) {
      console.error(`[Browser SSO] 解析 Token 失败: ${e.message}`);
    }
    
    if (!userMisId) {
      console.error('[Browser SSO] 警告：未能从 Token 中提取用户 MIS ID');
    }

    // ── 保存 Token 到两个位置 ──────────────────────────────────

    // 1. 保存到 plus-cli 配置
    const plusCliConfig = {
      token: oauthAccessToken,
      refreshToken,
      expiresAt,
      auth_method: 'browser_sso',
      client_id: clientId,
      environment: env,
      updated_at: Math.floor(Date.now() / 1000),
    };
    
    // 如果获取到用户 MIS ID，也保存它
    if (userMisId) {
      plusCliConfig.operator = userMisId;
      plusCliConfig.user_mis_id = userMisId;
    }

    fs.mkdirSync(configDir, { recursive: true });
    fs.writeFileSync(configFile, JSON.stringify(plusCliConfig, null, 2));
    console.error(`[Browser SSO] plus-cli config 已保存: ${configFile}`);

    // 2. 同时保存到 talos 配置（兼容性考虑）
    let talosCfg = {};
    if (fs.existsSync(tokenCacheFile)) {
      try {
        talosCfg = JSON.parse(fs.readFileSync(tokenCacheFile, 'utf-8'));
      } catch (e) {
        console.error('[Browser SSO] 警告：talos 配置格式错误，将重新创建');
      }
    }

    if (!talosCfg.ssoTokens) {
      talosCfg.ssoTokens = {};
    }
    talosCfg.ssoTokens.plus = {
      accessToken: oauthAccessToken,
      refreshToken,
      expiresAt,
    };

    fs.mkdirSync(tokenCacheDir, { recursive: true });
    fs.writeFileSync(tokenCacheFile, JSON.stringify(talosCfg, null, 2));
    console.error(`[Browser SSO] talos config 已保存: ${tokenCacheFile}`);

    // ── 输出成功结果 ────────────────────────────────────────

    const outputResult = {
      success: true,
      token: oauthAccessToken,
      auth_method: 'browser_sso',
      expires_in: expiresIn,
      expires_at: expiresAt,
    };
    
    // 如果成功提取到用户 MIS ID，也返回它（用于后续 token 交换）
    if (userMisId) {
      outputResult.user_mis_id = userMisId;
      outputResult.operator = userMisId;
    }

    console.log(JSON.stringify(outputResult));

    process.exit(0);
  } catch (error) {
    console.error('[Browser SSO] 错误堆栈:', error.stack);
    console.error('[Browser SSO] 错误消息:', error.message);
    console.error('[Browser SSO] 错误数据:', error.data || error.response?.data || '');
    console.error('[Browser SSO] 错误类型:', error.constructor?.name);
    
    // 解析常见的错误类型
    let errorCode = 'browser_sso_error';
    let diagnostic = '';
    
    if (error.message?.includes('ECONNREFUSED')) {
      errorCode = 'port_in_use';
      diagnostic = '本地端口被占用，请关闭其他使用这些端口的进程';
    } else if (error.message?.includes('invalid_request') && error.message?.includes('redirect_uri')) {
      errorCode = 'invalid_redirect_uri';
      diagnostic = `回调地址不匹配！必须在应用开放平台 (https://open.sankuai.com) 配置以下回调地址：
      • http://localhost:9152/websso/oauth/callback
      • http://localhost:10152/websso/oauth/callback
      • http://localhost:11152/websso/oauth/callback
      • http://localhost:12152/websso/oauth/callback
      
      配置步骤：开放平台 -> 应用列表 -> 选择应用 -> 编辑应用 -> OIDC 协议 -> 添加回调地址`;
    } else if (error.message?.includes('invalid_client')) {
      errorCode = 'invalid_client_id';
      diagnostic = '应用 ID 无效或该应用未启用 OIDC 协议';
    } else if (error.message?.includes('timeout')) {
      errorCode = 'login_timeout';
      diagnostic = '登录超时，请检查网络连接';
    }

    const fullMessage = diagnostic ? `${error.message}。${diagnostic}` : error.message;
    errorExit(errorCode, `浏览器 SSO 登录出现错误: ${fullMessage}`);
  }
}

// ── 入口点 ──────────────────────────────────────────────────
if (require.main === module) {
  performSSOLogin().catch((err) => {
    errorExit('browser_sso_error', err.message);
  });
}

module.exports = { performSSOLogin };
