#!/bin/bash

# 获取发布项信息并自动更新缓存
# Usage: 
#   ./fetch_release_info.sh [repository_url]  - 根据仓库地址获取
#   ./fetch_release_info.sh --name <release_name>  - 根据发布项名称获取
#   ./fetch_release_info.sh --id <release_id>  - 根据发布项ID获取
# 如果不提供任何参数，将尝试从当前目录的 git 仓库获取仓库地址

set -e

# Source 公共配置
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/release-common.sh"

# 初始化变量
QUERY_MODE="repository"  # 查询模式：repository, name, id
QUERY_VALUE=""
REPOSITORY=""
RELEASE_ID=""
RELEASE_NAME=""

# 参数解析
if [ $# -eq 0 ]; then
    # 尝试从当前目录的 git 获取远程仓库地址
    if ! git rev-parse --git-dir > /dev/null 2>&1; then
        echo "错误: 当前目录不是一个 git 仓库，且未提供任何参数" >&2
        echo "用法: $0 [repository_url]" >&2
        echo "       $0 --name <release_name>" >&2
        echo "       $0 --id <release_id>" >&2
        exit 1
    fi

    REPOSITORY=$(git remote get-url origin 2>/dev/null || echo "")

    if [ -z "$REPOSITORY" ]; then
        echo "错误: 无法获取 git 远程仓库地址" >&2
        echo "请检查 git remote 配置，或手动提供参数" >&2
        exit 1
    fi

    echo "从当前 git 仓库获取到远程地址: $REPOSITORY" >&2
elif [ "$1" == "--name" ]; then
    if [ -z "$2" ]; then
        echo "错误: --name 选项需要提供发布项名称" >&2
        exit 1
    fi
    QUERY_MODE="name"
    QUERY_VALUE="$2"
    echo "使用发布项名称查询: $QUERY_VALUE" >&2
elif [ "$1" == "--id" ]; then
    if [ -z "$2" ]; then
        echo "错误: --id 选项需要提供发布项ID" >&2
        exit 1
    fi
    QUERY_MODE="id"
    QUERY_VALUE="$2"
    echo "使用发布项ID查询: $QUERY_VALUE" >&2
else
    REPOSITORY="$1"
    echo "使用指定的仓库地址: $REPOSITORY" >&2
fi

echo "" >&2

# 根据查询模式获取发布项信息
if [ "$QUERY_MODE" == "repository" ]; then
    echo "正在从 API 获取发布项信息..." >&2
    RESPONSE=$(curl -s -X GET \
      "${API_HOST}/code/repo/release/list?repository=${REPOSITORY}")
    
    # 响应直接是数组，检查是否为空
    if ! echo "$RESPONSE" | jq -e '.[0]' > /dev/null 2>&1; then
        echo "错误: 未找到此仓库的发布项" >&2
        exit 2
    fi
    
    # 响应是直接的数组，保存所有发布项供后续处理
    RELEASES_DATA="$RESPONSE"
    
elif [ "$QUERY_MODE" == "name" ]; then
    echo "正在根据名称查询发布项信息..." >&2
    RESPONSE=$(curl -s -X GET "${API_HOST}/release_detail?release_name=${QUERY_VALUE}")
    
    # 检查响应是否有有效的发布项ID
    RELEASE_ID=$(echo "$RESPONSE" | jq -r '.Id')
    
    if [ "$RELEASE_ID" == "null" ] || [ "$RELEASE_ID" == "" ]; then
        echo "错误: 未找到该发布项名称: $QUERY_VALUE" >&2
        exit 2
    fi
    
    # 响应是直接的发布项对象，包装为数组
    RELEASES_DATA=$(echo "$RESPONSE" | jq '[.]')
    
    echo "获取到发布项ID: $RELEASE_ID" >&2
    
elif [ "$QUERY_MODE" == "id" ]; then
    echo "正在根据ID查询发布项信息..." >&2
    RESPONSE=$(curl -s -X GET "${API_HOST}/release_detail?release_id=${QUERY_VALUE}")
    
    # 检查响应是否有有效的发布项ID
    RELEASE_ID=$(echo "$RESPONSE" | jq -r '.Id')
    
    if [ "$RELEASE_ID" == "null" ] || [ "$RELEASE_ID" == "" ]; then
        echo "错误: 未找到该发布项ID: $QUERY_VALUE" >&2
        exit 2
    fi
    
    # 响应是直接的发布项对象，包装为数组
    RELEASES_DATA=$(echo "$RESPONSE" | jq '[.]')
fi

# 构造所有发布项的 JSON 数据用于缓存
# 将 API 返回的发布项数组转换为我们的缓存格式
RELEASES_TO_CACHE=$(echo "$RELEASES_DATA" | jq -r --arg repo "$REPOSITORY" '[.[] | {
  repository: $repo,
  release_id: .Id,
  release_name: .Name,
  appkey: .Appkey
}]')

# 验证是否有有效的发布项
if [ "$(echo "$RELEASES_TO_CACHE" | jq 'length')" -eq 0 ]; then
    echo "错误: 获取的发布项信息不完整或为空" >&2
    exit 2
fi

# 输出将要保存的发布项数量
RELEASE_COUNT=$(echo "$RELEASES_TO_CACHE" | jq 'length')
echo "获取到 $RELEASE_COUNT 个发布项" >&2

# 更新缓存
CACHE_FILE="${CACHE_DIR}/releases.json"
ensure_cache_dir "${CACHE_DIR}"

if [ ! -f "$CACHE_FILE" ]; then
    # 缓存文件不存在，创建新文件
    echo '{"releases":[]}' > "$CACHE_FILE"
    echo "创建缓存文件: $CACHE_FILE" >&2
fi

# 更新或添加所有发布项信息到缓存
# 对每个新的发布项，检查是否在缓存中存在，存在则更新，否则追加
TMP_FILE=$(mktemp)
TIMESTAMP=$(date -u +'%Y-%m-%dT%H:%M:%SZ')

jq --argjson new_releases "$(echo "$RELEASES_TO_CACHE")" \
  --arg last_updated "$TIMESTAMP" \
  '.releases |= (
    . as $old_releases |
    (
      # 更新已存在的发布项（保留原有的last_updated，新项目添加当前时间戳）
      ($old_releases | map(
        . as $old_item |
        ($new_releases[] | select(.release_id == $old_item.release_id) as $matched |
          $matched + {last_updated: $last_updated}
        ) // $old_item
      )) +
      # 添加缓存中不存在的新发布项
      [
        $new_releases[] | select(
          . as $new_item |
          ($old_releases | any(.release_id == $new_item.release_id) | not)
        ) | . + {last_updated: $last_updated}
      ]
    )
  )' "$CACHE_FILE" > "$TMP_FILE" && mv "$TMP_FILE" "$CACHE_FILE"

echo "✓ 已将 $RELEASE_COUNT 个发布项保存到缓存: $CACHE_FILE" >&2

# 处理部署模版缓存
echo "" >&2
echo "正在处理部署模版缓存..." >&2

# 对每个发布项保存其对应的模版缓存
echo "$RELEASES_DATA" | jq -c '.[]' | while read -r RELEASE_JSON; do
    RELEASE_ID=$(echo "$RELEASE_JSON" | jq -r '.Id')
    TEMPLATES_CACHE_DIR="${CACHE_DIR}/releases/${RELEASE_ID}"
    TEMPLATES_CACHE_FILE="${TEMPLATES_CACHE_DIR}/templates.json"
    
    ensure_cache_dir "${TEMPLATES_CACHE_DIR}"
    
    # 从发布项数据中提取模版信息
    # 只保留 template_id, template_name, environment, environment_name, build_template_name
    ALL_TEMPLATES_JSON=$(echo "$RELEASE_JSON" | jq '
      (.BuildTemplate // []) as $build_templates |
      [(.Template // []) | .[] | 
        . as $template |
        ($build_templates[] | select(.Id == $template.BuildTemplateId) | .Name) as $build_template_name |
        {
          template_id: .Id,
          template_name: .Name,
          environment: .Env,
          environment_name: (if .Env == 1 then "prod" elif .Env == 2 then "staging" elif .Env == 3 then "test" elif .Env == 4 then "beta" elif .Env == 5 then "dev" else "prod" end),
          build_template_name: ($build_template_name // "")
        }
      ]
    ')
    
    if [ ! -f "$TEMPLATES_CACHE_FILE" ]; then
        # 缓存文件不存在，创建新文件
        echo '{"templates":[]}' > "$TEMPLATES_CACHE_FILE"
        echo "创建模版缓存文件: $TEMPLATES_CACHE_FILE" >&2
    fi
    
    # 更新或添加所有模版信息到缓存
    TMP_FILE=$(mktemp)
    TIMESTAMP=$(date -u +'%Y-%m-%dT%H:%M:%SZ')
    
    jq --argjson new_templates "$(echo "$ALL_TEMPLATES_JSON")" \
      --arg release_id "$RELEASE_ID" \
      --arg last_updated "$TIMESTAMP" \
      '.release_id = ($release_id | tonumber) |
       .last_updated = $last_updated |
       .templates = (
         (.templates // []) as $existing |
         [
           ($existing[] | {id: .template_id, item: .}),
           ($new_templates[] | {id: .template_id, item: .})
         ] |
         unique_by(.id) |
         map(.item)
       )' "$TEMPLATES_CACHE_FILE" > "$TMP_FILE" && mv "$TMP_FILE" "$TEMPLATES_CACHE_FILE"
    
    TEMPLATES_COUNT=$(cat "$TEMPLATES_CACHE_FILE" | jq '.templates | length')
    echo "✓ 缓存已更新: $TEMPLATES_CACHE_FILE（当前共 $TEMPLATES_COUNT 个模版）" >&2
done
