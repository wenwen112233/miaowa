#!/bin/bash

# 公共变量和函数 - 发布项信息技能
# 此文件被所有脚本 source，提供共享的配置和工具函数

# API 配置
API_HOST="http://plus.sankuai.com"

# 目录配置
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
CACHE_DIR="${SKILL_DIR}/.cache/release-info"

# 确保缓存目录存在w
ensure_cache_dir() {
    local dir="$1"
    mkdir -p "${dir}"
}

# 根据环境 ID 获取环境名称
get_env_name() {
    local env_id="$1"
    case "$env_id" in
        1) echo "prod" ;;
        2) echo "staging" ;;
        3) echo "test" ;;
        4) echo "beta" ;;
        5) echo "dev" ;;
        *) echo "prod" ;;
    esac
}

# 从 git 获取仓库地址
get_repository_from_git() {
    if ! git rev-parse --git-dir > /dev/null 2>&1; then
        return 1
    fi

    local repo=$(git remote get-url origin 2>/dev/null || echo "")
    if [ -z "$repo" ]; then
        return 1
    fi

    echo "$repo"
    return 0
}
